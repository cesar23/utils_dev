function menu(){

    echo "-------------------------------------------------"
    echo "------- Comandos favoritos!  version 1.0.2"
    echo "-------------------------------------------------"
    printf "\n\n"
    ##---------------------
    COMANDO="menu"
    printf  "   * command ${Purple}${COMANDO} ${Color_Off}: %s  ver menu favoritos \n"
    ##---------------------
    COMANDO="bashrc"
    printf  "   * command ${Purple}${COMANDO} ${Color_Off}: ver .bash_profile \n"
    ##---------------------
    COMANDO="gitup-qa"
    printf  "   * command ${Purple}${COMANDO} ${Color_Off}: actualiza repositorio actual en qa\n"
    ##---------------------
    COMANDO="gitup-all"
    printf  "   * command ${Purple}${COMANDO} ${Color_Off}: actualiza repositorio actual en qa\n"
    ##---------------------
    COMANDO="init_ssh"
    printf  "   * command ${Purple}${COMANDO} ${Color_Off}: ssh linux\n"
    ##---------------------
    COMANDO="path_shell_to_path_windows"
    printf  "   * command ${Purple}${COMANDO} ${Color_Off}: convierte path shell a Windows uso: path_shell_to_path_windows '/temp'\n"
    ##---------------------
    COMANDO="path_windows_to_path_shell"
    printf  "   * command ${Purple}${COMANDO} ${Color_Off}: convierte path windows a Shell uso: path_windows_to_path_shell '%s' \n" "c:\\\temp"
    ##---------------------
    COMANDO="start-docker-compose"
    printf  "   * command ${Purple}${COMANDO} ${Color_Off}: inicia docker-compose desde\n"
    ##---------------------
    COMANDO="cdd"
    printf "\n"
    printf  "   * command ${Purple}${COMANDO} ${Color_Off}: lista carpetas del directorio actual\n"
    # printf  "   * command start-docker-compose:      start-docker-compose  inicia docker-compose desde"
    ##---------------------
    COMANDO="reload_config"
    printf "\n"
    printf  "   * command ${Purple}${COMANDO} ${Color_Off}: recargar funciones,alias,conf extras\n"
    ##---------------------
    printf  "   ::-----------------------------------------------------------::\n"
    printf  "   ::------------------------ IDES -----------------------------::\n"
    printf  "   ::-----------------------------------------------------------::\n"
    COMANDO="xwst , xidea"
    printf  "   * commands ${Purple}${COMANDO} ${Color_Off}: Abrir ides Intellij\n"
    ##---------------------
    printf  "   ::-----------------------------------------------------------::\n"
    printf  "   ::------------------------ util -----------------------------::\n"
    printf  "   ::-----------------------------------------------------------::\n"
    COMANDO="xmobax"
    printf  "   * commands ${Purple}${COMANDO} ${Color_Off}: Abre Terminal mobaxTerm\n"

    COMANDO="run_server_py"
        printf  "   * commands ${Purple}${COMANDO} ${Color_Off}: abre un server local en python\n"
    COMANDO="cds"
    printf  "   * commands ${Purple}${COMANDO} ${Color_Off}: utiliza para  entrar a un directorio desde gitbash \n"
    printf  "                    ${Cyan} ejemplo: cds \'D:/repos/test_repos\' ${Color_Off} "

    #------------
    COMANDO="menu_proxmox"
    printf "\n"
    printf  "   * command ${Purple}${COMANDO} ${Color_Off}: Menu proxmox\n"

    #------------
    printf "\n"
    echo "-------------------------------------------------"
    echo "------- Comandos Utilies"
    echo "-------------------------------------------------"
    printf "\n"
    printf "   - check ip public: ${Cyan} curl checkip.dyndns.org ${Color_Off} \n"
    


    printf "\n"
    printf "\n"

}
