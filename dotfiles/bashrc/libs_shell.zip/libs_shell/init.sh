# -------------------------------- INICIO DEL SCRIPT --------------------------------
# ----------------------------------------
# Function: detect_system
# Detects the operating system distribution.
# Returns:
#   - "termux"  -> If running in Termux
#   - "wsl"     -> If running on Windows Subsystem for Linux
#   - "ubuntu"  -> If running on Ubuntu/Debian-based distributions
#   - "redhat"  -> If running on Red Hat, Fedora, CentOS, Rocky, or AlmaLinux
#   - "gitbash" -> If running on Git Bash
#   - "unknown" -> If the system is not recognized
#
# Example usage:
#   system=$(detect_system)
#   echo "Detected system: $system"
# ----------------------------------------
detect_system() {
    if [ -f /data/data/com.termux/files/usr/bin/pkg ]; then
        echo "termux"
    elif grep -q Microsoft /proc/version; then
        echo "wsl"
    elif [ -f /etc/os-release ]; then
        # Lee el ID de /etc/os-release
        source /etc/os-release
        case $ID in
            ubuntu|debian)
                echo "ubuntu"
                ;;
            rhel|centos|fedora|rocky|almalinux)
                echo "redhat"
                ;;
            *)
                echo "unknown"
                ;;
        esac
    elif [ -n "$MSYSTEM" ]; then
        echo "gitbash"
    else
        echo "unknown"
    fi
}

# Obtiene la ruta absoluta del script actual
PATH_SCRIPT=$(readlink -f "${BASH_SOURCE:-$0}")
CURRENT_DIR=$(dirname "$PATH_SCRIPT")

# --------------------------------------------------------
# ----- Determina el tipo de terminal actual -------------
# --------------------------------------------------------
CURRENT_TERMINAL='gitbash'  # Valor por defecto: Git Bash


# Detectar sistema operativo
SO_SYSTEM=$(detect_system)


# si estamos en so de termux, cambiar la ruta de descarga
if [ "$SO_SYSTEM" = "termux" ]; then
    CURRENT_TERMINAL='linux'
    CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/linux"

elif [ "$SO_SYSTEM" = "gitbash" ]; then
  CURRENT_TERMINAL='gitbash'
  CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/gitbash"

elif [ "$SO_SYSTEM" = "ubuntu" ]; then
  CURRENT_TERMINAL='linux'
  CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/linux"

else
  # defecto  linux
    CURRENT_TERMINAL='linux'
    CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/linux"
fi



## Si el shell es bash en Git Bash
#if [ "$SHELL" == "/usr/bin/bash" ]; then
#    CURRENT_TERMINAL='gitbash'
#    CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/gitbash"
#
#    # Si existe la variable CMDER_ROOT, entonces estamos en Cmder
#    if [ -n "$CMDER_ROOT" ]; then
#        CURRENT_TERMINAL='cmder'
#        CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/cmder"
#    fi
#fi
#
## Si el shell es bash en Linux
#if [ "$SHELL" == "/bin/bash" ]; then
#    CURRENT_TERMINAL='linux'
#    CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/linux"
#fi
#
## Si el shell es bash en MobaXterm
#if [ "$SHELL" == "/bin/bash.exe" ]; then
#    CURRENT_TERMINAL='mobax'
#    CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/mobax"
#fi

# --------------------------------------------------------
# ----- Carga de scripts según el terminal detectado -----
# --------------------------------------------------------
case "$CURRENT_TERMINAL" in
    # ---------------------------------------------------------
    # Git Bash
    # ---------------------------------------------------------
    "gitbash")
        if [ -f "${CURRENT_TERMINAL_SCRIPTS}/colors.sh" ]; then
            # Función para recargar la configuración de Git Bash
            function reload_config() {
                source "${CURRENT_TERMINAL_SCRIPTS}/colors.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_1.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_2.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_level_1.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_ides.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_files.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_extras.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/func_fzf.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_menu.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/func_server_ssh.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_neofetch.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/func_navegacion.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_docker.sh"
            }
            reload_config
        fi
        ;;

    # ---------------------------------------------------------
    # Cmder
    # ---------------------------------------------------------
    "cmder")
        if [ -f "${CURRENT_TERMINAL_SCRIPTS}/colors.sh" ]; then
            # Función para recargar la configuración de Cmder
            function reload_config() {
                source "${CURRENT_TERMINAL_SCRIPTS}/z.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/fzf_script.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/colors.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_1.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_2.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_level_1.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_ides.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_files.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_extras.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_menu.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_neofetch.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_docker.sh"
            }
            reload_config
        fi
        ;;

    # ---------------------------------------------------------
    # Linux
    # ---------------------------------------------------------
    "linux")
        if [ -f "${CURRENT_TERMINAL_SCRIPTS}/colors.sh" ]; then
            # Función para recargar la configuración en Linux
            function reload_config() {
                source "${CURRENT_TERMINAL_SCRIPTS}/colors.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_1.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_2.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_level_1.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_extras.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/func_fzf.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_menu.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/func_server_ssh.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/func_img_compress.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/func_navegacion.sh"
                # source "${CURRENT_TERMINAL_SCRIPTS}/conf_neofetch.sh" # Comentado, no está disponible
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_docker.sh"
            }
            reload_config

        fi
        ;;

    # ---------------------------------------------------------
    # MobaXterm
    # ---------------------------------------------------------
    "mobax")
        # Función para recargar la configuración en MobaXterm
        function reload_config() {
            source "${CURRENT_TERMINAL_SCRIPTS}/colors.sh"
            source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_1.sh"
            source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_2.sh"
            source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_level_1.sh"
            source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_ides.sh"
            source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_files.sh"
            source "${CURRENT_TERMINAL_SCRIPTS}/conf_extras.sh"
            source "${CURRENT_TERMINAL_SCRIPTS}/func_fzf.sh"
            source "${CURRENT_TERMINAL_SCRIPTS}/conf_menu.sh"
            source "${CURRENT_TERMINAL_SCRIPTS}/conf_neofetch.sh"
            source "${CURRENT_TERMINAL_SCRIPTS}/mobax.sh"
            source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_docker.sh"
        }
        reload_config
        echo -en "\e[1;32mLoading functions [Cesar A.]  ... \e[0m \n" && sleep 4 && clear
        ;;

    # ---------------------------------------------------------
    # Termux
    # ---------------------------------------------------------
    "mobax")
        # Función para recargar la configuración en MobaXterm
        function reload_config() {
                source "${CURRENT_TERMINAL_SCRIPTS}/colors.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_1.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_2.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_level_1.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_extras.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/func_fzf.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_menu.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/func_img_compress.sh"
                source "${CURRENT_TERMINAL_SCRIPTS}/func_navegacion.sh"
                # source "${CURRENT_TERMINAL_SCRIPTS}/conf_neofetch.sh" # Comentado, no está disponible
                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_docker.sh"
        }
        reload_config
        echo -en "\e[1;32mLoading functions [Cesar A.]  ... \e[0m \n" && sleep 4 && clear
        ;;
esac

# ----------------------------- FIN DEL SCRIPT -----------------------------
