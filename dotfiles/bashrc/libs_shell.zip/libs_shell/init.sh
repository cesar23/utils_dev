# -------------------------------- INICIO DEL SCRIPT --------------------------------
# ----------------------------------------------------------------------------------
# PERF: valores globales calculados UNA sola vez por sesión de shell.
# Los demás scripts (conf_funciones_level_1.sh, level_2.sh, func_server_ssh.sh,
# func_img_compress.sh, funGit.sh, etc.) reutilizan estas variables en vez de
# volver a lanzar procesos (id, hostname, date, readlink, basename, dirname...).
# Esto evita ~25 forks redundantes cada vez que abres una terminal o corres
# "reload_config" / "cesar". En Git Bash cada fork cuesta mucho más que en
# Linux, así que esta parte es la que más se nota.
# ----------------------------------------------------------------------------------
: "${CURRENT_USER:=$(id -un)}"
: "${CURRENT_PC_NAME:=$(hostname)}"
: "${MY_INFO:=${CURRENT_USER}@${CURRENT_PC_NAME}}"
: "${INFO_PC:=${MY_INFO}}"

: "${PATH_SCRIPT:=$(readlink -f "${BASH_SOURCE:-$0}")}" # Ruta completa del script actual.
: "${SCRIPT_NAME:=$(basename "$PATH_SCRIPT")}"
: "${CURRENT_DIR:=$(dirname "$PATH_SCRIPT")}"
: "${INFO_PC:=${MY_INFO}}"
: "${INFO_PC:=${MY_INFO}}"
: "${INFO_PC:=${MY_INFO}}"
: "${INFO_PC:=${MY_INFO}}"




# Fecha/hora en zona horaria de Perú (UTC-5), un solo fork de "date" en vez de
# la cadena "date -d ... || TZ=... date ... || echo ..." repetida en 4 ficheros.
: "${DATE_HOUR:=$(TZ="America/Lima" date "+%Y-%m-%d_%H:%M:%S")}"
: "${DATE_HOUR_GIT:=$DATE_HOUR}"
: "${DATE_HOUR_GIT_PE:=$DATE_HOUR}"
: "${DATE_HOUR_PE:=$DATE_HOUR}"
export CURRENT_USER CURRENT_PC_NAME PATH_SCRIPT SCRIPT_NAME CURRENT_DIR MY_INFO INFO_PC DATE_HOUR DATE_HOUR_GIT DATE_HOUR_GIT_PE DATE_HOUR_PE

# ----------------------------------------
# Function: detect_system
# Detects the operating system distribution.
# Returns:
#   - "termux"  -> If running in Termux
#   - "wsl"     -> If running on Windows Subsystem for Linux
#   - "ubuntu"  -> If running on Ubuntu/Debian-based distributions
#   - "redhat"  -> If running on Red Hat, Fedora, CentOS, Rocky, or AlmaLinux
#   - "gitbash" -> If running on Git Bash
#   - "unknown" -> If the system is not recognized
#
# Example usage:
#   system=$(detect_system)
#   echo "Detected system: $system"
# ----------------------------------------
detect_system() {
    if [ -f /data/data/com.termux/files/usr/bin/pkg ]; then
        echo "termux"
    elif [ -f /proc/version ] && { read -r _proc_version_line < /proc/version; [[ $_proc_version_line == *Microsoft* ]]; }; then
        echo "wsl"
    elif [ -f /etc/os-release ]; then
        # Lee el ID de /etc/os-release
        source /etc/os-release
        case $ID in
            ubuntu|debian)
                echo "ubuntu"
                ;;
            rhel|centos|fedora|rocky|almalinux)
                echo "redhat"
                ;;
            *)
                echo "unknown"
                ;;
        esac
    elif [ -n "$MSYSTEM" ]; then
        echo "gitbash"
    else
        echo "unknown"
    fi
}


# --------------------------------------------------------
# ----- Determina el tipo de terminal actual -------------
# --------------------------------------------------------
CURRENT_TERMINAL='gitbash'  # Valor por defecto: Git Bash


# Detectar sistema operativo
SO_SYSTEM=$(detect_system)


# si estamos en so de termux, cambiar la ruta de descarga
if [ "$SO_SYSTEM" = "termux" ]; then
    CURRENT_TERMINAL='linux'
    CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/linux"

elif [ "$SO_SYSTEM" = "gitbash" ]; then
  CURRENT_TERMINAL='gitbash'
  CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/gitbash"

elif [ "$SO_SYSTEM" = "ubuntu" ]; then
  CURRENT_TERMINAL='linux'
  CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/linux"

else
  # defecto  linux
    CURRENT_TERMINAL='linux'
    CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/linux"
fi



## Si el shell es bash en Git Bash
#if [ "$SHELL" == "/usr/bin/bash" ]; then
#    CURRENT_TERMINAL='gitbash'
#    CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/gitbash"
#
#    # Si existe la variable CMDER_ROOT, entonces estamos en Cmder
#    if [ -n "$CMDER_ROOT" ]; then
#        CURRENT_TERMINAL='cmder'
#        CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/cmder"
#    fi
#fi
#
## Si el shell es bash en Linux
#if [ "$SHELL" == "/bin/bash" ]; then
#    CURRENT_TERMINAL='linux'
#    CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/linux"
#fi
#


## Si el shell es bash en MobaXterm
#if [ "$SHELL" == "/bin/bash.exe" ]; then
#    CURRENT_TERMINAL='mobax'
#    CURRENT_TERMINAL_SCRIPTS="${CURRENT_DIR}/mobax"
#fi


source "${CURRENT_DIR}/config_menu.sh"

# ---------------------------------
# 1. funciones genrales
# ---------------------------------

#cf(){
#  source "${CURRENT_DIR}/gitbash/func_generales.sh"
#  general_cf
#}
#
#clear_saved_prompt(){
#  source "${CURRENT_DIR}/gitbash/func_generales.sh"
#  general_clear_saved_prompt
#}
#
#comparar(){
#  source "${CURRENT_DIR}/gitbash/func_generales.sh"
#  general_comparar
#}
#
#general_dcrestart(){
#  source "${CURRENT_DIR}/gitbash/func_generales.sh"
#  general_comparar
#}



# ---------------------------------
# 1. Funciones generales (carga perezosa)
# ---------------------------------
# func_generales.sh vive en la raíz de libs_shell (no depende del OS: no
# hay nada gitbash-específico ahí dentro), por eso se referencia con
# $CURRENT_DIR y no con $CURRENT_TERMINAL_SCRIPTS. Cada función real ahí
# dentro está nombrada "general_<nombre>" (p.ej. general_cf, general_sd,
# general_dcrestart...); este bloque genera automáticamente una función
# pública de nombre corto (cf, sd, dcrestart...) por cada una que
# encuentra, para no tener que escribirlas ni mantenerlas a mano.
#
# La primera vez que llamas a cualquiera de esas funciones cortas:
#   1) se hace source de func_generales.sh completo (define TODAS las
#      "general_*" reales)
#   2) se ejecuta la "general_<nombre>" correspondiente, con tus argumentos
# El resto de la sesión ya quedan cargadas de verdad, sin capa extra.
#
# Si una función ya existe como función real (por ejemplo las definidas
# directamente en el .bashrc: parse_git_branch, short_pwd, p1..p5, vi,
# menu), no se genera un stub para no pisarla.
_FUNC_GENERALES="${CURRENT_DIR}/${CURRENT_TERMINAL}/func_generales.sh"
if [ -f "$_FUNC_GENERALES" ]; then
    while read -r _real; do
        _pub="${_real#general_}"
        [ -z "$_pub" ] && continue
        declare -F "$_pub" >/dev/null 2>&1 && continue   # ya está cargada de verdad, no pisar
        eval "
${_pub}() {
    source \"\$_FUNC_GENERALES\"
    ${_real} \"\$@\"
}"
    done < <(grep -oE '^(function[[:space:]]+)?general_[a-zA-Z0-9_]*[[:space:]]*\(\)' "$_FUNC_GENERALES" | sed -E 's/^function[[:space:]]+//; s/[[:space:]]*\(\)//')
    unset _real _pub
fi



_FUNC_PYTHON="${CURRENT_DIR}/${CURRENT_TERMINAL}/conf_func_python.sh"
if [ -f "$_FUNC_PYTHON" ]; then
    while read -r _real; do
        _pub="${_real#python_fuc_}"
        [ -z "$_pub" ] && continue
        declare -F "$_pub" >/dev/null 2>&1 && continue   # ya está cargada de verdad, no pisar
        eval "
${_pub}() {
    source \"\$_FUNC_PYTHON\"
    ${_real} \"\$@\"
}"
    done < <(grep -oE '^(function[[:space:]]+)?python_fuc_[a-zA-Z0-9_]*[[:space:]]*\(\)' "$_FUNC_PYTHON" | sed -E 's/^function[[:space:]]+//; s/[[:space:]]*\(\)//')
    unset _real _pub
fi




_FUNC_GIT="${CURRENT_DIR}/${CURRENT_TERMINAL}/funGit.sh"
# NOTA: a diferencia de func_generales.sh y conf_func_python.sh, funGit.sh
# NO usa un prefijo común (sus funciones se llaman directo: gitup, gitup2,
# git_merge, gcm, etc.) -- por eso aquí no se recorta ningún prefijo, el
# nombre público es el mismo que el nombre real.
if [ -f "$_FUNC_GIT" ]; then
    while read -r _real; do
        [ -z "$_real" ] && continue
        declare -F "$_real" >/dev/null 2>&1 && continue   # ya está cargada de verdad, no pisar
        eval "
${_real}() {
    source \"\$_FUNC_GIT\"
    ${_real} \"\$@\"
}"
    done < <(grep -oE '^(function[[:space:]]+)?[a-zA-Z_][a-zA-Z0-9_]*[[:space:]]*\(\)' "$_FUNC_GIT" | sed -E 's/^function[[:space:]]+//; s/[[:space:]]*\(\)//')
    unset _real
fi

# =================================================================
_FUNC_LEVEL_1="${CURRENT_DIR}/${CURRENT_TERMINAL}/conf_funciones_level_1.sh"
# NOTA: a diferencia de func_generales.sh y conf_func_python.sh, funGit.sh
# NO usa un prefijo común (sus funciones se llaman directo: path_to_laragon_format, cds, login, path_file_weight_human)
# nombre público es el mismo que el nombre real.
if [ -f "$_FUNC_LEVEL_1" ]; then
    while read -r _real; do
        [ -z "$_real" ] && continue
        declare -F "$_real" >/dev/null 2>&1 && continue   # ya está cargada de verdad, no pisar
        eval "
${_real}() {
    source \"\$_FUNC_LEVEL_1\"
    ${_real} \"\$@\"
}"
    done < <(grep -oE '^(function[[:space:]]+)?[a-zA-Z_][a-zA-Z0-9_]*[[:space:]]*\(\)' "$_FUNC_LEVEL_1" | sed -E 's/^function[[:space:]]+//; s/[[:space:]]*\(\)//')
    unset _real
fi

# =================================================================
# LA ULTIMA Y MEJORADA (CESAR)
# Arma la ruta completa al archivo real (solo texto, todavía no lo lee ni lo ejecuta).
_FUNC_FILES="${CURRENT_DIR}/${CURRENT_TERMINAL}/conf_funciones_files.sh"

# Si el archivo no existe, todo el bloque se salta sin hacer nada (seguro tenerlo aunque falte el archivo).
if [ -f "$_FUNC_FILES" ]; then

    # Bucle: se ejecuta una vez por cada nombre de función que llegue por la tubería de abajo (la del "done < <(...)").
    # En cada vuelta, "_real" contiene UN nombre (ej: "cds"), leído línea por línea.
    while read -r _real; do
        # Si por algún motivo llegó una línea vacía, la salta y sigue con la siguiente vuelta.
        [ -z "$_real" ] && continue
        # Pregunta "¿ya existe una función REAL con este nombre cargada en la sesión?" (declare -F no imprime
        # el código, solo dice sí/no). Si ya existe (por ejemplo porque otro archivo ya la definió de verdad),
        # "continue" salta esta vuelta del bucle para NO pisarla con un stub.
        declare -F "$_real" >/dev/null 2>&1 && continue   # ya está cargada de verdad, no pisar

        # "eval" toma el texto entre comillas y lo EJECUTA como si tú lo hubieras tecleado a mano.
        # Como "${_real}" se reemplaza por el nombre real (ej: "cds") ANTES de que eval lo interprete,
        # esto crea una función pública con ESE MISMO nombre: el "doble" liviano (el stub).
        eval "
          ${_real}() {
              # Esto solo corre la PRIMERA vez que alguien llama a esta función (ej: cds proyectos).
              # "source" lee y ejecuta el archivo real completo, lo que REDEFINE esta función (y todas
              # las demás del mismo archivo) con su código de verdad, reemplazando este stub.
              source \"\$_FUNC_FILES\"
              # Como bash busca la definición de una función en el momento en que se llama (no antes),
              # esta línea ya encuentra la versión REAL recién cargada y la ejecuta con tus mismos
              # argumentos ("\$@" conserva cada argumento tal cual, incluso los que tienen espacios).
              ${_real} \"\$@\"
          }"

    # Esto alimenta el "while read" de arriba: busca en el archivo todas las líneas que empiecen con
    # "nombre()" o "function nombre()" (grep), y les quita la palabra "function" y los paréntesis "()"
    # (sed), dejando solo el nombre limpio. Es una simple lectura de texto: NO ejecuta ni una sola
    # línea del archivo real, por eso es seguro/barato hacerlo en cada apertura de terminal.
    done < <(grep -oE '^(function[[:space:]]+)?[a-zA-Z_][a-zA-Z0-9_]*[[:space:]]*\(\)' "$_FUNC_FILES" | sed -E 's/^function[[:space:]]+//; s/[[:space:]]*\(\)//')

    # Limpieza: "_real" fue solo una variable temporal del bucle, se borra para no dejarla dando vueltas
    # en la sesión (podría confundir si otro script usa una variable con ese mismo nombre más adelante).
    unset _real
fi

#
## --------------------------------------------------------
## ----- Carga de scripts según el terminal detectado -----
## --------------------------------------------------------
#case "$CURRENT_TERMINAL" in
#    # ---------------------------------------------------------
#    # Git Bash
#    # ---------------------------------------------------------
#    "gitbash")
#        if [ -f "${CURRENT_TERMINAL_SCRIPTS}/colors.sh" ]; then
#            # Función para recargar la configuración de Git Bash
#            function reload_config() {
#                source "${CURRENT_TERMINAL_SCRIPTS}/colors.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_1.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_2.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_level_1.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_ides.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_files.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_extras.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/func_fzf.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_menu.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/func_server_ssh.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_neofetch.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/func_navegacion.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_docker.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/funGit.sh"
#            }
#            reload_config
#        fi
#        ;;
#
#    # ---------------------------------------------------------
#    # Cmder
#    # ---------------------------------------------------------
#    "cmder")
#        if [ -f "${CURRENT_TERMINAL_SCRIPTS}/colors.sh" ]; then
#            # Función para recargar la configuración de Cmder
#            function reload_config() {
#                source "${CURRENT_TERMINAL_SCRIPTS}/z.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/fzf_script.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/colors.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_1.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_2.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_level_1.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_ides.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_files.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_extras.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_menu.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_neofetch.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_docker.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/funGit.sh"
#            }
#            reload_config
#        fi
#        ;;
#
#    # ---------------------------------------------------------
#    # Linux
#    # ---------------------------------------------------------
#    "linux")
#        if [ -f "${CURRENT_TERMINAL_SCRIPTS}/colors.sh" ]; then
#            # Función para recargar la configuración en Linux
#            function reload_config() {
#                source "${CURRENT_TERMINAL_SCRIPTS}/colors.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_1.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_2.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_level_1.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_extras.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/func_fzf.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_menu.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/func_server_ssh.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/func_img_compress.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/func_navegacion.sh"
#                # source "${CURRENT_TERMINAL_SCRIPTS}/conf_neofetch.sh" # Comentado, no está disponible
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_docker.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/funGit.sh"
#            }
#            reload_config
#
#        fi
#        ;;
#
#    # ---------------------------------------------------------
#    # MobaXterm
#    # ---------------------------------------------------------
#    "mobax")
#        # Función para recargar la configuración en MobaXterm
#        function reload_config() {
#            source "${CURRENT_TERMINAL_SCRIPTS}/colors.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_1.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_2.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_level_1.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_ides.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_files.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/conf_extras.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/func_fzf.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/conf_menu.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/conf_neofetch.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/mobax.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_docker.sh"
#            source "${CURRENT_TERMINAL_SCRIPTS}/funGit.sh"
#        }
#        reload_config
#        echo -en "\e[1;32mLoading functions [Cesar A.]  ... \e[0m \n" && sleep 4 && clear
#        ;;
#
#    # ---------------------------------------------------------
#    # Termux
#    # ---------------------------------------------------------
#    "mobax")
#        # Función para recargar la configuración en MobaXterm
#        function reload_config() {
#                source "${CURRENT_TERMINAL_SCRIPTS}/colors.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_1.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_funciones_level_2.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_level_1.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_extras.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/func_fzf.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_menu.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/func_img_compress.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/func_navegacion.sh"
#                # source "${CURRENT_TERMINAL_SCRIPTS}/conf_neofetch.sh" # Comentado, no está disponible
#                source "${CURRENT_TERMINAL_SCRIPTS}/conf_alias_docker.sh"
#                source "${CURRENT_TERMINAL_SCRIPTS}/funGit.sh"
#        }
#        reload_config
#        echo -en "\e[1;32mLoading functions [Cesar A.]  ... \e[0m \n" && sleep 4 && clear
#        ;;
#esac

# ----------------------------- FIN DEL SCRIPT -----------------------------
