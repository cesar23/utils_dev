#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  GIT - Aliases & Functions
#  @author Cesar Auris
#  @updated 2025
# ═══════════════════════════════════════════════════════════════


# ──────────────────────────────────────────────
#  VARIABLES GLOBALES
# ──────────────────────────────────────────────
CURRENT_USER=$(id -un)
CURRENT_PC_NAME=$(hostname)
MY_INFO="${CURRENT_USER}@${CURRENT_PC_NAME}"
INFO_PC=${INFO_PC:-$MY_INFO}

# Fecha y hora (UTC -5 / Perú)
DATE_HOUR_GIT=$(date -u -d "-5 hours" "+%Y-%m-%d_%H:%M:%S" 2>/dev/null \
  || TZ="America/Lima" date "+%Y-%m-%d_%H:%M:%S" 2>/dev/null \
  || date "+%Y-%m-%d_%H:%M:%S")


# ──────────────────────────────────────────────
#  COLORES
# ──────────────────────────────────────────────
Color_Off='\033[0m'
Black='\033[0;30m';   BBlack='\033[1;30m'
Red='\033[0;31m';     BRed='\033[1;31m'
Green='\033[0;32m';   BGreen='\033[1;32m'
Yellow='\033[0;33m';  BYellow='\033[1;33m'
Blue='\033[0;34m';    BBlue='\033[1;34m'
Purple='\033[0;35m';  BPurple='\033[1;35m'
Cyan='\033[0;36m';    BCyan='\033[1;36m'
White='\033[0;37m';   BWhite='\033[1;37m'
Gray='\033[0;90m';    BGray='\033[1;90m'

# ──────────────────────────────────────────────
#  HELPERS DE UI
# ──────────────────────────────────────────────

_line() {
  echo -e "${BGray}──────────────────────────────────────────────${Color_Off}"
}

_title() {
  echo -e ""
  echo -e "${BBlue}          _ _    __     _       _       ${Color_Off}"
  echo -e "${BBlue}         (_) |  / _|   | |     | |      ${Color_Off}"
  echo -e "${BBlue}     __ _ _| |_| |_ ___| |_ ___| |__    ${Color_Off}"
  echo -e "${BBlue}    / _\` | | __|  _/ _ \\ __/ __| '_\\   ${Color_Off}"
  echo -e "${BBlue}   | (_| | | |_| ||  __/ || (__| | | |  ${Color_Off}"
  echo -e "${BBlue}    \\__, |_|\\__|_| \\___|\\__\\___|_| |_|  ${Color_Off}"
  echo -e ""
}

_menu_item() {
  local num="$1"
  local label="$2"
  local cmd="$3"
  echo -e "  ${BYellow}[$num]${Color_Off} ${BWhite}${label}${Color_Off}"
  echo -e "       ${Gray}→ ${Cyan}${cmd}${Color_Off}"
  echo -e ""
}

_run_cmd() {
  local cmd="$1"
  echo -e ""
  _line
  echo -e " ${BGreen}▶ Ejecutando:${Color_Off} ${BCyan}${cmd}${Color_Off}"
  _line
  echo -e ""
  sleep 1
  # GIT_PAGER=cat evita que git diff/log abran 'less',
  # que al cerrarse borra la salida del terminal
  GIT_PAGER=cat eval "$cmd"
  local exit_code=$?
  echo -e ""
  _line
  if [[ $exit_code -eq 0 ]]; then
    echo -e " ${BGreen}✓ Comando finalizado${Color_Off}"
  else
    echo -e " ${BRed}✗ El comando terminó con error (código: ${exit_code})${Color_Off}"
  fi
  _line
  echo -e ""
}


# ──────────────────────────────────────────────
#  MENÚ PRINCIPAL
# ──────────────────────────────────────────────

function gitfetch() {

  # Detectar rama remota actual
  local CURRENT_BRANCH
  CURRENT_BRANCH="$(git rev-parse --abbrev-ref HEAD 2>/dev/null)"

  if [[ -z "$CURRENT_BRANCH" ]]; then
    echo -e "\n ${BRed}✗ No estás dentro de un repositorio git.${Color_Off}\n"
    return 1
  fi

  local REMOTE_REF="origin/${CURRENT_BRANCH}"

  while true; do
    clear
    _title

    echo -e "  ${BGray}Repositorio:${Color_Off} ${BPurple}$(basename "$(git rev-parse --show-toplevel)")${Color_Off}"
    echo -e "  ${BGray}Rama actual:${Color_Off} ${BGreen}${CURRENT_BRANCH}${Color_Off}   ${BGray}Remote:${Color_Off} ${Yellow}${REMOTE_REF}${Color_Off}"
    echo -e ""
    _line
    echo -e "  ${BWhite}¿Qué deseas hacer?${Color_Off}"
    _line
    echo -e ""

    _menu_item "1" "Descargar cambios del remoto" \
               "git fetch"

    _menu_item "2" "Ver commits descargados (no aplicados aún)" \
               "git log --oneline HEAD..${REMOTE_REF}"

    _menu_item "3" "Ver diferencia de contenido con el remoto" \
               "git diff HEAD ${REMOTE_REF}"

    _menu_item "4" "Ver diff de un archivo específico" \
               "git diff HEAD ${REMOTE_REF} -- <archivo>"

    _menu_item "5" "Fusionar cambios del remoto (merge)" \
               "git merge ${REMOTE_REF}"

    _menu_item "6" "Fetch + ver commits + fusionar (todo en uno)" \
               "git fetch && git log --oneline HEAD..${REMOTE_REF} && git merge ${REMOTE_REF}"

    echo -e "  ${BRed}[0]${Color_Off} ${White}Salir${Color_Off}"
    echo -e ""
    _line
    echo -en "  ${BYellow}Elige una opción: ${Color_Off}"
    read -r opcion

    case "$opcion" in

      1)
        _run_cmd "git fetch"
        # Actualizar rama remota después del fetch
        REMOTE_REF="origin/${CURRENT_BRANCH}"
        ;;

      2)
        _run_cmd "git log --oneline HEAD..${REMOTE_REF}"
        ;;

      3)
        _run_cmd "git diff HEAD ${REMOTE_REF}"
        ;;

      4)
        echo -e ""
        echo -en "  ${Yellow}Ingresa el path del archivo ${Gray}(ej: src/auth.js)${Yellow}: ${Color_Off}"
        read -r archivo
        if [[ -z "$archivo" ]]; then
          echo -e "\n  ${BRed}✗ No ingresaste ningún archivo.${Color_Off}\n"
        else
          _run_cmd "git diff HEAD ${REMOTE_REF} -- ${archivo}"
        fi
        ;;

      5)
        echo -e ""
        echo -e "  ${BYellow}⚠ Esto fusionará ${REMOTE_REF} en tu rama ${CURRENT_BRANCH}.${Color_Off}"
        echo -en "  ${White}¿Confirmar? ${Gray}(s/n): ${Color_Off}"
        read -r confirm
        if [[ "$confirm" =~ ^[sS]$ ]]; then
          _run_cmd "git merge ${REMOTE_REF}"
        else
          echo -e "\n  ${Gray}Cancelado.${Color_Off}\n"
        fi
        ;;

      6)
        echo -e ""
        echo -e "  ${BCyan}Ejecutando flujo completo: fetch → log → merge${Color_Off}"
        _run_cmd "git fetch"
        echo -e "  ${BWhite}Commits nuevos:${Color_Off}"
        _run_cmd "git log --oneline HEAD..${REMOTE_REF}"
        echo -en "  ${BYellow}¿Fusionar ahora? ${Gray}(s/n): ${Color_Off}"
        read -r confirm
        if [[ "$confirm" =~ ^[sS]$ ]]; then
          _run_cmd "git merge ${REMOTE_REF}"
        else
          echo -e "\n  ${Gray}Merge cancelado. Fetch realizado.${Color_Off}\n"
        fi
        ;;

      0)
        echo -e "\n  ${BGray}Saliendo del menú git fetch. 👋${Color_Off}\n"
        break
        ;;

      *)
        echo -e "\n  ${BRed}✗ Opción inválida. Intenta de nuevo.${Color_Off}\n"
        sleep 1
        ;;
    esac

    echo -en "  ${Gray}Presiona ENTER para volver al menú...${Color_Off}"
    read -r
  done
}


# ──────────────────────────────────────────────
#  HELPERS INTERNOS
# ──────────────────────────────────────────────

# Recarga la fecha/hora actual en Perú
function reload_date() {
  DATE_HOUR_GIT=$(date -u -d "-5 hours" "+%Y-%m-%d_%H:%M:%S" 2>/dev/null \
    || TZ="America/Lima" date "+%Y-%m-%d_%H:%M:%S" 2>/dev/null \
    || date "+%Y-%m-%d_%H:%M:%S")
}

# Ejecuta un comando mostrándolo en amarillo antes de correrlo
run_command() {
  echo -e "${BYellow}${1}${Color_Off}" && sleep 1
  eval "$1"
}

# Retorna "1" si hay cambios sin commitear, "0" si no hay
fn_check_changes_repositor() {
  local out=$(git status -s | head -n 1)
  [[ -n "$out" ]] && echo "1" || echo "0"
}

# Retorna "1" si existe un remote llamado "origin2"
fn_check_remote_origin_2() {
  local out=$(git remote -v | grep origin2 | head -n 1)
  [[ -n "$out" ]] && echo "1" || echo "0"
}


# ──────────────────────────────────────────────
#  PROMPT - muestra rama + estado (limpio ✓ / cambios ✗)
# ──────────────────────────────────────────────
parse_git_branch() {
  git branch 2>/dev/null | grep '\*' | sed 's/* //'
}
parse_git_status() {
  [[ -n "$(git status --short 2>/dev/null)" ]] && echo " ✗" || echo " ✓"
}


# ──────────────────────────────────────────────
#  ALIAS - Básicos
# ──────────────────────────────────────────────
alias gst='git status -sb'             # estado resumido
alias gad='git add -A'                 # agregar todo
alias gch='git checkout'
alias gcob='git checkout -b'           # crear rama y moverse a ella
alias gsw='git switch'
alias gswc='git switch -c'
alias gbr='git branch'
alias gba='git branch -a'             # todas las ramas (locales + remotas)
alias gbd='git branch -d'             # borrar rama (seguro)
alias gbD='git branch -D'             # borrar rama (forzado)
alias gme='git merge'
alias grb='git rebase'
alias grbi='git rebase -i'            # rebase interactivo
alias grbc='git rebase --continue'
alias grba='git rebase --abort'
alias gpl='git pull --rebase'         # pull con rebase
alias gpu='git push'
alias gpf='git push --force-with-lease'  # push forzado (seguro)
alias gf='git fetch --all --prune'    # fetch + limpiar ramas muertas
alias gmt='git mergetool'
alias gd='git diff'
alias gds='git diff --staged'
alias bdf='git diff'
alias gcp='git cherry-pick'
alias gwip='git add -A && git commit -m "WIP: trabajo en progreso"'  # guardar rápido


# ──────────────────────────────────────────────
#  ALIAS - Log visual (gráfico)
# ──────────────────────────────────────────────

# Log compacto (1 línea por commit)
alias glg='git log --date-order --all --graph \
  --format="%C(green)%h%Creset %C(yellow)%an%Creset %C(blue bold)%ar%Creset %C(red bold)%d%Creset%s"'

# Log detallado (con archivos modificados)
alias glg2='git log --date-order --all --graph --name-status \
  --format="%C(green)%H%Creset %C(yellow)%an%Creset %C(blue bold)%ar%Creset %C(red bold)%d%Creset%s"'

# Log ultra compacto solo rama actual
alias gl='git log --oneline --graph --decorate'


# ──────────────────────────────────────────────
#  FUNCIONES - Commit interactivo
# ──────────────────────────────────────────────

#######################################
# Commit interactivo: pide mensaje, agrega info del equipo + fecha PE
# @example  gcm
#######################################
function gcm() {
  reload_date
  git add -A
  read -p 'Message commit: ' msg_commit
  git commit -m "${msg_commit} | ${MY_INFO} :${DATE_HOUR_GIT}"
}

#######################################
# Commit + push a master rápido (sin mensaje personalizado)
# @example  upgit
#######################################
function upgit() {
  reload_date
  git pull
  git add -A
  git commit -m "${MY_INFO} se actualizo :${DATE_HOUR_GIT}"
  git push -u origin master
}


# ──────────────────────────────────────────────
#  FUNCIONES - gitup (rama actual, con checks)
# ──────────────────────────────────────────────

#######################################
# Commit + push en la rama actual.
# - Detecta si hay cambios antes de operar
# - Soporta segundo remote (origin2 / GitHub)
# @example  gitup
# @since    2024
#######################################
function gitup() {
  reload_date
  echo -en "${Gray}[gitup]${Color_Off}\n" && sleep 1
  local CURRENT_BRANCH
  CURRENT_BRANCH="$(git rev-parse --abbrev-ref HEAD)"

  if [[ "1" == "$(fn_check_changes_repositor)" ]]; then
    echo -e "${Gray}Fecha: ${DATE_HOUR_GIT}${Color_Off}" && sleep 1

    run_command "git pull origin ${CURRENT_BRANCH}"
    run_command "git add -A"
    git commit -m "${MY_INFO} actualizó [${CURRENT_BRANCH}] :${DATE_HOUR_GIT}"
    run_command "git push origin ${CURRENT_BRANCH}"

    # Push a origin2 (GitHub u otro) si está configurado
    if [[ "1" == "$(fn_check_remote_origin_2)" ]]; then
      echo -en "\n${BYellow}Actualizando origin2: [${CURRENT_BRANCH}]${Color_Off}\n\n" && sleep 1
      run_command "git push origin2 ${CURRENT_BRANCH}"
    fi

  else
    echo -en "Sin cambios en [${BGreen}${CURRENT_BRANCH}${Color_Off}]\n" && sleep 2
  fi
}

#######################################
# Igual que gitup pero tú escribes el mensaje del commit.
# Si no escribes nada, usa el nombre de la rama como mensaje.
# @example  gitup2
# @since    2024
#######################################
function gitup2() {
  reload_date
  echo -en "${Gray}[gitup2]${Color_Off}\n" && sleep 1
  local CURRENT_BRANCH
  CURRENT_BRANCH="$(git rev-parse --abbrev-ref HEAD)"

  if [[ "1" == "$(fn_check_changes_repositor)" ]]; then
    echo -e "${Gray}Fecha: ${DATE_HOUR_GIT}${Color_Off}" && sleep 1
    run_command "git pull origin ${CURRENT_BRANCH}"

    printf "%b" "${Yellow}Descripción del commit (enter = nombre de rama): ${Color_Off}"
    read -r description_commit
    description_commit="${description_commit:-$CURRENT_BRANCH}"

    run_command "git add -A"
    git commit -m "${description_commit}"
    run_command "git push origin ${CURRENT_BRANCH}"

  else
    echo -en "Sin cambios en [${BGreen}${CURRENT_BRANCH}${Color_Off}]\n" && sleep 2
  fi
}


# ──────────────────────────────────────────────
#  FUNCIONES - Ramas específicas (qa / master)
# ──────────────────────────────────────────────

#######################################
# Commit + push a QA con mensaje personalizado
# @example  gitup-qa
#######################################
function gitup-qa() {
  reload_date
  git checkout qa && git pull
  git add -A
  read -p 'Message commit: ' msg_commit
  git commit -m "${msg_commit} | ${MY_INFO} :${DATE_HOUR_GIT}"
  git push origin qa
}

#######################################
# Commit + push a QA sin escribir mensaje (fast)
# @example  gitup-qa-fast
#######################################
function gitup-qa-fast() {
  reload_date
  git checkout qa && git pull
  git add -A
  git commit -m "fast commit | ${MY_INFO} :${DATE_HOUR_GIT}"
  git push origin qa
}

#######################################
# Commit + push a master
# @example  gitup-master
#######################################
function gitup-master() {
  reload_date
  git checkout master && git pull
  git add -A
  git commit -m "${MY_INFO} actualizó master :${DATE_HOUR_GIT}"
  git push origin master
}


# ──────────────────────────────────────────────
#  FUNCIONES - Utilidades extra
# ──────────────────────────────────────────────

#######################################
# Clonar repo y entrar al directorio automáticamente
# @example  gcl https://github.com/user/repo.git
#######################################
function gcl() {
  git clone "$1" && cd "$(basename "$1" .git)" || return
}

#######################################
# Push de rama nueva al origin con tracking (-u)
# @example  gpush
#######################################
function gpush() {
  local branch
  branch=$(git branch --show-current)
  git push -u origin "$branch"
}

#######################################
# Borrar rama local Y remota a la vez
# @example  gbrm feature/login
#######################################
function gbrm() {
  git branch -d "$1"
  git push origin --delete "$1"
  echo "✓ Rama '$1' eliminada local y remotamente"
}

#######################################
# Deshacer N commits conservando los cambios en staging
# @example  gundo      → deshace 1 commit
# @example  gundo 3    → deshace 3 commits
#######################################
function gundo() {
  git reset --soft HEAD~"${1:-1}"
  echo "✓ ${1:-1} commit(s) deshecho(s). Cambios en staging."
}

#######################################
# Limpiar ramas locales ya mergeadas en main/master
# @example  gclean
#######################################
function gclean() {
  git branch --merged main   2>/dev/null | grep -v "^\*\|main\|master\|dev" | xargs -r git branch -d
  git branch --merged master 2>/dev/null | grep -v "^\*\|main\|master\|dev" | xargs -r git branch -d
  echo "✓ Ramas mergeadas eliminadas."
}

#######################################
# Buscar commits por texto en el mensaje
# @example  ggrep "login"
#######################################
function ggrep() {
  git log --all --oneline --grep="$1"
}

#######################################
# Buscar commits que modificaron cierta cadena en el CÓDIGO
# @example  gpickaxe "nombre_funcion"
#######################################
function gpickaxe() {
  git log -S "$1" --oneline --all
}

#######################################
# Resumen rápido del estado del repo
# @example  ginfo
#######################################
function ginfo() {
  echo "── Rama actual ──────────────────"
  git branch --show-current
  echo "── Último commit ────────────────"
  git log -1 --pretty=format:"%h  %s  (%cr)  <%an>"
  echo -e "\n── Estado ───────────────────────"
  git status -sb
  echo "── Stashes ──────────────────────"
  git stash list
}

#######################################
# Crear tag anotado y hacer push
# @example  gtpush v1.0.0
# @example  gtpush v1.0.0 "Release estable"
#######################################
function gtpush() {
  git tag -a "$1" -m "${2:-Release $1}"
  git push origin "$1"
  echo "✓ Tag '$1' creado y enviado."
}

#######################################
# Sincronizar fork con su upstream
# @example  gsync
#######################################
function gsync() {
  local branch
  branch=$(git branch --show-current)
  git fetch upstream
  git rebase upstream/"$branch"
  git push origin "$branch"
}