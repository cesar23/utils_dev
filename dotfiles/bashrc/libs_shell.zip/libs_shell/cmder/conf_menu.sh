#!/bin/bash

# Colores Regulares
Color_Off='\e[0m'       # Reset de color.
Black='\e[0;30m'        # Negro.
Red='\e[0;31m'          # Rojo.
Green='\e[0;32m'        # Verde.
Yellow='\e[0;33m'       # Amarillo.
Blue='\e[0;34m'         # Azul.
Purple='\e[0;35m'       # Púrpura.
Cyan='\e[0;36m'         # Cian.
White='\e[0;37m'        # Blanco.
Gray='\e[0;90m'         # Gris.

# Colores en Negrita
BBlack='\e[1;30m'       # Negro (negrita).
BRed='\e[1;31m'         # Rojo (negrita).
BGreen='\e[1;32m'       # Verde (negrita).
BYellow='\e[1;33m'      # Amarillo (negrita).
BBlue='\e[1;34m'        # Azul (negrita).
BPurple='\e[1;35m'      # Púrpura (negrita).
BCyan='\e[1;36m'        # Cian (negrita).
BWhite='\e[1;37m'       # Blanco (negrita).
BGray='\e[1;90m'        # Gris (negrita).


# ================== Función personalizada 'cesar' ==================
function cesar() {
    echo ""
   echo -e "${Red} ▄████▄  ▓█████   ██████  ▄▄▄       ██▀███         ▄▄▄${Color_off}"
   echo -e "${Red}▒██▀ ▀█  ▓█   ▀ ▒██    ▒ ▒████▄    ▓██ ▒ ██▒      ▒████▄${Color_off}"
   echo -e "${Red}▒▓█    ▄ ▒███   ░ ▓██▄   ▒██  ▀█▄  ▓██ ░▄█ ▒      ▒██  ▀█▄${Color_off}"
   echo -e "${Red}▒▓▓▄ ▄██▒▒▓█  ▄   ▒   ██▒░██▄▄▄▄██ ▒██▀▀█▄        ░██▄▄▄▄██${Color_off}"
   echo -e "${Red}▒ ▓███▀ ░░▒████▒▒██████▒▒ ▓█   ▓██▒░██▓ ▒██▒  ██▓  ▓█   ▓██▒${Color_off}"
   echo -e "${Red}░ ░▒ ▒  ░░░ ▒░ ░▒ ▒▓▒ ▒ ░ ▒▒   ▓▒█░░ ▒▓ ░▒▓░  ▒▓▒  ▒▒   ▓▒█░${Color_off}"
   echo -e "${Red}  ░  ▒    ░ ░  ░░ ░▒  ░ ░  ▒   ▒▒ ░  ░▒ ░ ▒░  ░▒    ▒   ▒▒ ░${Color_off}"
   echo -e "${Red}░           ░   ░  ░  ░    ░   ▒     ░░   ░   ░     ░   ▒${Color_off}"
   echo -e "${Red}░ ░         ░  ░      ░        ░  ░   ░        ░        ░  ░${Color_off}"
    echo ""

    # Sección de comandos útiles
    echo -e "${Blue}** Favorite commands Cesar **${Color_off}"
    echo -e "${Yellow}IP Public: ${COLORS[OFF]}curl checkip.amazonaws.com${Color_off}"
    echo -e "${Yellow}Menus: ${COLORS[OFF]}menu${Color_off}"
    echo -e "${Yellow}Reload script: ${COLORS[OFF]}cesar${Color_off}"
    echo -e "${Blue}System Info: ${COLORS[OFF]}neofetch${Color_off}"
    echo ""
}