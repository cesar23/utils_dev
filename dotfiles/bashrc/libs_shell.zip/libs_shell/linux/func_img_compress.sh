#!/bin/bash
# ----------------------------------------------------------
# SCRIPT DE OPTIMIZACIÓN DE IMÁGENES
# Este script busca y optimiza imágenes JPG, JPEG y PNG
# en el directorio especificado o en el actual si no se pasa un argumento.
#
# DEPENDENCIAS NECESARIAS:
# 1. jpegoptim (para JPG/JPEG)
# 2. pngquant (para PNG)
#
# INSTALACIÓN DE DEPENDENCIAS:
# sudo apt update
# sudo apt install jpegoptim pngquant -y
#
# MODO DE USO:
# ./compress_img.sh <directorio>
# Ejemplo:
# ./compress_img.sh '/ruta/a/imagenes'
# Si no se pasa un directorio, se usa el actual por defecto.
# ----------------------------------------------------------

# =============================================================================
# 🏆 SECTION: Configuración Inicial
# =============================================================================
# Variables de configuración iniciales
DATE_HOUR="$(date +%Y-%m-%d_%H:%M:%S)"  # Fecha y hora actuales en formato YYYY-MM-DD_HH:MM:SS.
CURRENT_USER=$(id -un)             # Nombre del usuario actual.
CURRENT_PC_NAME=$(hostname)        # Nombre del equipo actual.
MY_INFO="${CURRENT_USER}@${CURRENT_PC_NAME}"  # Información combinada del usuario y del equipo.
PATH_SCRIPT=$(readlink -f "${BASH_SOURCE:-$0}")  # Ruta completa del script actual.
SCRIPT_NAME=$(basename "$PATH_SCRIPT")           # Nombre del archivo del script.
CURRENT_DIR=$(dirname "$PATH_SCRIPT")            # Ruta del directorio donde se encuentra el script.
# =============================================================================
# 🎨 SECTION: Colores para su uso
# =============================================================================
# Definición de colores que se pueden usar en la salida del terminal.

# Colores Regulares
Color_Off='\e[0m'       # Reset de color.
Black='\e[0;30m'        # Negro.
Red='\e[0;31m'          # Rojo.
Green='\e[0;32m'        # Verde.
Yellow='\e[0;33m'       # Amarillo.
Blue='\e[0;34m'         # Azul.
Purple='\e[0;35m'       # Púrpura.
Cyan='\e[0;36m'         # Cian.
White='\e[0;37m'        # Blanco.
Gray='\e[0;90m'         # Gris.




# =============================================================================
# 🔥 SECTION: Main Code
# =============================================================================

optimize_img_dir (){


  # Establece la codificación a UTF-8 para evitar problemas con caracteres especiales.

  # Variables de configuración iniciales
  DIRECTORIO="${1:-.}"                    # Directorio raíz (por defecto, el actual).
  LOG_FILE="optimized_files.log"          # Archivo de registro.
  LOG_FILE_PATH="${CURRENT_DIR}/$LOG_FILE"



  # Crear archivo de registro si no existe
  if [ ! -f "$LOG_FILE" ]; then
      touch "$LOG_FILE_PATH"
      echo -e "${Yellow}Archivo de registro creado: ${LOG_FILE}${Color_Off}"
  fi

  echo -e "${Cyan}Iniciando optimización de imágenes en: ${DIRECTORIO}${Color_Off}"

  # =============================================================================
  # 🎨 SECTION: Funciones
  # =============================================================================

  # Verifica si el archivo ya fue optimizado
  ya_optimizado() {
      # Convierte la ruta a absoluta para evitar problemas
      archivo_absoluto=$(realpath "$1")
      # Busca exactamente la ruta en el archivo de registro
      echo -e "${Gray}Buscando en el registro: $(realpath "$1")"
      # Busca exactamente la ruta en el archivo de registro, ignorando la marca de tiempo
      grep -E "^\[.*\] $archivo_absoluto$" "$LOG_FILE_PATH" > /dev/null
  }

  # Función para optimizar archivos JPG/JPEG
  optimizar_jpg() {
      echo -e "${Blue}Buscando archivos JPG/JPEG...${Color_Off}"
      find "$DIRECTORIO" -type f \( -iname "*.jpg" -o -iname "*.jpeg" \) | while read -r archivo; do
          if ya_optimizado "$archivo"; then
              echo -e "${Yellow}Ya optimizado (JPG/JPEG): $archivo${Color_Off}" # Aquí puedes usar -e si tienes colores
          else
              echo -e "${Gray}Optimizando JPG/JPEG: $archivo${Color_Off}"
              jpegoptim --strip-all --max=85 "$archivo"
              if [ $? -eq 0 ]; then
                  echo -e "${Green}✔ Archivo optimizado: $archivo${Color_Off}"
                  echo "[$(date +%Y-%m-%d_%H:%M:%S)] $archivo_absoluto" >>"$LOG_FILE_PATH"
              else
                  echo -e "${Red}✖ Error al optimizar: $archivo${Color_Off}"
              fi
          fi
      done
  }

  # Función para optimizar archivos PNG
  optimizar_png() {
      echo -e "${Blue}Buscando archivos PNG...${Color_Off}"
      find "$DIRECTORIO" -type f -iname "*.png" | while read -r archivo; do
          if ya_optimizado "$archivo"; then
              echo -e "${Yellow}Ya optimizado (PNG): $archivo${Color_Off}"
          else
              echo -e "${Gray}Optimizando PNG: $archivo${Color_Off}"
              pngquant --force --ext .png --quality=65-80 "$archivo"
              if [ $? -eq 0 ]; then
                  echo -e "${Green}✔ Archivo optimizado: $archivo${Color_Off}"
                  echo "[$(date +%Y-%m-%d_%H:%M:%S)] $(realpath "$archivo")" >>"$LOG_FILE_PATH"
              else
                  echo -e "${Red}✖ Error al optimizar: $archivo${Color_Off}"
              fi
          fi
      done
  }

  # =============================================================================
  # 🎨 SECTION: Ejecución
  # =============================================================================

  optimizar_jpg
  optimizar_png

  echo -e "${Green}✔ Optimización completada.${Color_Off}"
  echo -e "${Blue}✔ historial de ficheros optimizados: ${LOG_FILE_PATH}${Color_Off}"
}
