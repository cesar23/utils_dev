#!/bin/bash
# 🎗️🎖️⛏️⚒️🛠️⚙️🏷️🗂️⏱️🛸⛱️❤️‼️✔️☢️☣️⚠️🗓️🧱🧬🪛🗝️🕹️🎗️✌️👁️ℹ️Ⓜ️☄️🌨️🌩️🌦️🌤️🏚️
#  ver ccolores en repo linux => Colores/1_generar_colores.sh
function neofetch() {
  "${CURRENT_TERMINAL_SCRIPTS}/neofeth.sh" --ascii_distro Arch
#   ~/neofeth.sh --ascii_distro Arch
#   ~/neofeth.sh --ascii_distro Arch
}
