# ----------------------------- INICIO DEL SCRIPT ---------------------------------

# ================== Instalación de herramientas ==================
# Para Windows, instala las siguientes herramientas usando Chocolatey:
# choco install fzf        # Fuzzy finder
# choco install bat        # Cat mejorado con resaltado de sintaxis

# Para Ubuntu/Debian, usa el siguiente comando para instalar las herramientas:
# sudo apt install fzf      # Fuzzy finder
# sudo apt install bat      # En Ubuntu 'bat' se usa como 'batcat'

# ================== Aliases ==================
# Alias para usar 'batcat' como 'bat' en lugar de 'batcat'
alias bat="batcat"

# ------------------------- Funciones útiles -------------------------

# sd - Función para buscar y cambiar directorios recursivamente usando fzf
# Ejemplo de uso:
#   sd         # Busca directorios en el directorio actual y navega entre ellos.
#   sd /path   # Busca directorios dentro de /path.
function sd() {
  local dir
  # Busca directorios en el directorio actual o en el especificado, luego usa fzf para seleccionar uno.
  dir=$(find "${1:-.}" -type d 2> /dev/null | fzf +m) && cd "$dir"
}

# sde - Función que permite navegar entre directorios como un explorador de Windows
# Ejemplo de uso:
#   sde       # Navega entre directorios, incluyendo opción para retroceder con ".."
function sde() {
  # Configuración de fzf
  export FZF_DEFAULT_OPTS="--height 40% --layout=reverse --border"
  bind '"\C-r": " \C-a\C-k\C-r\C-y\ey\C-m"'

    while true; do
        # Usa un array para manejar correctamente directorios con espacios
        dirs=("..")

        # Añade los directorios a la lista
        while IFS= read -r -d $'\0' dir; do
            dirs+=("$dir")
        done < <(find . -maxdepth 1 -type d -print0)

        # Usa fzf para seleccionar un directorio, manejando correctamente los nombres con espacios
        dir=$(printf "%s\n" "${dirs[@]}" | fzf --header "Selecciona un directorio ('..' para retroceder)")

        if [[ -n "$dir" ]]; then
          if [[ "$dir" == ".." ]]; then
            cd ..
          else
            cd "$dir"
          fi
         echo -e "${Gray}Estás en: $(pwd)" # Muestra la ruta actual
        else
          break  # Sale del bucle si no se selecciona nada
        fi
    done

}

# sf - Función para buscar archivos excluyendo carpetas y tipos de ficheros específicos
# Ejemplo de uso:
#   sf        # Busca archivos excluyendo ficheros no deseados y los abre en nvim
function sf() {
  export FZF_DEFAULT_OPTS="--height 100% --layout=reverse --border"
  bind '"\C-r": " \C-a\C-k\C-r\C-y\ey\C-m"'

  # Verificar si fzf está instalado
  if which fzf > /dev/null; then
    # Encuentra archivos, excluyendo carpetas y tipos de ficheros no deseados
    find . -type d \( -iname '$RECYCLE.BIN' -o \
                      -iname '.git' -o \
                      -iname 'node_modules' -o \
                      -iname 'dist' \) -prune -o -type f \( -not -iname '*.dll' -a \
                                                            -not -iname '*.exe' \) -print \
    | fzf --preview 'batcat --style=numbers --color=always --line-range :500 {}' \
    | xargs -r nvim  # Abre el archivo seleccionado en nvim
  else
    echo "fzf no está instalado."
  fi
}

# sff - Función para buscar archivos sin omitir ningún fichero o carpeta
# Ejemplo de uso:
#   sff       # Busca cualquier archivo en el directorio actual y lo abre en nvim
function sff() {
  export FZF_DEFAULT_OPTS="--height 100% --layout=reverse --border"
  bind '"\C-r": " \C-a\C-k\C-r\C-y\ey\C-m"'

  # Verificar si fzf está instalado
  if which fzf > /dev/null; then
    # Busca todos los archivos sin restricciones
    find . -print \
    | fzf --preview 'batcat --style=numbers --color=always --line-range :500 {}' \
    | xargs -r nvim  # Abre el archivo seleccionado en nvim
  else
    echo "fzf no está instalado."
  fi
}


# ----------------------------- FIN DEL SCRIPT ---------------------------------
