#!/bin/bash
DATE_HOUR_GIT="`date +%Y`-`date +%m`-`date +%d`_`date +%H`:`date +%M`:`date +%S`"
DATE_HOUR_GIT_PE=$(date -u -d "-5 hours" "+%Y-%m-%d_%H:%M:%S" 2>/dev/null || TZ="America/Lima" date "+%Y-%m-%d_%H:%M:%S" 2>/dev/null || echo "$DATE_HOUR")
CURRENT_USER=$(id -un)             # Nombre del usuario actual.
CURRENT_PC_NAME=$(hostname)        # Nombre del equipo actual.
MY_INFO="${CURRENT_USER}@${CURRENT_PC_NAME}"  # Información combinada del usuario y del equipo.
INFO_PC=${INFO_PC:-$MY_INFO}


run_command(){
  local param_1=$1
  echo -e "${BYellow}${param_1}${Color_Off}" && sleep 1
  eval "$param_1"
}

# function dir_gspMarino(){
#   cd C:\\laragon\\www\\gspmarinov1
# }
# TODO ddsd
# function dir_gspTerrestre(){
#   cd C:\\laragon\\www\\gsptrackv1
# }
# function dir_cursoReact(){
#   cd C:\\Users\\Cesar\\cesar\\curso_ReacJs
# }

# function dir_aws(){
#   cd C:\\Users\\Cesar\\cesar\\aws
# }

# function dir_projectTerrestre(){
#   cd C:\\laragon\\www\\project_terrestre_node
# }

#######################################
# setea la hora de la variables globales
# @author Cesar Auris
# @return void
# @param name sin referencia
# @version 0.1 2022-03-04
#######################################
function reload_date(){
  DATE_HOUR="`date +%d`/`date +%m`/`date +%Y` - `date +%H`:`date +%M`:`date +%S`"
  DATE_HOUR_GIT="`date +%Y`-`date +%m`-`date +%d`_`date +%H`:`date +%M`:`date +%S`"
}

#######################################
# @description convierte path de shella  windows
# @author Cesar Auris
# @return object
# @param name $1
# @example path_shell_to_path_windows '/c/Desktop/proyecto-tracking/NonFood'
# @version 0.1 2022-03-04
#######################################
function path_shell_to_path_windows (){
    local PATH_REPO=$1
    local result

  # --------- para Cmder
# result=$(echo "${PATH_REPO}" | sed -r -e 's/^\/drives\/([a-zA-Z])+\/(.*)/\/\1\/\2/')
# result=$(echo "${result}" | sed "s/\//\\\\/g")
# result=$(echo "${result}" | sed -r -e 's/^\\([a-zA-Z])+\\(.*)$/\1:\\\2/')

  # --------- para Mobax
  result=$(echo "${PATH_REPO}" | sed -r -e 's@^/drives/([a-zA-Z]+)/(.*)@/\1/\2@')
  result=$(echo "${result}" | sed "s@/@\\\\@/g")
  result=$(echo "${result}" | sed -r -e 's@^\\([a-zA-Z]+)\\(.*)$@\1:\\2@')

  echo "$result"
}

#######################################
# @description convierte un path windows a  shell
# @author Cesar Auris
# @return object
# @param name $1
# @example path_windows_to_path_shell "D:\repos\test_repos"
# @version 0.1 2022-03-04
#######################################
#function path_windows_to_path_shell (){
function path_windows_to_path_shell (){
    local PATH_REPO=$1

    if [[ -z "$PATH_REPO" ]]; then
        echo "Error: Debes proporcionar una ruta en formato Windows." >&2
        return 1
    fi

    # Convertir letra de unidad y backslashes a formato Unix
    local path_unix=$(echo "${PATH_REPO}" | sed 's|^\([A-Za-z]\):|/\L\1|;s|\\|/|g')

    if [[ -d "/mnt/c" ]]; then
      #  aqui convertir ejemplo: C:\laragon
      # a /mnt/c/laragon
        path_unix=$(echo "$PATH_REPO" | sed 's|^\([A-Za-z]\):|/mnt/\L\1|;s|\\|/|g')
        echo "$path_unix"
    else
        echo "$path_unix"
    fi
}



#######################################
# @description pasa como parametro un path windows y se ubica con cd en el directorio
# @author Cesar Auris
# @return void
# @param name sin referencia
# @example cds 'D:\repos\test_repos'
# @version 0.1 2022-03-04
#######################################
function cds (){
  typeset dir
    echo -en "${BIPurple}Paste Directory Path: ${Color_Off}"
    # printf "Paste Directory Path: "
    read -r dir || return
    # cd ${dir:?}

    # read -p "Ingresa path windows: " path_dir
    PATH_WINDOWS=$(path_windows_to_path_shell  "${dir}")
    cd "${PATH_WINDOWS}"
}



function login() {
  read -p 'Username: ' uservar
  read -sp 'Password: ' passvar
  echo ""
  echo "Thankyou ${uservar} tu passwork es:${passvar}"
}
#:: para  hacer commit en git
function gcm() {
    # ::-- start -- actualizar fecha y hora
    reload_date
    # ::-- end -- actualizar fecha y hora
	  git add -A
    read -p 'Message commit: ' msg_commit
    git commit -m "${msg_commit} | ${MY_INFO} se actualizo :${DATE_HOUR_GIT}"
    # git push -u origin master
}


function upgit() {
	git pull
    git add -A
    git commit -m "${MY_INFO} se actualizo :${DATE_HOUR_GIT}"
    git push -u origin master
}

function path_file_weight_human() {
    local file=$1
    local weight=$(du -h "$file" | cut -f1)
    echo $weight
}

function verifi_peso_files_gitup(){
  local resultado_find
  # Guardar el resultado de find en una variable
  resultado_find=$(find . -type f -not -path './.git/*' -size +50M)

  local found_file=0
  # Recorder cada elemento en el resultado
  IFS=$'\n' # Configurar el separador de campos para que sea solo una nueva línea
  for archivo in $resultado_find; do
      # Aquí puedes hacer lo que quieras con cada archivo
      local PESO_DIR=$(path_file_weight_human "${archivo}")
      echo "Procesando archivo: ${archivo} (peso: ${PESO_DIR})"
      # Agrega cualquier otra operación que desees realizar con el archivo aquí
      found_file=1
  done

  echo "$found_file"

}

#######################################
# @description (Utilizado mis nomalmente) este scrtip hara un commit y un push en la rama actual. con fecha actual y descripciond e la pc
# @author Cesar Auris
# @return void
# @example
# @since   2024-13-19
#######################################
function gitup() {
  echo -en "${Gray}[script core]${Color_Off} \n" && sleep 3
  CURRENT_BRANCH="$(git rev-parse --abbrev-ref HEAD)"
  if [ "1" == "$( fn_check_changes_repositor )" ]
  then
         local DATE_HOUR_GIT_PE=$(date -u -d "-5 hours" "+%Y-%m-%d_%H:%M:%S" 2>/dev/null || TZ="America/Lima" date "+%Y-%m-%d_%H:%M:%S" 2>/dev/null || echo "$DATE_HOUR")
         echo -e "${Gray}Fecha de commit: ${DATE_HOUR_GIT_PE}${Color_Off}" && sleep 1

         run_command "git pull origin ${CURRENT_BRANCH}"

         run_command "git add -A"

         git commit -m "${MY_INFO} se actualizo rama ${CURRENT_BRANCH} :${DATE_HOUR_GIT_PE}"

         run_command "git push origin ${CURRENT_BRANCH}"

         #------- Verificamos si extiste un segundo repositorio ------
         if [ "1" == "$( fn_check_remote_origin_2 )" ]
         then
            echo -en "\nActualizando Repositorio ${BYellow}Github : [${CURRENT_BRANCH}]${Color_Off} \n\n" && sleep 2
            run_command "git push origin2 ${CURRENT_BRANCH}"
         fi

  else
     echo -en "No se encontraron cambios en rama actual: [${BGreen}${CURRENT_BRANCH}${Color_Off}] \n" && sleep 3
  fi

}

#######################################
# @description (Utilizado para trabajos) este scrtiphara un commit y un push en la rama actual. el commit sera el mismo nombre de la rama
# @author Cesar Auris
# @return void
# @example
# @since   2024-13-19
#######################################
function gitup2() {
  echo -en "${Gray}[script core]${Color_Off} \n" && sleep 3
  CURRENT_BRANCH="$(git rev-parse --abbrev-ref HEAD)"
  if [ "1" == "$( fn_check_changes_repositor )" ]
  then
         local DATE_HOUR_GIT_PE=$(date -u -d "-5 hours" "+%Y-%m-%d_%H:%M:%S" 2>/dev/null || TZ="America/Lima" date "+%Y-%m-%d_%H:%M:%S" 2>/dev/null || echo "$DATE_HOUR")

         # :::::::::::::: 1. traer Data
         echo -e "${Gray}Fecha de commit: ${DATE_HOUR_GIT_PE}${Color_Off}" && sleep 1
         run_command "git pull origin ${CURRENT_BRANCH}"


         # Print colored prompt first (so escapes are interpreted), then read input
         if [[ -n "${Yellow}" ]]; then
           printf "%b" "${Yellow}Ingrese description Commit: ${Color_Off}"
         else
           printf "%b" $'\e[33mIngrese description Commit: \e[0m'
         fi
         read -r description_commit
         description_commit="${description_commit:-$CURRENT_BRANCH}"

         # :::::::::::::: 3. Enviar Commit y push
         run_command "git add -A"

         git commit -m "$description_commit"
         # push: ensure git is present in the command
         run_command "git push origin ${CURRENT_BRANCH}"
         #git push origin "$CURRENT_BRANCH"

  else
     echo -en "No se encontraron cambios en rama actual: [${BGreen}${CURRENT_BRANCH}${Color_Off}] \n" && sleep 3
  fi

}
# verificar si hay cambios en repositorio
function fn_check_changes_repositor(){
  #file_temp="${TMP}/temp_git_$(date +%s).tmp"
  OUT_GIT_STATUS=$( git status -s |  head -n 1 )
  if [ -n "$OUT_GIT_STATUS" ]
  then
      echo "1"
  else
      echo "0"
  fi
}
function fn_check_remote_origin_2(){
  OUT_GIT_STATUS=$( git remote -v | grep origin2 | head -n 1 )
  if [ -n "$OUT_GIT_STATUS" ]
  then
      echo "1"
  else
      echo "0"
  fi
}

function gitup-qa() {
    # ::-- start -- actualizar fecha y hora
    reload_date
    # ::-- end -- actualizar fecha y hora
    git checkout qa
    git pull
	  git add -A
    read -p 'Message commit: ' msg_commit
    git commit -m "${msg_commit} | ${MY_INFO} se actualizo :${DATE_HOUR_GIT}"
    # git push -u origin master
    git push origin qa
}
function gitup-qa-fast() {
    # ::-- start -- actualizar fecha y hora
    reload_date
    # ::-- end -- actualizar fecha y hora
    git checkout qa
    git pull
    git add -A
    git commit -m "commit fast| ${MY_INFO} se actualizo :${DATE_HOUR_GIT}"
    # git push -u origin master
    git push origin qa
}
function gitup-master() {
      # ::-- start -- actualizar fecha y hora
    reload_date
    # ::-- end -- actualizar fecha y hora
    git checkout master
    git pull
	  git add -A
    git commit -m "se actualizo :${DATE_HOUR_GIT}"
    # git push -u origin master
    git push master
}



function clo (){
  current_dir_this=$(pwd)
  read -p 'ingrese  repo: ' git_repo

  # Set comma as delimiter
  IFS='@'

  read -a strarr <<< "$git_repo"
  #cogemos el path ultimo
  REPO_DIR="${strarr[1]}"
  
  PATH_REPO="${current_dir_this}/${REPO_DIR}"  
  PATH_WINDOWS=$(path_shell_to_path_windows  "${PATH_REPO}") 

  
  echo "PATH_REPO: ${PATH_REPO}"
  echo "PATH_WINDOWS: ${PATH_WINDOWS}"
      if [ -d $PATH_WINDOWS ] 
        then
            
            echo "------------------El repo ya  existe-----------------------------"
            echo "PATH_REPO: ${PATH_REPO}"
    
        else

            echo "------------------clonando-----------------------------"
              $git_repo
              sleep 2
              cd $PATH_REPO
              git checkout qa
              sleep 2
              pwd
              cd ..
          clear
      fi

  # cd $REPO_DIR
  # git checkout qa
  # sleep 2
  # pwd
  # cd ..
}


#######################################
# @descripcion
# @author Cesar Auris
# @return array
# @param name sin referencia
# @version 0.1 2022-03-04
#######################################

function fn_str_length() {
  #----paranmetros
  PARAM_1=$1
  #---variables
  STRLENGTH=$(echo -n $PARAM_1 | wc -m)
  printf $STRLENGTH
}

function fn_spaces(){
  #----paranmetros
  PARAM_1=$1

  STRLENGTH=$(fn_str_length $PARAM_1 )
  for i in $(seq 0 $STRLENGTH); do
  printf " "
  done
}

function fn_tal(){
  PARAM_1=$1
  # tail -f $PARAM_1 | awk '
    
  #   /DEBUG/ {print "\033[32m" $0 "\033[39m"}
  #   /TRACE/ {print "\033[4m" $0 "\033[39m"}
  #   /INFO/ {print "\033[33m" $0 "\033[39m"}
    
  # '

tail -f $PARAM_1 | sed --unbuffered \
    -e 's/\(.* DEBUG.*\)/\o033[1;32m\1\o033[39m/' \
    -e 's/\(.* WARN.*\)/\o033[1;33m\1\o033[39m/' \
    -e 's/\(.* ERROR.*\)/\o033[1;31m\1\o033[39m/' \
    -e 's/\(.* INFO.*\)/\o033[1;30m\1\o033[39m/' \
    -e 's/\(.* TRACE.*\)/\o033[34m\1\o033[39m/'

}


#------------------------------------------------------
#------------ para abrir Ides de Windows
#------------------------------------------------------

#:: Webstorm
function xws (){
  current_dir_this=$(pwd)

   PATH_IDE='/c/Program Files/JetBrains/WebStorm 2021.3/bin/'
   if [ "$CURRENT_TERMINAL" == "mobax" ]
    then
      PATH_IDE='/drives/c/Program Files/JetBrains/WebStorm 2021.3/bin/'
   fi

  PATH_EXE='webstorm64.exe'
  # Aqui ejecutamos el ide con el path para  abrir el proyecto como en VSCODE
  cd "$PATH_IDE" && start $PATH_EXE "${current_dir_this}" && cd "${current_dir_this}"
}

#:: Webstorm
function xidea (){
  current_dir_this=$(pwd)
  PATH_IDE='/c/Program Files/JetBrains/WebStorm 2021.3/bin/'
  if [ "$CURRENT_TERMINAL" == "mobax" ]
   then
     PATH_IDE='/drives/c/Program Files/JetBrains/WebStorm 2021.3/bin/'
  fi
  PATH_EXE='idea64.exe'
  # Aqui ejecutamos el ide con el path para  abrir el proyecto como en VSCODE
  cd "$PATH_IDE" && start $PATH_EXE "${current_dir_this}" && cd "${current_dir_this}"
}


function loadCygwin64(){

    SET CHERE_INVOKING=1 && "C:\cygwin64\bin\bash.exe --login -i" -new_console:p:C:"C:\cygwin64\Cygwin.ico"

}


