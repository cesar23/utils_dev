#!/bin/bash

# Colores Regulares
Color_Off='\e[0m'       # Reset de color.
Black='\e[0;30m'        # Negro.
Red='\e[0;31m'          # Rojo.
Green='\e[0;32m'        # Verde.
Yellow='\e[0;33m'       # Amarillo.
Blue='\e[0;34m'         # Azul.
Purple='\e[0;35m'       # Púrpura.
Cyan='\e[0;36m'         # Cian.
White='\e[0;37m'        # Blanco.
Gray='\e[0;90m'         # Gris.




PATH_SCRIPT=$(readlink -f "${BASH_SOURCE:-$0}")  # Ruta completa del script actual.
SCRIPT_NAME=$(basename "$PATH_SCRIPT")           # Nombre del archivo del script.
CURRENT_TERMINAL_SCRIPTS=$(dirname "$PATH_SCRIPT")            # Ruta del directorio donde se encuentra el script.


#######################################
# @description convierte path de shella  windows
# @author Cesar Auris
# @return object
# @param name $1
# @example path_shell_to_path_windows '/c/Desktop/proyecto-tracking/NonFood'
# @version 0.1 2022-03-04
#######################################
function path_shell_to_path_windows (){
  PATH_REPO=$1

  # --------- para Mobax
  result=$(echo "${PATH_REPO}" | sed -r -e 's/^\/drives\/([a-zA-Z])+\/(.*)/\/\1\/\2/' )
  result=$(echo "${result}" | sed "s/\//\\\\/g")
  result=$(echo "${result}" | sed -r -e 's/^\\([a-zA-Z])+\\(.*)$/\1:\\\2/' )

  echo $result
}

# --------------------------------------------------------------
# Función: run_server_py
# Descripción:
#   Inicia un servidor Python ejecutando un script llamado `server_python.py`.
#   Utiliza `python` en Windows y `python3` en Linux.
# --------------------------------------------------------------
function run_server_py() {
  # Valores predeterminados
  default_port=8080
  default_directory=$(pwd)

  # Parámetros opcionales: puerto y directorio
  port=${1:-$default_port}            # Si no se proporciona, usar puerto predeterminado
  directory=${2:-$default_directory}  # Si no se proporciona, usar directorio actual

  echo -e "${Gray}"
  echo "============================"
  echo "Iniciando servidor Python..."
  echo "Directorio: ${directory}"
  echo "Puerto: ${port}"
  echo "URL: http://localhost:${port}"
  echo "============================"
  echo -e "${Color_Off}"

  # Verificar si el directorio existe
  if [[ ! -d "$directory" ]]; then
    echo -e "${Red}❌ Error: El directorio especificado no existe: $directory${Color_Off}"
    return 1
  fi

  # Detectar sistema operativo
  if [[ $(uname -s) == *"MINGW"* || $(uname -s) == *"CYGWIN"* ]]; then
    python_cmd="python"  # Windows (Git Bash o Cygwin)
    # Convertir ruta a formato Windows
    path_windows=$(path_shell_to_path_windows  "${directory}")
    echo "Ruta en formato Windows: ${path_windows}"
    directory="$path_windows"
  else
    python_cmd="python3"  # Linux/Mac
  fi

  # Ejecutar el servidor Python
  echo -e "${Cyan} *********** ejecucion de script Python *************"
  cd "${CURRENT_TERMINAL_SCRIPTS}/" && $python_cmd server_python.py "$port" "$directory"
  if [[ $? -ne 0 ]]; then
    echo "Error al iniciar el servidor Python."
    return 1
  fi
}

# --------------------------------------------------------------
# Ejecución directa para pruebas
# --------------------------------------------------------------

#if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
#  # Leer argumentos: puerto y directorio
#  port_arg=${1:-}
#  directory_arg=${2:-}
#
#  run_server_py "$port_arg" "$directory_arg"
#fi

# --------------------------------------------------------------
# Modo de uso
# --------------------------------------------------------------
#    ./conf_funciones_level_2.sh
#    ./conf_funciones_level_2.sh 9090
#    ./conf_funciones_level_2.sh 9090 /E/deysi^