#!/usr/bin/env bash

# =============================================================================
# 🏆 SECTION: Configuración Inicial
# =============================================================================
# Establece la codificación a UTF-8 para evitar problemas con caracteres especiales.


# PERF: reutiliza variables ya calculadas por init.sh / conf_funciones_level_1.sh
# en vez de recomputarlas (esto solía lanzar ~13 procesos nuevos cada vez que
# se abría una terminal o se llamaba reload_config/cesar).
# Fecha y hora actual en formato: YYYY-MM-DD_HH:MM:SS (hora local)
: "${DATE_HOUR:=$(date "+%Y-%m-%d_%H:%M:%S")}"
# Fecha y hora actual en Perú (UTC -5)
HOURS_RESTART="-5"
: "${DATE_HOUR_PE:=${DATE_HOUR_GIT:-$DATE_HOUR}}"
: "${CURRENT_USER:=$(id -un)}"             # Nombre del usuario actual.
CURRENT_USER_HOME="${HOME:-$USERPROFILE}"  # Ruta del perfil del usuario actual.
: "${CURRENT_PC_NAME:=$(hostname)}"        # Nombre del equipo actual.
MY_INFO="${MY_INFO:-${CURRENT_USER}@${CURRENT_PC_NAME}}"  # Información combinada del usuario y del equipo.
: "${PATH_SCRIPT:=$(readlink -f "${BASH_SOURCE:-$0}")}"  # Ruta completa del script actual.
: "${SCRIPT_NAME:=$(basename "$PATH_SCRIPT")}"           # Nombre del archivo del script.
: "${CURRENT_DIR:=$(dirname "$PATH_SCRIPT")}"            # Ruta del directorio donde se encuentra el script.
NAME_DIR=$(basename "$CURRENT_DIR")              # Nombre del directorio actual (barato, sin fork extra relevante).
TEMP_PATH_SCRIPT="${PATH_SCRIPT%.sh}.tmp"        # Ruta para un archivo temporal basado en el nombre del script (sin fork).
TEMP_PATH_SCRIPT_SYSTEM="${TMP}/${SCRIPT_NAME%.sh}.tmp"  # Ruta para un archivo temporal en /tmp (sin fork).
: "${ROOT_PATH:=$(realpath -m "${CURRENT_DIR}/..")}"

# Ruta del archivo de configuración SSH
SSH_CONFIG="${HOME}/.ssh/config"



# =============================================================================
# ⚙️ SECTION: Core Functions
# =============================================================================

# ==============================================================================
# 📝 Función: msg
# ------------------------------------------------------------------------------
# ✅ Descripción:
#   Imprime mensajes con colores según el tipo. Formato limpio sin fecha ni etiquetas.
#
# 🔧 Parámetros:
#   $1 - Mensaje a mostrar (texto)
#   $2 - Tipo de mensaje (INFO | WARNING | ERROR | SUCCESS | DEBUG) [opcional, por defecto: INFO]
#
# 💡 Uso:
#   msg "Proceso completado"                  # Por defecto: INFO (azul)
#   msg "Revisar configuración" "WARNING"     # WARNING (amarillo)
#   msg "Conexión fallida" "ERROR"            # ERROR (rojo)
#   msg "Operación exitosa" "SUCCESS"         # SUCCESS (verde)
#   msg "Modo debug activado" "DEBUG"         # DEBUG (púrpura)
#
# 🎨 Requiere:
#   Variables de color: BBlue, BYellow, BRed, BGreen, BPurple, BGray, Color_Off
# ==============================================================================

ssh_func_msg() {
  local message="$1"
  local level="${2:-OTHER}"

  case "$level" in
    INFO)
      echo -e "${BBlue}${message}${Color_Off}"
      ;;
    WARNING)
      echo -e "${BYellow}${message}${Color_Off}"
      ;;
    DEBUG)
      echo -e "${BPurple}${message}${Color_Off}"
      ;;
    ERROR)
      echo -e "${BRed}${message}${Color_Off}"
      ;;
    SUCCESS)
      echo -e "${BGreen}${message}${Color_Off}"
      ;;
    *)
      echo -e "${BGray}${message}${Color_Off}"
      ;;
  esac
}

# =============================================================================
# 🔌 SECTION: SSH Manager Functions
# =============================================================================

#=============================================================================
# Función: parse_ssh_config
#
# Descripción:
#   Lee el archivo ~/.ssh/config y extrae los hosts con sus respectivas IPs
#   Almacena los resultados en arrays paralelos para su posterior uso
#
# Variables globales (arrays):
#   SSH_HOSTS - Array con los nombres de los hosts
#   SSH_IPS   - Array con las IPs correspondientes
#
# Retorna:
#   0: Éxito - Arrays poblados con la información
#   1: Error - Archivo config no existe o no se pudo leer
#=============================================================================
ssh_func_parse_ssh_config() {
    # Verificar que el archivo existe
    if [ ! -f "$SSH_CONFIG" ]; then
        msg "No se encontró el archivo de configuración SSH: $SSH_CONFIG" "ERROR"
        return 1
    fi

    # Inicializar arrays
    SSH_HOSTS=()
    SSH_IPS=()
    SSH_USERS=()
    SSH_PORTS=()

    local current_host=""
    local current_ip=""
    local current_user=""
    local current_port=""

    # Leer el archivo línea por línea
    while IFS= read -r line; do
        # Ignorar líneas vacías y comentarios
        [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

        # Detectar Host
        if [[ "$line" =~ ^[[:space:]]*Host[[:space:]]+([^[:space:]]+) ]]; then
            # Si ya teníamos un host previo, guardarlo
            if [ -n "$current_host" ] && [ -n "$current_ip" ]; then
                SSH_HOSTS+=("$current_host")
                SSH_IPS+=("$current_ip")
                SSH_USERS+=("${current_user:-N/A}")
                SSH_PORTS+=("${current_port:-22}")
            fi

            # Iniciar nuevo host
            current_host="${BASH_REMATCH[1]}"
            current_ip=""
            current_user=""
            current_port=""
        fi

        # Detectar HostName (IP)
        if [[ "$line" =~ ^[[:space:]]*HostName[[:space:]]+([^[:space:]]+) ]]; then
            current_ip="${BASH_REMATCH[1]}"
        fi

        # Detectar User
        if [[ "$line" =~ ^[[:space:]]*User[[:space:]]+([^[:space:]]+) ]]; then
            current_user="${BASH_REMATCH[1]}"
        fi

        # Detectar Port
        if [[ "$line" =~ ^[[:space:]]*Port[[:space:]]+([^[:space:]]+) ]]; then
            current_port="${BASH_REMATCH[1]}"
        fi

    done < "$SSH_CONFIG"

    # Guardar el último host
    if [ -n "$current_host" ] && [ -n "$current_ip" ]; then
        SSH_HOSTS+=("$current_host")
        SSH_IPS+=("$current_ip")
        SSH_USERS+=("${current_user:-N/A}")
        SSH_PORTS+=("${current_port:-22}")
    fi

    return 0
}






#=============================================================================
# Función: show_menu
# Muestra el menú con todos los servidores SSH
#=============================================================================
ssh_func_show_menu() {

    echo ""

    # Colores para intercalar
    local color1="${BWhite}"
    local color2="${BCyan}"

    # Mostrar lista de servidores
    for i in "${!SSH_HOSTS[@]}"; do
        local num=$((i + 1))
        local host="${SSH_HOSTS[$i]}"
        local ip="${SSH_IPS[$i]}"
        local user="${SSH_USERS[$i]}"
        local port="${SSH_PORTS[$i]}"

        # Elegir color según paridad del índice
        if (( i % 2 == 0 )); then
            local line_color="$color1"
        else
            local line_color="$color2"
        fi

        echo -en "${BYellow}[$num]${Color_Off} ${line_color}${host}${Color_Off} / "
        echo -e "${line_color}${user}@${ip}:${port}${Color_Off}"

    done

    echo -e "${BYellow}[0]${Color_Off} ${BRed}❌  Salir${Color_Off}"
    echo ""
}

#=============================================================================
# Función: connect_ssh
# Establece conexión SSH al servidor seleccionado
#=============================================================================
ssh_func_connect_ssh() {
    local index=$1
    local host="${SSH_HOSTS[$index]}"

    echo ""
    echo -e "${BGreen}🚀 Conectando a ${BCyan}${host}${Color_Off}"
    echo ""

    # Conectar al servidor
    ssh "$host"

    echo ""
    echo -e "${BYellow}⚠️  Conexión cerrada${Color_Off}"
    echo ""
}

# =============================================================================
# 🚀 SECTION: Main Function
# =============================================================================

ssh_func_main_config_ssh() {
    # Parsear el archivo de configuración SSH
    if ! ssh_func_parse_ssh_config; then
        msg "❌ Error al leer la configuración SSH" "ERROR"
        exit 1
    fi

    # Verificar que hay servidores configurados
    if [ ${#SSH_HOSTS[@]} -eq 0 ]; then
        msg "⚠️  No se encontraron servidores en $SSH_CONFIG" "WARNING"
        exit 1
    fi

    # Loop principal del menú
    while true; do
        ssh_func_show_menu

        # Solicitar selección
        echo -ne "${BWhite}Selecciona:${Color_Off} "
        read -r option

        # Validar entrada
        if ! [[ "$option" =~ ^[0-9]+$ ]]; then
            msg "❌ Opción inválida" "ERROR"
            sleep 1
            continue
        fi

        # Opción salir
        if [ "$option" -eq 0 ]; then
            echo ""
            echo -e "${BGreen}👋 ¡Hasta luego!${Color_Off}"
            echo ""
            return
        fi

        # Validar rango
        if [ "$option" -lt 1 ] || [ "$option" -gt ${#SSH_HOSTS[@]} ]; then
            msg "⚠️  Opción fuera de rango (1-${#SSH_HOSTS[@]})" "ERROR"
            sleep 1
            continue
        fi

        # Conectar
        ssh_func_connect_ssh $((option - 1))

        # Pausar antes de volver al menú
        echo -ne "${BCyan}⏎ Presiona ENTER...${Color_Off}"
        read -r
    done
}

# =============================================================================
# 🎬 SECTION: Script Execution
# =============================================================================
