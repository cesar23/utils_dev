#!/usr/bin/env bash

# =============================================================================
# 🏆 SECTION: Configuración Inicial
# =============================================================================
# Establece la codificación a UTF-8 para evitar problemas con caracteres especiales.
export LC_ALL="es_ES.UTF-8"

# Fecha y hora actual en formato: YYYY-MM-DD_HH:MM:SS (hora local)
DATE_HOUR=$(date "+%Y-%m-%d_%H:%M:%S")
# Fecha y hora actual en Perú (UTC -5)
HOURS_RESTART="-5"
DATE_HOUR_PE_DEFAULT=$(date -u -d "-5 hours" "+%Y-%m-%d_%H:%M:%S") # Fecha y hora actuales en formato YYYY-MM-DD_HH:MM:SS.
CURRENT_USER=$(id -un)             # Nombre del usuario actual.
CURRENT_USER_HOME="${HOME:-$USERPROFILE}"  # Ruta del perfil del usuario actual.
CURRENT_PC_NAME=$(hostname)        # Nombre del equipo actual.
MY_INFO="${CURRENT_USER}@${CURRENT_PC_NAME}"  # Información combinada del usuario y del equipo.
PATH_SCRIPT=$(readlink -f "${BASH_SOURCE:-$0}")  # Ruta completa del script actual.
SCRIPT_NAME=$(basename "$PATH_SCRIPT")           # Nombre del archivo del script.
CURRENT_DIR=$(dirname "$PATH_SCRIPT")            # Ruta del directorio donde se encuentra el script.
NAME_DIR=$(basename "$CURRENT_DIR")              # Nombre del directorio actual.
TEMP_PATH_SCRIPT=$(echo "$PATH_SCRIPT" | sed 's/.sh/.tmp/g')  # Ruta para un archivo temporal basado en el nombre del script.
TEMP_PATH_SCRIPT_SYSTEM=$(echo "${TMP}/${SCRIPT_NAME}" | sed 's/.sh/.tmp/g')  # Ruta para un archivo temporal en /tmp.
ROOT_PATH=$(realpath -m "${CURRENT_DIR}/..")

# Ruta del archivo de configuración SSH
SSH_CONFIG="${HOME}/.ssh/config"

# =============================================================================
# 🎨 SECTION: Colores para su uso
# =============================================================================
# Definición de colores que se pueden usar en la salida del terminal.

# Colores Regulares
Color_Off='\033[0m'       # Reset de color.
Black='\033[0;30m'        # Negro.
Red='\033[0;31m'          # Rojo.
Green='\033[0;32m'        # Verde.
Yellow='\033[0;33m'       # Amarillo.
Blue='\033[0;34m'         # Azul.
Purple='\033[0;35m'       # Púrpura.
Cyan='\033[0;36m'         # Cian.
White='\033[0;37m'        # Blanco.
Gray='\033[0;90m'         # Gris.

# Colores en Negrita
BBlack='\033[1;30m'       # Negro (negrita).
BRed='\033[1;31m'         # Rojo (negrita).
BGreen='\033[1;32m'       # Verde (negrita).
BYellow='\033[1;33m'      # Amarillo (negrita).
BBlue='\033[1;34m'        # Azul (negrita).
BPurple='\033[1;35m'      # Púrpura (negrita).
BCyan='\033[1;36m'        # Cian (negrita).
BWhite='\033[1;37m'       # Blanco (negrita).
BGray='\033[1;90m'        # Gris (negrita).

# =============================================================================
# ⚙️ SECTION: Core Functions
# =============================================================================

#=============================================================================
# Función: get_date_peru
#
# Descripción:
#   Obtiene la fecha y hora actual de Perú desde una API externa.
#   La función realiza una llamada HTTP a un servicio de zona horaria
#   y extrae la fecha en formato yyyy-MM-dd_HH:mm:ss (con guión bajo
#   como separador para compatibilidad con nombres de archivo).
#
# Variables de entorno:
#   API_TOKEN - Token de autenticación para la API (opcional, tiene fallback)
#
# Retorna:
#   0: Éxito - Imprime la fecha en stdout en formato yyyy-MM-dd_HH:mm:ss
#   1: Error - Fallo en la conexión o en el parseo de la respuesta
#
# Ejemplos de uso:
#
#   Opción 1 - Manejo con valor por defecto (más conciso):
#   if ! FECHA=$(get_date_peru); then
#       FECHA="2025-01-01_00:00:00"
#   fi
#   echo "Fecha: $FECHA"
#
#   Opción 2 - Manejo con mensajes de error:
#   if FECHA=$(get_date_peru); then
#       echo "Fecha obtenida: $FECHA"
#   else
#       echo "Error al obtener fecha" >&2
#       exit 1
#   fi
#=============================================================================
get_date_peru() {
    # Configuración del token de autenticación
    # Se prioriza la variable de entorno API_TOKEN por seguridad
    # Si no existe, usa el valor predeterminado (solo para desarrollo)
    local TOKEN="${API_TOKEN:-12312323rfefewfewfwefwef23r23r23f23f32f}"

    # Parámetros de la petición HTTP
    local API_URL="https://worker-utils.solucionessystem.com/api/time-zone/peru"
    local FORMATO_FECHA="yyyy-MM-dd%20HH%3Amm%3Ass"  # URL encoded: "yyyy-MM-dd HH:mm:ss"
    local TIMEOUT=10  # Timeout en segundos para la petición

    # Realizar llamada a la API con curl
    # Opciones:
    #   -s (silent): Suprime la barra de progreso
    #   --location: Sigue redirecciones HTTP
    #   --max-time: Tiempo máximo de espera para la operación completa
    local RESPONSE
    RESPONSE=$(curl -s --location \
        --max-time "$TIMEOUT" \
        "${API_URL}?key=${TOKEN}&format=${FORMATO_FECHA}") || {
        # Si curl falla (código de salida != 0), retornar error
        # Posibles causas: sin conexión, timeout, servidor no responde
        return 1
    }

    # Parsear la respuesta JSON para extraer el campo "date_local"
    # Método: Usa grep con regex para buscar el patrón y cut para extraer el valor
    # Ventaja: No requiere dependencias adicionales como jq
    # Ejemplo de JSON esperado: {"date_local":"2025-10-30 15:30:45"}
    local FECHA_HORA
    FECHA_HORA=$(echo "$RESPONSE" | grep -o '"date_local":"[^"]*"' | cut -d'"' -f4)

    # Validar que se extrajo correctamente la fecha
    if [ -z "$FECHA_HORA" ]; then
        # Si la extracción falla, la respuesta no tiene el formato esperado
        # o el campo "date_local" no existe
        return 1
    fi

    # Reemplazar espacios por guiones bajos para compatibilidad
    # Útil cuando se usa la fecha en nombres de archivo o rutas
    FECHA_HORA=$(echo "$FECHA_HORA" | tr ' ' '_')

    # Retornar la fecha formateada
    echo "$FECHA_HORA"
    return 0
}

# funcion para saber si restaremos horas para obtener hora peru
set_hours_rest_peru(){
  # 2025-02-02_12:33:34  =  2025-02-02_12
  # El patrón ':*' busca el primer ':' y  lo que le sigue, eliminando ':33:34'.
  local DATE_HOUR_HOUR="${DATE_HOUR%:*}"
  local DATE_HOUR_PE_HOUR="${DATE_HOUR_PE%:*}"

  # Si las horas coinciden, no es necesario restar (la API ya devuelve hora correcta)
  if [[ "${DATE_HOUR_HOUR}" == "${DATE_HOUR_PE_HOUR}" ]]; then
      HOURS_RESTART="-0"
  fi
}

# ==============================================================================
# 📝 Función: msg
# ------------------------------------------------------------------------------
# ✅ Descripción:
#   Imprime un mensaje con formato estándar, incluyendo:
#   - Marca de tiempo en UTC-5 (Perú)
#   - Tipo de mensaje (INFO, WARNING, ERROR, o personalizado)
#   - Colores para terminal (si están definidos previamente)
#
# 🔧 Parámetros:
#   $1 - Mensaje a mostrar (texto)
#   $2 - Tipo de mensaje (INFO | WARNING | ERROR | otro) [opcional, por defecto: INFO]
#
# 💡 Uso:
#   msg "Inicio del proceso"               # Por defecto: INFO
#   msg "Plugin no instalado" "WARNING"
#   msg "Error de conexión" "ERROR"
#   msg "Mensaje personalizado" "DEBUG"
#
# 🎨 Requiere:
#   Variables de color: BBlue, BYellow, BRed, BWhite, BGray, Color_Off
# ==============================================================================
msg() {
  local message="$1"
  local level="${2:-INFO}"
  local timestamp=$(date "+%Y-%m-%d %H:%M:%S")

  # si tenemos que restar horas
  if [[ "${HOURS_RESTART}" == "-5" ]]; then
    timestamp=$(date -u -d "-5 hours" "+%Y-%m-%d %H:%M:%S")
  fi

  local SHOW_DETAIL=1
  if [ -n "$SO_SYSTEM" ] && [ "$SO_SYSTEM" = "termux" ]; then
    SHOW_DETAIL=0
  fi

  case "$level" in
    INFO)
        if [ "$SHOW_DETAIL" -eq 0 ]; then
          echo -e "${BBlue}[INFO]${Color_Off} ${message}"
        else
          echo -e "${BBlue}${timestamp} - [INFO]${Color_Off} ${message}"
        fi
        ;;
    WARNING)
        if [ "$SHOW_DETAIL" -eq 0 ]; then
          echo -e "${BYellow}[WARNING]${Color_Off} ${message}"
        else
          echo -e "${BYellow}${timestamp} - [WARNING]${Color_Off} ${message}"
        fi
        ;;
    DEBUG)
        if [ "$SHOW_DETAIL" -eq 0 ]; then
          echo -e "${BPurple}[DEBUG]${Color_Off} ${message}"
        else
          echo -e "${BPurple}${timestamp} - [DEBUG]${Color_Off} ${message}"
        fi
        ;;
    ERROR)
        if [ "$SHOW_DETAIL" -eq 0 ]; then
          echo -e "${BRed}[ERROR]${Color_Off} ${message}"
        else
          echo -e "${BRed}${timestamp} - [ERROR]${Color_Off} ${message}"
        fi
        ;;
    SUCCESS)
        if [ "$SHOW_DETAIL" -eq 0 ]; then
          echo -e "${BGreen}[SUCCESS]${Color_Off} ${message}"
        else
          echo -e "${BGreen}${timestamp} - ${BGreen}[SUCCESS]${Color_Off} ${message}"
        fi
        ;;
    *)
          echo -e "${BGray}[OTHER]${Color_Off} ${message}"
        ;;
  esac
}

# =============================================================================
# 🔌 SECTION: SSH Manager Functions
# =============================================================================

#=============================================================================
# Función: parse_ssh_config
#
# Descripción:
#   Lee el archivo ~/.ssh/config y extrae los hosts con sus respectivas IPs
#   Almacena los resultados en arrays paralelos para su posterior uso
#
# Variables globales (arrays):
#   SSH_HOSTS - Array con los nombres de los hosts
#   SSH_IPS   - Array con las IPs correspondientes
#
# Retorna:
#   0: Éxito - Arrays poblados con la información
#   1: Error - Archivo config no existe o no se pudo leer
#=============================================================================
parse_ssh_config() {
    # Verificar que el archivo existe
    if [ ! -f "$SSH_CONFIG" ]; then
        msg "No se encontró el archivo de configuración SSH: $SSH_CONFIG" "ERROR"
        return 1
    fi

    # Inicializar arrays
    SSH_HOSTS=()
    SSH_IPS=()
    SSH_USERS=()
    SSH_PORTS=()

    local current_host=""
    local current_ip=""
    local current_user=""
    local current_port=""

    # Leer el archivo línea por línea
    while IFS= read -r line; do
        # Ignorar líneas vacías y comentarios
        [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

        # Detectar Host
        if [[ "$line" =~ ^[[:space:]]*Host[[:space:]]+([^[:space:]]+) ]]; then
            # Si ya teníamos un host previo, guardarlo
            if [ -n "$current_host" ] && [ -n "$current_ip" ]; then
                SSH_HOSTS+=("$current_host")
                SSH_IPS+=("$current_ip")
                SSH_USERS+=("${current_user:-N/A}")
                SSH_PORTS+=("${current_port:-22}")
            fi

            # Iniciar nuevo host
            current_host="${BASH_REMATCH[1]}"
            current_ip=""
            current_user=""
            current_port=""
        fi

        # Detectar HostName (IP)
        if [[ "$line" =~ ^[[:space:]]*HostName[[:space:]]+([^[:space:]]+) ]]; then
            current_ip="${BASH_REMATCH[1]}"
        fi

        # Detectar User
        if [[ "$line" =~ ^[[:space:]]*User[[:space:]]+([^[:space:]]+) ]]; then
            current_user="${BASH_REMATCH[1]}"
        fi

        # Detectar Port
        if [[ "$line" =~ ^[[:space:]]*Port[[:space:]]+([^[:space:]]+) ]]; then
            current_port="${BASH_REMATCH[1]}"
        fi

    done < "$SSH_CONFIG"

    # Guardar el último host
    if [ -n "$current_host" ] && [ -n "$current_ip" ]; then
        SSH_HOSTS+=("$current_host")
        SSH_IPS+=("$current_ip")
        SSH_USERS+=("${current_user:-N/A}")
        SSH_PORTS+=("${current_port:-22}")
    fi

    return 0
}




my_banner(){
  clear
  echo ""
  echo -e "${BRed}╔══════════════════════════════════════════════════╗${Color_Off}"
  echo -e "${BRed}║${Color_Off}  ${BWhite} ██████╗ █████╗ ${Color_Off}      ${BRed}██████╗ ███████╗██╗   ██╗${Color_Off} ${BRed}║${Color_Off}"
  echo -e "${BRed}║${Color_Off}  ${BWhite}██╔════╝██╔══██╗${Color_Off}      ${BRed}██╔══██╗██╔════╝██║   ██║${Color_Off} ${BRed}║${Color_Off}"
  echo -e "${BRed}║${Color_Off}  ${BWhite}██║     ███████║${Color_Off}█████╗${BRed}██║  ██║█████╗  ██║   ██║${Color_Off} ${BRed}║${Color_Off}"
  echo -e "${BRed}║${Color_Off}  ${BWhite}██║     ██╔══██║${Color_Off}╚════╝${BRed}██║  ██║██╔══╝  ╚██╗ ██╔╝${Color_Off} ${BRed}║${Color_Off}"
  echo -e "${BRed}║${Color_Off}  ${BWhite}╚██████╗██║  ██║${Color_Off}      ${BRed}██████╔╝███████╗ ╚████╔╝ ${Color_Off} ${BRed}║${Color_Off}"
  echo -e "${BRed}║${Color_Off}  ${BWhite} ╚═════╝╚═╝  ╚═╝${Color_Off}      ${BRed}╚═════╝ ╚══════╝  ╚═══╝  ${Color_Off} ${BRed}║${Color_Off}"
  echo -e "${BRed}║${Purple}          Cesar Auris - perucaos@gmail.com        ${BRed}║${Color_Off}"
  echo -e "${BRed}╚══════════════════════════════════════════════════╝${Color_Off}"
  echo -e "${Gray}┌──────────────────────────────────────────────────┐${Color_Off}"
  echo -e "${Gray}│${Color_Off} ${BRed}[${Color_Off}${BWhite}*${Color_Off}${BRed}]${Color_Off} Config: ${BYellow}${SSH_CONFIG}${Color_Off}${Gray}         │${Color_Off}"
  echo -e "${Gray}└──────────────────────────────────────────────────┘${Color_Off}"
}



#=============================================================================
# Función: show_menu
# Muestra el menú con todos los servidores SSH
#=============================================================================
show_menu() {
    my_banner
    echo ""

    # Mostrar lista de servidores
    for i in "${!SSH_HOSTS[@]}"; do
        local num=$((i + 1))
        local host="${SSH_HOSTS[$i]}"
        local ip="${SSH_IPS[$i]}"
        local user="${SSH_USERS[$i]}"
        local port="${SSH_PORTS[$i]}"

        echo -en "${BYellow}[$num]${Color_Off} ${BWhite}${host}${Color_Off} / "
        echo -e "${Cyan}${user}@${ip}:${port}${Color_Off}"
        echo ""
    done

    echo -e "${BYellow}[0]${Color_Off} ${BRed}❌  Salir${Color_Off}"
    echo ""
}

#=============================================================================
# Función: connect_ssh
# Establece conexión SSH al servidor seleccionado
#=============================================================================
connect_ssh() {
    local index=$1
    local host="${SSH_HOSTS[$index]}"

    echo ""
    echo -e "${BGreen}🚀 Conectando a ${BCyan}${host}${Color_Off}"
    echo ""

    # Conectar al servidor
    ssh "$host"

    echo ""
    echo -e "${BYellow}⚠️  Conexión cerrada${Color_Off}"
    echo ""
}

# =============================================================================
# 🚀 SECTION: Main Function
# =============================================================================

main_config_ssh() {
    # Parsear el archivo de configuración SSH
    if ! parse_ssh_config; then
        msg "❌ Error al leer la configuración SSH" "ERROR"
        exit 1
    fi

    # Verificar que hay servidores configurados
    if [ ${#SSH_HOSTS[@]} -eq 0 ]; then
        msg "⚠️  No se encontraron servidores en $SSH_CONFIG" "WARNING"
        exit 1
    fi

    # Loop principal del menú
    while true; do
        show_menu

        # Solicitar selección
        echo -ne "${BWhite}Selecciona:${Color_Off} "
        read -r option

        # Validar entrada
        if ! [[ "$option" =~ ^[0-9]+$ ]]; then
            msg "❌ Opción inválida" "ERROR"
            sleep 1
            continue
        fi

        # Opción salir
        if [ "$option" -eq 0 ]; then
            echo ""
            echo -e "${BGreen}👋 ¡Hasta luego!${Color_Off}"
            echo ""
            return
        fi

        # Validar rango
        if [ "$option" -lt 1 ] || [ "$option" -gt ${#SSH_HOSTS[@]} ]; then
            msg "⚠️  Opción fuera de rango (1-${#SSH_HOSTS[@]})" "ERROR"
            sleep 1
            continue
        fi

        # Conectar
        connect_ssh $((option - 1))

        # Pausar antes de volver al menú
        echo -ne "${BCyan}⏎ Presiona ENTER...${Color_Off}"
        read -r
    done
}

# =============================================================================
# 🎬 SECTION: Script Execution
# =============================================================================

