# =========================================
# string_slugify
# -----------------------------------------
# Convierte una cadena en un slug amigable para URLs.
# Permite controlar el formato de mayúsculas/minúsculas.
#
# Argumentos:
#   $1 (str): Cadena original.
#   $2 (str): Formato de capitalización (opcional):
#       - "lower": todo minúsculas
#       - "upper": todo mayúsculas
#       - "capitalize": primera letra en mayúscula
#       - "title": primera letra de cada palabra en mayúscula
#       - "none" o vacío: conserva el formato original (por defecto)
#
# Retorna:
#   str: Cadena en formato slug.
#
# Ejemplos de uso:
#   texto="¡Hola Mundo! Este es un Título de Prueba 2024"
#   echo "$(string_slugify "$texto")"                # hola-mundo-este-es-un-titulo-de-prueba-2024
#   echo "$(string_slugify "$texto" lower)"          # hola-mundo-este-es-un-titulo-de-prueba-2024
#   echo "$(string_slugify "$texto" upper)"          # HOLA-MUNDO-ESTE-ES-UN-TITULO-DE-PRUEBA-2024
#   echo "$(string_slugify "$texto" capitalize)"     # Hola-mundo-este-es-un-titulo-de-prueba-2024
#   echo "$(string_slugify "$texto" title)"          # Hola-Mundo-Este-Es-Un-Titulo-De-Prueba-2024
#   echo "$(string_slugify "Mi_video_de prueba final")" # mi-video-de-prueba-final
#   echo "$(string_slugify "Título con acentos y ñ")"   # titulo-con-acentos-y-n
#
#   # Usando el slug para nombrar archivos:
#   titulo="Mi Video de Prueba 2024!"
#   slug=$(string_slugify "$titulo")
#   yt-dlp -o "${slug}.%(ext)s" "URL_DEL_VIDEO"
#   # Descargará el video como: mi-video-de-prueba-2024.mp4
# =========================================
string_slugify() {
    local input="$1"
    local case="$2"

    # Validar parámetros
    [[ -z "$input" ]] && echo "" && return

    # Eliminar espacios iniciales y finales
    input="$(echo "$input" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"

    # Aplicar el formato de capitalización
    case "$case" in
        lower)
            input="$(echo "$input" | tr '[:upper:]' '[:lower:]')"
            ;;
        upper)
            input="$(echo "$input" | tr '[:lower:]' '[:upper:]')"
            ;;
        capitalize)
            first="$(echo "${input:0:1}" | tr '[:lower:]' '[:upper:]')"
            rest="$(echo "${input:1}" | tr '[:upper:]' '[:lower:]')"
            input="$first$rest"
            ;;
        title)
            input="$(echo "$input" | awk '{for(i=1;i<=NF;i++){ $i=toupper(substr($i,1,1)) tolower(substr($i,2)) }}1')"
            ;;
        none|"")
            ;; # conservar original
        *)
            echo "Error: parámetro inválido. Usa: lower, upper, capitalize, title o none."
            return 1
            ;;
    esac

    # Eliminar caracteres no deseados (solo letras, números, guiones y espacios)
    input="$(echo "$input" | sed 's/[^[:alnum:] _-]//g')"

    # Reemplazar espacios o guiones bajos múltiples por un solo guion
    input="$(echo "$input" | sed -E 's/[[:space:]_]+/-/g')"

    # Eliminar guiones iniciales o finales
    input="$(echo "$input" | sed -E 's/^-+|-+$//g')"

    echo "$input"
}

#
#texto="AURICULAR logitech G335. ( 981-000977 ) GAMING WHITE.[dd] salida.webp"
#
#string_slugify "$texto"           # default (none)
#string_slugify "$texto" lower     # minúsculas
#string_slugify "$texto" upper     # mayúsculas
#string_slugify "$texto" capitalize # tipo oración
#string_slugify "$texto" title     # primera de cada palabra