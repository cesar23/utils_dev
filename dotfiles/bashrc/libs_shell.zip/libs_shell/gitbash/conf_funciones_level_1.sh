#!/bin/bash
# PERF: reutiliza lo ya calculado por init.sh (0 forks nuevos si ya se cargó).
# Antes esta línea sola lanzaba 6 procesos "date" + otro más en la línea de abajo.
: "${DATE_HOUR_GIT:=$(TZ="America/Lima" date "+%Y-%m-%d_%H:%M:%S")}"
: "${DATE_HOUR_GIT_PE:=$DATE_HOUR_GIT}"
: "${CURRENT_USER:=$(id -un)}"             # Nombre del usuario actual.
: "${CURRENT_PC_NAME:=$(hostname)}"        # Nombre del equipo actual.
MY_INFO="${MY_INFO:-${CURRENT_USER}@${CURRENT_PC_NAME}}"  # Información combinada del usuario y del equipo.
INFO_PC=${INFO_PC:-$MY_INFO}


run_command(){
  local param_1=$1
  echo -e "${BYellow}${param_1}${Color_Off}" && sleep 1
  eval "$param_1"
}

# function dir_gspMarino(){
#   cd C:\\laragon\\www\\gspmarinov1
# }
# TODO ddsd
# function dir_gspTerrestre(){
#   cd C:\\laragon\\www\\gsptrackv1
# }
# function dir_cursoReact(){
#   cd C:\\Users\\Cesar\\cesar\\curso_ReacJs
# }

# function dir_aws(){
#   cd C:\\Users\\Cesar\\cesar\\aws
# }

# function dir_projectTerrestre(){
#   cd C:\\laragon\\www\\project_terrestre_node
# }

#######################################
# setea la hora de la variables globales
# @author Cesar Auris
# @return void
# @param name sin referencia
# @version 0.1 2022-03-04
#######################################
function reload_date(){
  DATE_HOUR="`date +%d`/`date +%m`/`date +%Y` - `date +%H`:`date +%M`:`date +%S`"
  DATE_HOUR_GIT="`date +%Y`-`date +%m`-`date +%d`_`date +%H`:`date +%M`:`date +%S`"
}

#######################################
# @description convierte path de shella  windows
# @author Cesar Auris
# @return object
# @param name $1
# @example path_shell_to_path_windows '/c/Desktop/proyecto-tracking/NonFood'
# @version 0.1 2022-03-04
#######################################
function path_shell_to_path_windows (){
    local PATH_REPO=$1
    local result

  # --------- para Cmder
# result=$(echo "${PATH_REPO}" | sed -r -e 's/^\/drives\/([a-zA-Z])+\/(.*)/\/\1\/\2/')
# result=$(echo "${result}" | sed "s/\//\\\\/g")
# result=$(echo "${result}" | sed -r -e 's/^\\([a-zA-Z])+\\(.*)$/\1:\\\2/')

  # --------- para Mobax
  result=$(echo "${PATH_REPO}" | sed -r -e 's@^/drives/([a-zA-Z]+)/(.*)@/\1/\2@')
  result=$(echo "${result}" | sed "s@/@\\\\@/g")
  result=$(echo "${result}" | sed -r -e 's@^\\([a-zA-Z]+)\\(.*)$@\1:\\2@')

  echo "$result"
}

#######################################
# @description convierte un path windows a  shell
# @author Cesar Auris
# @return object
# @param name $1
# @example path_windows_to_path_shell "D:\repos\test_repos"
# @version 0.1 2022-03-04
#######################################
#function path_windows_to_path_shell (){
function path_windows_to_path_shell (){
    local PATH_REPO=$1

    if [[ -z "$PATH_REPO" ]]; then
        echo "Error: Debes proporcionar una ruta en formato Windows." >&2
        return 1
    fi

    # Convertir letra de unidad y backslashes a formato Unix
    local path_unix=$(echo "${PATH_REPO}" | sed 's|^\([A-Za-z]\):|/\L\1|;s|\\|/|g')

    if [[ -d "/mnt/c" ]]; then
      #  aqui convertir ejemplo: C:\laragon
      # a /mnt/c/laragon
        path_unix=$(echo "$PATH_REPO" | sed 's|^\([A-Za-z]\):|/mnt/\L\1|;s|\\|/|g')
        echo "$path_unix"
    else
        echo "$path_unix"
    fi
}


#===============================================================================
# FUNCIÓN: path_to_laragon_format
#===============================================================================
# DESCRIPCIÓN:
#   Convierte una ruta de archivo a formato compatible con Laragon Virtual Hosts.
#   Normaliza diferentes formatos de ruta (Windows, Git Bash, WSL) a un formato
#   estándar con comillas dobles, listo para usar en configuraciones de Apache/Nginx.
#
#   Formato de salida: "D:/ruta/completa/al/proyecto"
#
# PARÁMETROS:
#   $1 - Ruta de entrada (cualquier formato soportado)
#
# FORMATOS DE ENTRADA SOPORTADOS:
#   1. Windows nativo:     D:\repos\proyecto\www
#   2. Git Bash/MobaXterm: /d/repos/proyecto/www
#   3. WSL:                /mnt/d/repos/proyecto/www
#
# RETORNA:
#   - Éxito: Imprime la ruta formateada con comillas dobles
#   - Error: Imprime mensaje de error a stderr y retorna 1
#
# EJEMPLOS DE USO:
#   path_to_laragon_format "D:\repos\mi_proyecto\www"
#   path_to_laragon_format "/d/repos/mi_proyecto/www"
#   path_to_laragon_format "/mnt/d/repos/mi_proyecto/www"
#
# SALIDA ESPERADA:
#   "D:/repos/mi_proyecto/www"
#
# CASOS DE USO TÍPICOS:
#   - Generar automáticamente DocumentRoot en virtual hosts
#   - Crear configuraciones de Apache/Nginx para Laragon
#   - Scripts de automatización de proyectos
#
# DEPENDENCIAS:
#   - bash
#   - sed (con soporte para expresiones regulares extendidas -r)
#
# AUTOR: [Tu nombre]
# VERSIÓN: 1.0
#===============================================================================

function path_to_laragon_format() {
    local PATH_INPUT="$1"
    local result

    # Validar que se proporcionó un argumento
    if [[ -z "$PATH_INPUT" ]]; then
        echo "Error: Debes proporcionar una ruta." >&2
        echo "Uso: path_to_laragon_format <ruta>" >&2
        return 1
    fi

    # Detectar el formato de entrada y normalizar
    if [[ "$PATH_INPUT" =~ ^[A-Za-z]:\\ ]]; then
        # Caso 1: Entrada Windows (ej: D:\repos\...)
        # - Convierte letra de unidad a mayúscula
        # - Reemplaza backslashes (\) por forward slashes (/)
        result=$(echo "$PATH_INPUT" | sed -r -e 's@^([A-Za-z]):@\U\1:@' -e 's@\\@/@g')

    elif [[ "$PATH_INPUT" =~ ^/[A-Za-z]/ ]]; then
        # Caso 2: Entrada Shell/Git Bash (ej: /d/repos/...)
        # - Convierte /d/ a D:/
        # - Mantiene forward slashes (/)
        result=$(echo "$PATH_INPUT" | sed -r -e 's@^/([a-zA-Z])@\U\1:@' -e 's@/@/@g')

    elif [[ "$PATH_INPUT" =~ ^/mnt/[A-Za-z]/ ]]; then
        # Caso 3: Entrada WSL (ej: /mnt/d/repos/...)
        # - Convierte /mnt/d/ a D:/
        # - Mantiene forward slashes (/)
        result=$(echo "$PATH_INPUT" | sed -r -e 's@^/mnt/([a-zA-Z])@\U\1:@' -e 's@/@/@g')

    else
        echo "Error: Formato de ruta no reconocido." >&2
        echo "Formatos soportados:" >&2
        echo "  - Windows: D:\\ruta\\archivo" >&2
        echo "  - Git Bash: /d/ruta/archivo" >&2
        echo "  - WSL: /mnt/d/ruta/archivo" >&2
        return 1
    fi

    # Añadir comillas dobles al resultado (requerido para configuraciones Apache/Nginx)
    echo "\"${result}\""
}


#######################################
# @description pasa como parametro un path windows y se ubica con cd en el directorio
# @author Cesar Auris
# @return void
# @param name sin referencia
# @example cds 'D:\repos\test_repos'
# @version 0.1 2022-03-04
#######################################
function cds (){
  typeset dir
    echo -en "${BIPurple}Paste Directory Path: ${Color_Off}"
    # printf "Paste Directory Path: "
    read -r dir || return
    # cd ${dir:?}

    # read -p "Ingresa path windows: " path_dir
    PATH_WINDOWS=$(path_windows_to_path_shell  "${dir}")
    cd "${PATH_WINDOWS}"
}



function login() {
  read -p 'Username: ' uservar
  read -sp 'Password: ' passvar
  echo ""
  echo "Thankyou ${uservar} tu passwork es:${passvar}"
}

function path_file_weight_human() {
    local file=$1
    local weight=$(du -h "$file" | cut -f1)
    echo $weight
}

function verifi_peso_files_gitup(){
  local resultado_find
  # Guardar el resultado de find en una variable
  resultado_find=$(find . -type f -not -path './.git/*' -size +50M)

  local found_file=0
  # Recorder cada elemento en el resultado
  IFS=$'\n' # Configurar el separador de campos para que sea solo una nueva línea
  for archivo in $resultado_find; do
      # Aquí puedes hacer lo que quieras con cada archivo
      local PESO_DIR=$(path_file_weight_human "${archivo}")
      echo "Procesando archivo: ${archivo} (peso: ${PESO_DIR})"
      # Agrega cualquier otra operación que desees realizar con el archivo aquí
      found_file=1
  done

  echo "$found_file"

}




function clo (){
  current_dir_this=$(pwd)
  read -p 'ingrese  repo: ' git_repo

  # Set comma as delimiter
  IFS='@'

  read -a strarr <<< "$git_repo"
  #cogemos el path ultimo
  REPO_DIR="${strarr[1]}"
  
  PATH_REPO="${current_dir_this}/${REPO_DIR}"  
  PATH_WINDOWS=$(path_shell_to_path_windows  "${PATH_REPO}") 

  
  echo "PATH_REPO: ${PATH_REPO}"
  echo "PATH_WINDOWS: ${PATH_WINDOWS}"
      if [ -d $PATH_WINDOWS ] 
        then
            
            echo "------------------El repo ya  existe-----------------------------"
            echo "PATH_REPO: ${PATH_REPO}"
    
        else

            echo "------------------clonando-----------------------------"
              $git_repo
              sleep 2
              cd $PATH_REPO
              git checkout qa
              sleep 2
              pwd
              cd ..
          clear
      fi

  # cd $REPO_DIR
  # git checkout qa
  # sleep 2
  # pwd
  # cd ..
}


#######################################
# @descripcion
# @author Cesar Auris
# @return array
# @param name sin referencia
# @version 0.1 2022-03-04
#######################################

function fn_str_length() {
  #----paranmetros
  PARAM_1=$1
  #---variables
  STRLENGTH=$(echo -n $PARAM_1 | wc -m)
  printf $STRLENGTH
}

function fn_spaces(){
  #----paranmetros
  PARAM_1=$1

  STRLENGTH=$(fn_str_length $PARAM_1 )
  for i in $(seq 0 $STRLENGTH); do
  printf " "
  done
}

function fn_tal(){
  PARAM_1=$1
  # tail -f $PARAM_1 | awk '
    
  #   /DEBUG/ {print "\033[32m" $0 "\033[39m"}
  #   /TRACE/ {print "\033[4m" $0 "\033[39m"}
  #   /INFO/ {print "\033[33m" $0 "\033[39m"}
    
  # '

tail -f $PARAM_1 | sed --unbuffered \
    -e 's/\(.* DEBUG.*\)/\o033[1;32m\1\o033[39m/' \
    -e 's/\(.* WARN.*\)/\o033[1;33m\1\o033[39m/' \
    -e 's/\(.* ERROR.*\)/\o033[1;31m\1\o033[39m/' \
    -e 's/\(.* INFO.*\)/\o033[1;30m\1\o033[39m/' \
    -e 's/\(.* TRACE.*\)/\o033[34m\1\o033[39m/'

}


#------------------------------------------------------
#------------ para abrir Ides de Windows
#------------------------------------------------------

#:: Webstorm
function xws (){
  current_dir_this=$(pwd)

   PATH_IDE='/c/Program Files/JetBrains/WebStorm 2021.3/bin/'
   if [ "$CURRENT_TERMINAL" == "mobax" ]
    then
      PATH_IDE='/drives/c/Program Files/JetBrains/WebStorm 2021.3/bin/'
   fi

  PATH_EXE='webstorm64.exe'
  # Aqui ejecutamos el ide con el path para  abrir el proyecto como en VSCODE
  cd "$PATH_IDE" && start $PATH_EXE "${current_dir_this}" && cd "${current_dir_this}"
}

#:: Webstorm
function xidea (){
  current_dir_this=$(pwd)
  PATH_IDE='/c/Program Files/JetBrains/WebStorm 2021.3/bin/'
  if [ "$CURRENT_TERMINAL" == "mobax" ]
   then
     PATH_IDE='/drives/c/Program Files/JetBrains/WebStorm 2021.3/bin/'
  fi
  PATH_EXE='idea64.exe'
  # Aqui ejecutamos el ide con el path para  abrir el proyecto como en VSCODE
  cd "$PATH_IDE" && start $PATH_EXE "${current_dir_this}" && cd "${current_dir_this}"
}


function loadCygwin64(){

    SET CHERE_INVOKING=1 && "C:\cygwin64\bin\bash.exe --login -i" -new_console:p:C:"C:\cygwin64\Cygwin.ico"

}


