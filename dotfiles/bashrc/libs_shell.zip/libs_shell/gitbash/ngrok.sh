#!/bin/bash

# Ruta de instalación de Ngrok
INSTALL_PATH="ngrok"

# Autenticar Ngrok con el token proporcionado
AUTH_TOKEN="1SUMV0bQWCU8lTXuKvpyF6eIEyO_4g3xTatHJ122Xk4BETrSa"
echo "Autenticando Ngrok..."
$INSTALL_PATH authtoken $AUTH_TOKEN

# Preguntar por el puerto a exponer
read -p "Ingresa el puerto local que deseas exponer (por ejemplo, 8080): " PORT

SUBDOMAIN_NGROK_FREE="virtually-first-reindeer.ngrok-free.app"
# Preguntar si desea usar un subdominio personalizado
read -p "¿Deseas usar un subdominio personalizado? (s/n): " USE_SUBDOMAIN

if [[ "$USE_SUBDOMAIN" == "s" || "$USE_SUBDOMAIN" == "S" ]]; then
  echo "Ejecutando Ngrok en el puerto $PORT con el subdominio $SUBDOMAIN_NGROK_FREE..."
  $INSTALL_PATH http --url=$SUBDOMAIN_NGROK_FREE $PORT
else
  echo "Ejecutando Ngrok en el puerto $PORT sin subdominio personalizado..."
  $INSTALL_PATH http $PORT
fi

# Final
echo "Ngrok está corriendo. Abre http://localhost:${PORT} para ver el dashboard."
