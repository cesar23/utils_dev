#!/usr/bin/env bash
#
# ngrok.sh - Panel para exponer puertos locales con ngrok (http / tcp).
# Instala ngrok si falta, configura el authtoken y lista los puertos abiertos.
# Compatible con: Ubuntu/Debian (y WSL), Git Bash en Windows y macOS.
#
# Uso:
#   ./ngrok.sh                  # abre el panel (menu)
#   ./ngrok.sh http             # http, elige puerto en el panel
#   ./ngrok.sh tcp 22           # tcp al puerto 22
#   ./ngrok.sh http 3000 s      # http, puerto 3000, con dominio fijo
#   ./ngrok.sh 3000 n           # (compatible con la version anterior) http, URL aleatoria
#
# Tambien se puede cargar en la consola y usar como comando:
#   source ngrok.sh             # (ej. desde ~/.bashrc)
#   main_ngrok tcp 22
#   main_ngrok http 3000 s
#
# Variables opcionales:
#   NGROK_AUTHTOKEN    authtoken (si no, se usa el ya configurado o se pide por teclado)
#   NGROK_DOMAIN       dominio fijo para http (por defecto el de abajo)
#   NGROK_LOG=stdout   logs en texto en vez de la interfaz TUI de ngrok
#   SHOW_ALL_PORTS=1   muestra tambien puertos >= 49152 (dinamicos/efimeros)

# Nota: no se usa 'set -u' global para poder hacer 'source' sin alterar tu shell.
# main_ngrok corre en una subshell y activa 'set -u' solo dentro.

# Authtoken por defecto (opcional). Se usa solo si no hay NGROK_AUTHTOKEN ni un
# token ya configurado. Deja "xxxxx" para que el script lo pida por teclado.
NGROK_AUTHTOKEN_DEFAULT="xxxxx"

DEFAULT_PORT="8080"
DOMAIN="${NGROK_DOMAIN:-virtually-first-reindeer.ngrok-free.app}"

# =============================================================================
# Variables de entorno y fecha (reutilizadas de tu libreria)
# =============================================================================
CURRENT_USER=$(id -un)
CURRENT_PC_NAME=$(hostname)
MY_INFO="${CURRENT_USER}@${CURRENT_PC_NAME}"
PATH_SCRIPT=$(readlink -f "${BASH_SOURCE[0]:-$0}" 2>/dev/null || echo "$0")
SCRIPT_NAME=$(basename "$PATH_SCRIPT")

# Fecha y hora actual en Peru (UTC -5)
peru_time() {
  date -u -d "-5 hours" "+%Y-%m-%d_%H:%M:%S" 2>/dev/null \
    || TZ="America/Lima" date "+%Y-%m-%d_%H:%M:%S" 2>/dev/null \
    || date "+%Y-%m-%d_%H:%M:%S"
}
utc_time() { date -u "+%Y-%m-%d_%H:%M:%S"; }

# =============================================================================
# Colores
# =============================================================================
Color_Off='\033[0m'
NC='\033[0m'
Black='\033[0;30m'; Red='\033[0;31m'; Green='\033[0;32m'; Yellow='\033[0;33m'
Blue='\033[0;34m'; Purple='\033[0;35m'; Cyan='\033[0;36m'; White='\033[0;37m'
Gray='\033[0;90m'
BBlack='\033[1;30m'; BRed='\033[1;31m'; BGreen='\033[1;32m'; BYellow='\033[1;33m'
BBlue='\033[1;34m'; BPurple='\033[1;35m'; BCyan='\033[1;36m'; BWhite='\033[1;37m'
BGray='\033[1;90m'

msg() {
  local message="$1"
  local level="${2:-OTHER}"
  case "$level" in
    INFO)    echo -e "${BBlue}${message}${Color_Off}" ;;
    WARNING) echo -e "${BYellow}${message}${Color_Off}" ;;
    DEBUG)   echo -e "${BPurple}${message}${Color_Off}" ;;
    ERROR)   echo -e "${BRed}${message}${Color_Off}" ;;
    SUCCESS) echo -e "${BGreen}${message}${Color_Off}" ;;
    *)       echo -e "${BGray}${message}${Color_Off}" ;;
  esac
}
run_cmd() {
  echo -e "  ${BGray}›${Color_Off} ${BYellow}$*${Color_Off}"
  "$@"
}

info() { msg "[+] $*" SUCCESS; }
warn() { msg "[!] $*" WARNING >&2; }
die()  { msg "[x] $*" ERROR >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

# ---------------------------------------------------------------- detectar SO
case "$(uname -s)" in
  Linux*)               OS="linux"   ;;
  Darwin*)              OS="mac"     ;;
  MINGW*|MSYS*|CYGWIN*) OS="windows" ;;
  *) die "Sistema operativo no soportado: $(uname -s)" ;;
esac
case "$OS" in
  linux)   PLATFORM_LABEL="linux" ;;
  mac)     PLATFORM_LABEL="macos" ;;
  windows) PLATFORM_LABEL="gitbash (windows)" ;;
esac

# =============================================================================
# Instalacion de ngrok
# =============================================================================
install_linux_standalone() {
  have curl || die "Se necesita curl para la descarga directa."
  local arch
  case "$(uname -m)" in
    x86_64|amd64)  arch="amd64" ;;
    aarch64|arm64) arch="arm64" ;;
    armv7l|armv6l) arch="arm"   ;;
    *) die "Arquitectura no soportada: $(uname -m)" ;;
  esac
  local dir="$HOME/.local/bin"
  mkdir -p "$dir"
  info "Descargando ngrok (${arch}) en $dir ..."
  curl -fsSL "https://bin.ngrok.com/c/bNyj1mQVY4c/ngrok-v3-stable-linux-${arch}.tgz" \
    | tar -xz -C "$dir" ngrok || die "No se pudo descargar/extraer ngrok."
  export PATH="$dir:$PATH"
}

install_linux() {
  local SUDO=""
  if [ "$(id -u)" -ne 0 ] && have sudo; then SUDO="sudo"; fi

  if have apt-get && { [ "$(id -u)" -eq 0 ] || [ -n "$SUDO" ]; }; then
    info "Instalando ngrok con apt (repositorio oficial de ngrok)..."
    have curl || $SUDO apt-get install -y curl
    if curl -sSL https://ngrok-agent.s3.amazonaws.com/ngrok.asc \
         | $SUDO tee /etc/apt/trusted.gpg.d/ngrok.asc >/dev/null \
       && echo "deb https://ngrok-agent.s3.amazonaws.com bookworm main" \
         | $SUDO tee /etc/apt/sources.list.d/ngrok.list >/dev/null \
       && $SUDO apt-get update \
       && $SUDO apt-get install -y ngrok; then
      return 0
    fi
    warn "La instalacion con apt fallo; se intenta la descarga directa."
  fi
  install_linux_standalone
}

install_mac() {
  have brew || die "Instala Homebrew (https://brew.sh) o descarga ngrok desde https://ngrok.com/download"
  info "Instalando ngrok con Homebrew..."
  brew install ngrok
}

windows_refresh_path() {
  local d
  if have cygpath && [ -n "${LOCALAPPDATA:-}" ]; then
    for d in "$(cygpath -u "$LOCALAPPDATA")/Microsoft/WindowsApps" "$HOME/scoop/shims"; do
      if [ -d "$d" ]; then
        case ":$PATH:" in *":$d:"*) ;; *) PATH="$PATH:$d" ;; esac
      fi
    done
  fi
  export PATH
  hash -r
}

install_windows_zip() {
  have curl || die "Se necesita curl para la descarga directa."
  have powershell.exe || die "Se necesita powershell.exe para descomprimir el zip."
  warn "Descarga directa: Windows Defender a veces marca ngrok.exe por error."
  warn "Se recomienda Microsoft Store (winget install ngrok -s msstore)."
  local dir="$HOME/bin" tmp
  tmp="$(mktemp -d)"
  mkdir -p "$dir"
  info "Descargando ngrok para Windows..."
  curl -fsSL -o "$tmp/ngrok.zip" \
    "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-amd64.zip" \
    || die "No se pudo descargar ngrok.zip."
  powershell.exe -NoProfile -Command \
    "Expand-Archive -Force -Path '$(cygpath -w "$tmp/ngrok.zip")' -DestinationPath '$(cygpath -w "$dir")'" \
    || die "No se pudo descomprimir ngrok.zip."
  rm -rf "$tmp"
  export PATH="$dir:$PATH"
}

install_windows() {
  if have winget; then
    info "Instalando ngrok con winget (Microsoft Store)..."
    if winget install ngrok -s msstore --accept-package-agreements --accept-source-agreements; then
      windows_refresh_path
      have ngrok && return 0
      warn "winget termino, pero ngrok aun no esta en el PATH de esta sesion."
    fi
  fi
  if have scoop; then
    info "Instalando ngrok con Scoop..."
    if scoop install ngrok; then
      windows_refresh_path
      have ngrok && return 0
    fi
  fi
  install_windows_zip
}

ngrok_ver() {
  have ngrok && ngrok version 2>/dev/null | head -n1 | awk '{print $NF}'
}

ensure_ngrok() {
  [ "$OS" = "windows" ] && windows_refresh_path
  if have ngrok; then
    info "ngrok ya esta instalado: $(ngrok_ver)"
    return 0
  fi
  info "ngrok no esta instalado. Instalando para: $OS"
  case "$OS" in
    linux)   install_linux   ;;
    mac)     install_mac     ;;
    windows) install_windows ;;
  esac
  have ngrok || die "ngrok no quedo disponible. Cierra y abre la terminal, o instalalo desde https://ngrok.com/download"
  info "Instalado: $(ngrok_ver)"
}

# =============================================================================
# Authtoken
# =============================================================================
ngrok_has_token() {
  local f
  local files=(
    "$HOME/.config/ngrok/ngrok.yml"
    "$HOME/.ngrok2/ngrok.yml"
    "$HOME/Library/Application Support/ngrok/ngrok.yml"
  )
  if have cygpath && [ -n "${LOCALAPPDATA:-}" ]; then
    files+=("$(cygpath -u "$LOCALAPPDATA")/ngrok/ngrok.yml")
  fi
  for f in "${files[@]}"; do
    if [ -f "$f" ] && grep -q '^[[:space:]]*authtoken:' "$f"; then
      return 0
    fi
  done
  return 1
}

ensure_authtoken() {
  local tok="${NGROK_AUTHTOKEN:-}"
  if [ -z "$tok" ]; then
    if ngrok_has_token; then
      info "Authtoken ya configurado."
      return 0
    fi
    if [ -n "$NGROK_AUTHTOKEN_DEFAULT" ] && [ "$NGROK_AUTHTOKEN_DEFAULT" != "xxxxx" ]; then
      info "Usando NGROK_AUTHTOKEN_DEFAULT del script."
      tok="$NGROK_AUTHTOKEN_DEFAULT"
    fi
  fi
  if [ -z "$tok" ]; then
    echo "Consigue tu authtoken en: https://dashboard.ngrok.com/get-started/your-authtoken"
    read -rsp "Pega tu authtoken (Enter para omitir si ya lo configuraste): " tok
    echo
    [ -z "$tok" ] && { warn "Se omite la autenticacion."; return 0; }
  fi
  info "Guardando authtoken..."
  ngrok config add-authtoken "$tok" || die "No se pudo guardar el authtoken."
}

# =============================================================================
# Puertos locales abiertos (TCP en escucha)
# Salida de list_ports: puerto|proceso|direccion
# =============================================================================
list_ports() {
  case "$OS" in
    linux)
      if have ss; then
        ss -H -ltnp 2>/dev/null | awk '{
          n = split($4, a, ":"); port = a[n]; proc = ""
          if (match($0, /users:\(\("[^"]+"/)) proc = substr($0, RSTART + 9, RLENGTH - 10)
          print port "|" proc "|" $4 }'
      elif have netstat; then
        netstat -ltn 2>/dev/null | awk '$1 ~ /^tcp/ { n = split($4, a, ":"); print a[n] "||" $4 }'
      fi ;;
    mac)
      have lsof && lsof -nP -iTCP -sTCP:LISTEN 2>/dev/null \
        | awk 'NR > 1 { n = split($9, a, ":"); print a[n] "|" $1 "|" $9 }' ;;
    windows)
      awk 'FILENAME == ARGV[1] {
             split($0, f, "\",\""); name = f[1]; sub(/^"/, "", name); pid = f[2]; pname[pid] = name; next }
           $1 == "TCP" && $4 == "LISTENING" {
             k = split($2, a, ":"); print a[k] "|" pname[$5] "|" $2 }' \
        <(tasklist.exe //FO CSV //NH 2>/dev/null | tr -d '\r') \
        <(netstat.exe -ano -p TCP 2>/dev/null | tr -d '\r') ;;
  esac
}

PORTS=(); PROCS=(); ADDRS=()
collect_ports() {
  PORTS=(); PROCS=(); ADDRS=()
  local port proc addr
  while IFS='|' read -r port proc addr; do
    [[ "$port" =~ ^[0-9]+$ ]] || continue
    if [ "${SHOW_ALL_PORTS:-0}" != "1" ] && [ "$port" -ge 49152 ]; then continue; fi
    PORTS+=("$port"); PROCS+=("$proc"); ADDRS+=("$addr")
  done < <(list_ports | sort -t'|' -k1,1n -u)
}

port_is_listening() {
  local p
  for p in ${PORTS[@]+"${PORTS[@]}"}; do
    [ "$p" = "$1" ] && return 0
  done
  return 1
}

# =============================================================================
# Interfaz (panel)
# =============================================================================
hr() { printf '%b' "$Gray"; printf '─%.0s' $(seq 1 62); printf '%b\n' "$NC"; }

kv() { printf '  %b%-10s%b %b%s%b\n' "$Gray" "$1" "$NC" "${3:-$BGreen}" "$2" "$NC"; }

menu_item() {
  # menu_item <tecla> <etiqueta> <descripcion> [color_tecla] [color_etiqueta]
  printf '  %b%-3s%b %b%-10s%b %b%s%b\n' \
    "${4:-$Yellow}" "$1" "$NC" "${5:-$Blue}" "$2" "$NC" "$Gray" "$3" "$NC"
}

ask() {
  # ask "<texto>" <variable> [valor_por_defecto]
  local __prompt="$1" __var="$2" __def="${3:-}" __reply=""
  printf '%b' "  ${BGreen}❯${NC} ${__prompt}"
  IFS= read -r __reply || __reply=""
  printf -v "$__var" '%s' "${__reply:-$__def}"
}

draw_header() {
  [ -t 1 ] && clear
  echo
  printf '  %b  NGROK  %b  %b·%b  %bcontrol panel%b\n' \
    '\033[1;37;48;5;238m' "$NC" "$Gray" "$NC" "$Gray" "$NC"
  echo
  kv "SCRIPT"   "$SCRIPT_NAME"
  kv "USER"     "$MY_INFO"
  kv "PLATFORM" "($PLATFORM_LABEL)"
  local v; v="$(ngrok_ver)"
  if [ -n "$v" ]; then kv "NGROK" "$v" "$BGreen"; else kv "NGROK" "no instalado (se instalara)" "$BYellow"; fi
  kv "UTC"      "$(utc_time)"  "$BCyan"
  kv "UTC-5 PE" "$(peru_time)" "$BCyan"
  echo
  hr
}

draw_ports() {
  echo
  printf '  %bPUERTOS LOCALES ABIERTOS%b %b(TCP, escuchando)%b\n' "$BWhite" "$NC" "$Gray" "$NC"
  echo
  local i n="${#PORTS[@]}"
  if [ "$n" -eq 0 ]; then
    printf '  %b(ningun puerto escuchando)%b\n' "$Gray" "$NC"
  else
    for ((i = 0; i < n; i++)); do
      printf '  %b[%2d]%b  %b%-6s%b %b%-22s%b %b%s%b\n' \
        "$Yellow" "$((i + 1))" "$NC" \
        "$BGreen" "${PORTS[$i]}" "$NC" \
        "$Blue" "${PROCS[$i]:--}" "$NC" \
        "$Gray" "${ADDRS[$i]}" "$NC"
    done
  fi
  echo
  hr
}

draw_menu() {
  echo
  menu_item "01" "HTTP" "ngrok http  · web, URL https publica"
  menu_item "02" "TCP"  "ngrok tcp   · ssh, bases de datos, juegos"
  menu_item "r"  "Refrescar" "vuelve a leer los puertos abiertos" "$BGray" "$Gray"
  menu_item "x"  "Salir" "" "$BRed" "$BRed"
  echo
  hr
  echo
}

show_menu() {
  # Fija PROTO (http|tcp) o termina el script
  local choice
  while true; do
    collect_ports
    draw_header
    draw_ports
    draw_menu
    ask "Elige una opcion: " choice
    case "$choice" in
      1|01|http|h|H) PROTO="http"; return 0 ;;
      2|02|tcp|t|T)  PROTO="tcp";  return 0 ;;
      r|R|"")        continue ;;
      x|X|q|Q)       msg "  Hasta luego." OTHER; exit 0 ;;
      *)             warn "Opcion no valida: $choice"; sleep 1 ;;
    esac
  done
}

choose_port() {
  local sel
  echo
  printf '  %bNumero de la lista, o escribe el puerto (p<puerto> fuerza un puerto, ej: p3).%b\n' "$Gray" "$NC"
  ask "Puerto [${DEFAULT_PORT}]: " sel "$DEFAULT_PORT"
  case "$sel" in
    p[0-9]*) sel="${sel#p}" ;;
    *)
      if [[ "$sel" =~ ^[0-9]+$ ]] && [ "$sel" -ge 1 ] && [ "$sel" -le "${#PORTS[@]}" ]; then
        sel="${PORTS[$((sel - 1))]}"
      fi ;;
  esac
  PORT="$sel"
}

validate_port() {
  case "$PORT" in
    ''|*[!0-9]*) die "Puerto invalido: '$PORT'" ;;
  esac
  { [ "$PORT" -ge 1 ] && [ "$PORT" -le 65535 ]; } || die "Puerto fuera de rango: $PORT"
}

# =============================================================================
# Ejecucion
# =============================================================================
run_ngrok() {
  local args=("$PROTO" "$PORT")
  if [ "$PROTO" = "http" ]; then
    case "$USE" in s|S|y|Y) args+=(--url "https://${DOMAIN}") ;; esac
  fi
  [ "${NGROK_LOG:-}" = "stdout" ] && args+=(--log=stdout)

  echo
  msg "  Panel de ngrok: http://127.0.0.1:4040  (Ctrl+C para detener)" INFO
  run_cmd ngrok "${args[@]}"
  local rc=$?
  echo
  if [ "$rc" -eq 0 ]; then
    msg "  ngrok finalizo." OTHER
  else
    warn "ngrok termino con codigo $rc."
    [ "$PROTO" = "tcp" ] && warn "Si el error menciona verificacion de cuenta o tarjeta, revisa https://dashboard.ngrok.com"
  fi
  return "$rc"
}

main_ngrok() (
  set -u
  PROTO=""; PORT=""; USE=""

  # Argumentos: [http|tcp] [puerto] [s|n]   (tambien: [puerto] [s|n])
  case "${1:-}" in http|tcp) PROTO="$1"; shift ;; esac
  PORT="${1:-}"; USE="${2:-}"
  if [ -z "$PROTO" ] && [ -n "$PORT" ]; then PROTO="http"; fi

  if [ -z "$PROTO" ]; then
    show_menu            # panel completo: fija PROTO
  else
    collect_ports
    if [ -z "$PORT" ]; then draw_ports; fi
  fi

  ensure_ngrok
  ensure_authtoken

  if [ -z "$PORT" ]; then choose_port; fi
  validate_port

  if [ "$PROTO" = "http" ] && [ -z "$USE" ]; then
    ask "Usar dominio fijo ${DOMAIN}? (s/n) [s]: " USE "s"
  fi

  if ! port_is_listening "$PORT"; then
    warn "No veo ningun servicio escuchando en el puerto $PORT."
    local go
    ask "Continuar de todos modos? (s/n) [s]: " go "s"
    case "$go" in s|S|y|Y) ;; *) msg "  Cancelado." OTHER; exit 0 ;; esac
  fi

  run_ngrok
)

# Si se ejecuta directo (./ngrok.sh ...) corre main_ngrok; si se hace "source", solo carga la funcion.
#if [ "${BASH_SOURCE[0]}" = "$0" ]; then
#  main_ngrok "$@"
#fi