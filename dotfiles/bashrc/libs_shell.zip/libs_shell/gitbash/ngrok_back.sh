#!/bin/bash

#!/usr/bin/env bash
#
# ngrok.sh - Instala ngrok si falta, configura el authtoken y expone un puerto local.
# Compatible con: Ubuntu/Debian (y WSL), Git Bash en Windows y macOS.
#
# Uso:
#   ./ngrok.sh                 # pregunta puerto y si usar dominio fijo
#   ./ngrok.sh 3000 s          # puerto 3000, con dominio fijo
#   ./ngrok.sh 3000 n          # puerto 3000, URL aleatoria
#
# Variables opcionales:
#   NGROK_AUTHTOKEN   authtoken (si no, se pide por teclado la primera vez)
#   NGROK_DOMAIN      dominio fijo (por defecto el de abajo)
#   NGROK_LOG=stdout  muestra logs en texto en vez de la interfaz TUI
#                     (util si la TUI se ve mal en la terminal de Git Bash)

set -u

# Authtoken por defecto (opcional). Se usa solo si no hay NGROK_AUTHTOKEN ni un
# token ya configurado. Deja "xxxxx" para que el script lo pida por teclado.
NGROK_AUTHTOKEN_DEFAULT="1SUMV0bQWCU8lTXuKvpyF6eIEyO_4g3xTatHJ122Xk4BETrSa"

DEFAULT_PORT="8080"
DOMAIN="${NGROK_DOMAIN:-virtually-first-reindeer.ngrok-free.app}"

info() { printf '[+] %s\n' "$*"; }
warn() { printf '[!] %s\n' "$*" >&2; }
die()  { printf '[x] %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

# ---------------------------------------------------------------- detectar SO
case "$(uname -s)" in
  Linux*)               OS="linux"   ;;
  Darwin*)              OS="mac"     ;;
  MINGW*|MSYS*|CYGWIN*) OS="windows" ;;
  *) die "Sistema operativo no soportado: $(uname -s)" ;;
esac

# ------------------------------------------------------------- instalaciones
install_linux_standalone() {
  have curl || die "Se necesita curl para la descarga directa."
  local arch
  case "$(uname -m)" in
    x86_64|amd64)  arch="amd64" ;;
    aarch64|arm64) arch="arm64" ;;
    armv7l|armv6l) arch="arm"   ;;
    *) die "Arquitectura no soportada: $(uname -m)" ;;
  esac
  local dir="$HOME/.local/bin"
  mkdir -p "$dir"
  info "Descargando ngrok (${arch}) en $dir ..."
  curl -fsSL "https://bin.ngrok.com/c/bNyj1mQVY4c/ngrok-v3-stable-linux-${arch}.tgz" \
    | tar -xz -C "$dir" ngrok || die "No se pudo descargar/extraer ngrok."
  export PATH="$dir:$PATH"
}

install_linux() {
  local SUDO=""
  if [ "$(id -u)" -ne 0 ] && have sudo; then SUDO="sudo"; fi

  if have apt-get && { [ "$(id -u)" -eq 0 ] || [ -n "$SUDO" ]; }; then
    info "Instalando ngrok con apt (repositorio oficial de ngrok)..."
    have curl || $SUDO apt-get install -y curl
    if curl -sSL https://ngrok-agent.s3.amazonaws.com/ngrok.asc \
         | $SUDO tee /etc/apt/trusted.gpg.d/ngrok.asc >/dev/null \
       && echo "deb https://ngrok-agent.s3.amazonaws.com bookworm main" \
         | $SUDO tee /etc/apt/sources.list.d/ngrok.list >/dev/null \
       && $SUDO apt-get update \
       && $SUDO apt-get install -y ngrok; then
      return 0
    fi
    warn "La instalacion con apt fallo; se intenta la descarga directa."
  fi
  install_linux_standalone
}

install_mac() {
  have brew || die "Instala Homebrew (https://brew.sh) o descarga ngrok desde https://ngrok.com/download"
  info "Instalando ngrok con Homebrew..."
  brew install ngrok
}

windows_refresh_path() {
  local d
  if have cygpath && [ -n "${LOCALAPPDATA:-}" ]; then
    for d in "$(cygpath -u "$LOCALAPPDATA")/Microsoft/WindowsApps" "$HOME/scoop/shims"; do
      if [ -d "$d" ]; then
        case ":$PATH:" in *":$d:"*) ;; *) PATH="$PATH:$d" ;; esac
      fi
    done
  fi
  export PATH
  hash -r
}

install_windows_zip() {
  have curl || die "Se necesita curl para la descarga directa."
  have powershell.exe || die "Se necesita powershell.exe para descomprimir el zip."
  warn "Descarga directa: Windows Defender a veces marca ngrok.exe por error."
  warn "Se recomienda Microsoft Store (winget install ngrok -s msstore)."
  local dir="$HOME/bin" tmp
  tmp="$(mktemp -d)"
  mkdir -p "$dir"
  info "Descargando ngrok para Windows..."
  curl -fsSL -o "$tmp/ngrok.zip" \
    "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-amd64.zip" \
    || die "No se pudo descargar ngrok.zip."
  powershell.exe -NoProfile -Command \
    "Expand-Archive -Force -Path '$(cygpath -w "$tmp/ngrok.zip")' -DestinationPath '$(cygpath -w "$dir")'" \
    || die "No se pudo descomprimir ngrok.zip."
  rm -rf "$tmp"
  export PATH="$dir:$PATH"
}

install_windows() {
  if have winget; then
    info "Instalando ngrok con winget (Microsoft Store)..."
    if winget install ngrok -s msstore --accept-package-agreements --accept-source-agreements; then
      windows_refresh_path
      have ngrok && return 0
      warn "winget termino, pero ngrok aun no esta en el PATH de esta sesion."
    fi
  fi
  if have scoop; then
    info "Instalando ngrok con Scoop..."
    if scoop install ngrok; then
      windows_refresh_path
      have ngrok && return 0
    fi
  fi
  install_windows_zip
}

ensure_ngrok() {
  [ "$OS" = "windows" ] && windows_refresh_path
  if have ngrok; then
    info "ngrok ya esta instalado: $(ngrok version 2>/dev/null | head -n1)"
    return 0
  fi
  info "ngrok no esta instalado. Instalando para: $OS"
  case "$OS" in
    linux)   install_linux   ;;
    mac)     install_mac     ;;
    windows) install_windows ;;
  esac
  have ngrok || die "ngrok no quedo disponible. Cierra y abre la terminal, o instalalo desde https://ngrok.com/download"
  info "Instalado: $(ngrok version 2>/dev/null | head -n1)"
}

# ------------------------------------------------------------- authtoken
ngrok_has_token() {
  local f
  local files=(
    "$HOME/.config/ngrok/ngrok.yml"
    "$HOME/.ngrok2/ngrok.yml"
    "$HOME/Library/Application Support/ngrok/ngrok.yml"
  )
  if have cygpath && [ -n "${LOCALAPPDATA:-}" ]; then
    files+=("$(cygpath -u "$LOCALAPPDATA")/ngrok/ngrok.yml")
  fi
  for f in "${files[@]}"; do
    if [ -f "$f" ] && grep -q '^[[:space:]]*authtoken:' "$f"; then
      return 0
    fi
  done
  return 1
}

ensure_authtoken() {
  local tok="${NGROK_AUTHTOKEN:-}"
  if [ -z "$tok" ]; then
    if ngrok_has_token; then
      info "Authtoken ya configurado."
      return 0
    fi
    # Sin variable ni configuracion previa: usa el token por defecto si es real
    if [ -n "$NGROK_AUTHTOKEN_DEFAULT" ] && [ "$NGROK_AUTHTOKEN_DEFAULT" != "xxxxx" ]; then
      info "Usando NGROK_AUTHTOKEN_DEFAULT del script."
      tok="$NGROK_AUTHTOKEN_DEFAULT"
    fi
  fi
  if [ -z "$tok" ]; then
    echo "Consigue tu authtoken en: https://dashboard.ngrok.com/get-started/your-authtoken"
    read -rsp "Pega tu authtoken (Enter para omitir si ya lo configuraste): " tok
    echo
    [ -z "$tok" ] && { warn "Se omite la autenticacion."; return 0; }
  fi
  info "Guardando authtoken..."
  ngrok config add-authtoken "$tok" || die "No se pudo guardar el authtoken."
}

# ------------------------------------------------------------------ main

ngrok_main(){
#  ensure_ngrok
#  ensure_authtoken
#
#  PORT="${1:-}"
#  if [ -z "$PORT" ]; then
#    read -rp "Puerto local a exponer [${DEFAULT_PORT}]: " PORT
#    PORT="${PORT:-$DEFAULT_PORT}"
#  fi
#  case "$PORT" in
#    ''|*[!0-9]*) die "Puerto invalido: '$PORT'" ;;
#  esac
#  { [ "$PORT" -ge 1 ] && [ "$PORT" -le 65535 ]; } || die "Puerto fuera de rango: $PORT"
#
#  USE="${2:-}"
#  if [ -z "$USE" ]; then
#    read -rp "Usar dominio fijo ${DOMAIN}? (s/n) [s]: " USE
#    USE="${USE:-s}"
#  fi
#
#  args=(http "$PORT")
#  case "$USE" in
#    s|S|y|Y) args+=(--url "https://${DOMAIN}"); info "Puerto $PORT con dominio fijo https://${DOMAIN}" ;;
#    *)       info "Puerto $PORT con URL aleatoria" ;;
#  esac
#  [ "${NGROK_LOG:-}" = "stdout" ] && args+=(--log=stdout)
#
#  info "Panel de ngrok: http://127.0.0.1:4040  (Ctrl+C para detener)"
#  exec ngrok "${args[@]}"
echo "ngrok main"
}