#!/bin/bash

# Script interactivo para navegar por directorios

# Colores para hacerlo más bonito
Color_Off='\033[0m'       # Reset de color.
Black='\033[0;30m'        # Negro.
Red='\033[0;31m'          # Rojo.
Green='\033[0;32m'        # Verde.
Yellow='\033[0;33m'       # Amarillo.
Blue='\033[0;34m'         # Azul.
Purple='\033[0;35m'       # Púrpura.
Cyan='\033[0;36m'         # Cian.
White='\033[0;37m'        # Blanco.
Gray='\033[0;90m'         # Gris.

BBlack='\e[1;30m'       # Negro (negrita).
BRed='\e[1;31m'         # Rojo (negrita).
BGreen='\e[1;32m'       # Verde (negrita).
BYellow='\e[1;33m'      # Amarillo (negrita).
BBlue='\e[1;34m'        # Azul (negrita).
BPurple='\e[1;35m'      # Púrpura (negrita).
BCyan='\e[1;36m'        # Cian (negrita).
BWhite='\e[1;37m'       # Blanco (negrita).
BGray='\e[1;90m'        # Gris (negrita).



edit_file_select() {
    local file="$1"
    if [[ ! -f "$file" ]]; then
        echo -e "${Red}El fichero no existe: $file${Color_Off}"
        return 1
    fi
    # Verificar si es archivo de texto
    if ! file --mime-type "$file" | grep -q 'text/'; then
        echo -e "${Red}Solo se pueden editar archivos de texto plano.${Color_Off}"
        return 1
    fi
    if command -v nvim >/dev/null 2>&1; then
        nvim "$file"
    else
        nano "$file"
    fi
}


# Función para obtener el icono según el tipo de archivo
get_icon() {
    local path="$1"
    if [ -d "$path" ]; then
        echo "📁"
    elif [ -x "$path" ]; then
        echo "⚙️"
    elif file --mime-type "$path" | grep -q 'text/'; then
        echo "📝"
    else
        echo "📄"
    fi
}

convert_string_to_regex() {
    local input=$1
    # Si el input empieza por un punto, no añadas otro
    if [[ "$input" == .* ]]; then
        echo ".*${input}$"
    else
        echo ".*\.${input}$"
    fi
}

convert_regex_to_literal() {
    local regex="$1"
    # Extrae la extensión con punto antes del $ final, por ejemplo: .conf de .*\.*.conf$
    if [[ "$regex" =~ (\.[a-zA-Z0-9_]+)\$?$ ]]; then
        echo "${BASH_REMATCH[1]}"
    else
        # Si no hay coincidencia, devuelve el input original
        echo "$regex"
    fi
}



# --- FUNCIONES DE BUSQUEDA ---



search_dirs_regex() {
    local current_dir="$PWD"
    while true; do
        clear
        echo -e "${Blue}========== BÚSQUEDA DE CARPETAS ==========${Color_Off}"
        echo -e "${Cyan}Directorio base:${Color_Off} ${Yellow}$current_dir${Color_Off}"
        echo -e "${Gray}--------------------------------------------${Color_Off}"
        echo -e "${Green}Búsqueda de carpetas por nombre carpeta (insensible a mayúsculas)${Color_Off}"
        echo -e "${Gray}--------------------------------------------${Color_Off}"
        set -f
        read -e -p "Patrón de búsqueda (regex, vacío para mostrar todas): " regex
        set +f

        # find /d/repos/curso_linux -type d -iname "*texto*"
        
        # mapfile -t matches < <(find "$current_dir" -type d -iname "*${regex}*" 2>/dev/null | grep -i --color=never -E "$regex")
        mapfile -t matches < <(find "$current_dir"  \
                     -type d \( -name ".git" -o -name "node_modules" \) -prune -false -o -type d -iname  "*${regex}*" 2>/dev/null | grep -i --color=never -E "$regex")
      

        if [[ ${#matches[@]} -eq 0 ]]; then
            echo -e "${Red}No se encontraron carpetas.${Color_Off}"
            read -p "Presiona Enter para intentar de nuevo..."
            continue
        fi

        echo -e "${Cyan}Resultados:${Color_Off}"
        local i=1
        for dir in "${matches[@]}"; do
            display_name="$dir"
            if [[ "$regex" != "" ]]; then
                display_name=$(awk -v re="$regex" -v y="$Yellow" -v n="$Color_Off" '{gsub(re, y "&" n, $0); print}' <<< "$display_name")
            fi
            echo -e "  [$i] 📁 $display_name"
            ((i++))
        done
        echo -e "${Gray}--------------------------------------------${Color_Off}"
        echo -e "  [numero] para escoger carpeta${Color_Off}"
        echo -e "  [s] ${Yellow}Volver a buscar${Color_Off}"
        echo -e "  [x]  ${BRed}Salir${Color_Off}"
        read -e -p "Selecciona una  opcion: " choice
        if [[ "$choice" == "x" || "$choice" == "X" ]]; then
            break
        elif [[ "$choice" == "s" || "$choice" == "S" ]]; then
            continue
        elif [[ "$choice" =~ ^[0-9]+$ && "$choice" -ge 1 && "$choice" -le "${#matches[@]}" ]]; then
            cd "${matches[$((choice-1))]}" || { echo -e "${Red}No se pudo cambiar de directorio.${Color_Off}"; read -p "Presiona Enter..."; continue; }
            echo -e "${Green}Ahora estás en: $(pwd)${Color_Off}"
            while true; do
                clear
                echo -e "${Gray}¿Qué deseas hacer ahora?${Color_Off}"
                echo -e "  [s] ${Yellow}Seguir buscando directorios${Color_Off}"
                echo -e "  [x]  ${BRed}Salir${Color_Off}"
                read -e -p "Selecciona una opción: " next_action
                if [[ "$next_action" == "x" || "$next_action" == "X" ]]; then
                    return
                elif [[ "$next_action" == "s" || "$next_action" == "S" ]]; then
                    break
                else
                    echo -e "${Red}Opción inválida.${Color_Off}"
                fi
            done
            break
        else
            echo -e "${Red}Opción inválida.${Color_Off}"
            read -p "Presiona Enter para continuar..."
        fi
    done
}

search_files_regex() {
    local current_dir="$PWD"
    while true; do
        clear
        echo -e "${Cyan}Directorio base:${Color_Off} $current_dir"
        echo -e "${Green}Búsqueda de ficheros por palabra o regex (insensible a mayúsculas)${Color_Off}"
        echo -e "${Yellow}Si usas comodines (ej: *.conf), escríbelos entre comillas para evitar expansión por el shell.${Color_Off}"
        set -f  # Desactivar globbing
        read -e -p "Patrón de búsqueda (ej: palabra o *.conf): " regex
        echo -e "regex:${regex}"
        set +f  # Reactivar globbing
        if_regex=false
        regex_pattern=""

        # Solo si contiene *, [, ], {, }, o + se usa regex
        if [[ "$regex" == *'*'* || "$regex" == *'['* || "$regex" == *']'* || "$regex" == *'{'* || "$regex" == *'}'* || "$regex" == *'+'* || "$regex" == *'.'* ]]; then
            if_regex=true
            echo -e "${Gray}regex:si${Color_Off}"
            regex_pattern=$(convert_string_to_regex "$regex" )
            #mapfile -t matches < <(find "$current_dir" -type f -iregex "$regex_pattern" 2>/dev/null)
            mapfile -t matches < <(find "$current_dir" -type d \( -name ".git" -o -name "node_modules" \) -prune -false -o \
                                     -type f -iregex "$regex_pattern" 2>/dev/null)
        else
            if_regex=false
            echo -e "${Gray}regex:si${Color_Off}"
            #mapfile -t matches < <(find "$current_dir" -type f -iname "*${regex}*" 2>/dev/null)
            mapfile -t matches < <(find "$current_dir"  -type d \( -name ".git" -o -name "node_modules" \) -prune -false -o \
                                    -type f -iname "*${regex}*" 2>/dev/null)
        fi
        if [[ ${#matches[@]} -eq 0 ]]; then
            echo -e "${Red}No se encontraron ficheros.${Color_Off}"
            read -p "Presiona Enter para intentar de nuevo..."
            continue
        fi
        echo -e "${Cyan}Resultados:${Color_Off}"
        local i=1
        for file in "${matches[@]}"; do
            display_name="$file"

            if [[ "$if_regex" == true ]]; then
                literal_pattern=$(convert_regex_to_literal "$regex_pattern")
                display_name=$(awk -v re="$literal_pattern" -v y="$Yellow" -v n="$Color_Off" '{gsub(re, y "&" n, $0); print}' <<< "$display_name")
            else
                display_name=$(awk -v re="$regex" -v y="$Yellow" -v n="$Color_Off" '{gsub(re, y "&" n, $0); print}' <<< "$display_name")
            fi
            echo -e "  [$i] 📝 $display_name"
            ((i++))
        done
        echo -e "${Gray}--------------------------------------------${Color_Off}"
        echo -e "  [number] ${Yellow}para editar fichero${Color_Off}"
        echo -e "  [s] ${Yellow}Volver a buscar${Color_Off}"
        echo -e "  [x]  ${BRed}Salir${Color_Off}"


        read -e -p "Selecciona una opcion: " choice
        if [[ "$choice" == "x" || "$choice" == "X" ]]; then
            break
        elif [[ "$choice" == "s" || "$choice" == "S" ]]; then
            continue
        elif [[ "$choice" =~ ^[0-9]+$ && "$choice" -ge 1 && "$choice" -le "${#matches[@]}" ]]; then
            edit_file_select "${matches[$((choice-1))]}"
            while true; do
                clear
                echo -e "${Gray}¿Qué deseas hacer ahora?${Color_Off}"
                echo -e"  [s] ${Yellow}Seguir buscando fichero${Color_Off}"
                echo -e "  [x]  ${BRed}Salir${Color_Off}"
                read -e -p "Selecciona una opción: " next_action
                if [[ "$next_action" == "x" || "$next_action" == "X" ]]; then
                    return
                elif [[ "$next_action" == "s" || "$next_action" == "S" ]]; then
                    break
                else
                    echo -e "${Red}Opción inválida.${Color_Off}"
                fi
            done
            break
        else
            echo -e "${Red}Opción inválida.${Color_Off}"
            read -p "Presiona Enter para continuar..."
        fi
    done
}

navegar_directorios() {
    local current_dir="$PWD"
    while true; do
        clear
        echo -e "${Cyan}Estás en:${Color_Off} $current_dir"
        echo
        shopt -s dotglob
        # Solo directorios
        entries=()
        for item in "$current_dir"/*; do
            [ -d "$item" ] && entries+=("$item")
        done
        shopt -u dotglob
        # Mostrar opciones
        local i=1
        for item in "${entries[@]}"; do
            icon=$(get_icon "$item")
            echo "  [$i] $icon $(basename "$item")"
            ((i++))
        done
        echo -e "${Gray}--------------------------------------------${Color_Off}"
        echo -e "  [..] ${Yellow}⬆️  Subir${Color_Off}"
        echo -e "  [x]  ${BRed}Salir${Color_Off}"
        echo
        read -e -p "Selecciona número para entrar a directorio, '..' para subir, 'x' para salir: " input
        if [[ "$input" == "x" || "$input" == "X" ]]; then
            echo -e "${Red}Saliendo...${Color_Off}"
            break
        elif [[ "$input" == ".." ]]; then
            if [[ "$current_dir" != "/" ]]; then
                current_dir="$(dirname "$current_dir")"
                cd "$current_dir"
            fi
        elif [[ "$input" =~ ^[0-9]+$ && "$input" -ge 1 && "$input" -le "${#entries[@]}" ]]; then
            selected="${entries[$((input-1))]}"
            if [ -d "$selected" ]; then
                current_dir="$selected"
                cd "$current_dir"
                # No mostrar mensaje, simplemente refrescar el listado
            else
                echo -e "${Red}Solo puedes seleccionar directorios.${Color_Off}"
                read -p "Presiona Enter para continuar..."
            fi
        else
            echo -e "${Red}Opción inválida.${Color_Off}"
            read -p "Presiona Enter para continuar..."
        fi
    done
}


        




function menu_search() {
    # --- MENU INICIAL ---
    while true; do
        clear
        echo -e "${Blue}========== EXPLORADOR DE FICHEROS 2.0.1 ==========${Color_Off}"
        echo -e "${Cyan}Directorio actual:${Color_Off} ${Yellow}$PWD${Color_Off}"
        echo -e "${Gray}--------------------------------------------${Color_Off}"
        echo -e "  ${Yellow}[1]${Color_Off} ${Green}Navegar modo Windows ${Color_Off}"
        echo -e "  ${Yellow}[2]${Color_Off} ${Green}Búsqueda de carpetas modo (FZF)${Color_Off}"
        echo -e "  ${Yellow}[3]${Color_Off} ${Green}Búsqueda de Ficheros modo (FZF)${Color_Off}"
        echo -e "  ${Red}[x]${Color_Off} ${BRed}Salir${Color_Off}"
        echo -e "${Gray}--------------------------------------------${Color_Off}"
        read -p "> " modo
        case "$modo" in
            1)
                navegar_directorios
                ;;
            2)
                search_dirs_regex
                ;;
            3)
                search_files_regex
                ;;
            x|X)
                echo -e "${Red}Saliendo...${Color_Off}"
                break
                ;;
            *)
                echo -e "${Red}Opción inválida.${Color_Off}"
                read -p "Presiona Enter para continuar..."
                ;;
        esac
    done
}



# --- FIN DEL SCRIPT ---
