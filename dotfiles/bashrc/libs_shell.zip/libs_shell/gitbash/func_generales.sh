# ============================================================================
# gitbash/func_generales.sh
# Funciones de utilidad para la terminal (docker, fzf, prompts, ficheros, etc.)
#
# Este archivo se carga de forma PEREZOSA (lazy): .bashrc define un "stub"
# (función liviana) por cada nombre de función de aquí. El stub no hace nada
# hasta que la invocas por primera vez; en ese momento se hace
# source de este archivo (definiendo las funciones REALES, que reemplazan
# a los stubs) y se ejecuta la que llamaste. El resto de la sesión, todas
# las funciones de este archivo ya están cargadas y se llaman directo,
# sin ninguna capa extra.
# ============================================================================

general_cf ()
{ 
    local FILE_NAME="$1";
    echo "";
    if [ -z "$FILE_NAME" ]; then
        echo -e "${BBlue}✏️️  Nombre del archivo a crear (ej. mi_script.sh):${Color_Off}";
        read -rp "> " FILE_NAME;
    fi;
    if [ -z "$FILE_NAME" ]; then
        echo -e "${BRed}❌ Error: Debes ingresar un nombre de archivo válido.${Color_Off}";
        return 1;
    fi;
    if [ -f "$FILE_NAME" ]; then
        echo -e "${BYellow}⚠️  El archivo ya existe. ¿Deseas sobrescribirlo? [s/n]${Color_Off}";
        read -rp "> " RESP;
        [[ "$RESP" != [sS] ]] && echo -e "${BRed}❌ Cancelado.${Color_Off}" && return 1;
    fi;
    echo "";
    echo -e "${BPurple}✏️  Escribe el contenido del archivo (Ctrl+D para finalizar):${Color_Off}";
    CONTENT=$(cat);
    echo "$CONTENT" > "$FILE_NAME";
    chmod +x "$FILE_NAME";
    echo "";
    echo -e "${BGreen}✅ Archivo '$FILE_NAME' creado correctamente y marcado como ejecutable.${Color_Off}"
}

general_clear_saved_prompt ()
{ 
    if [ -f "$PROMPT_CONFIG_FILE" ]; then
        rm "$PROMPT_CONFIG_FILE";
        echo -e "${BGreen}Prompt guardado eliminado${Color_Off}";
    else
        echo -e "${BRed}No hay prompt guardado para eliminar${Color_Off}";
    fi
}

general_comparar ()
{ 
    diff -y "$1" "$2"
}

general_dcrestart ()
{ 
    docker-compose down && docker-compose up -d
}

general_dinspect ()
{ 
    if [ -z "$1" ]; then
        echo "Uso: dinspect <nombre_contenedor>";
    else
        docker inspect "$1";
    fi
}

general_directory_space ()
{ 
    local path="${1:-.}";
    echo "Analizando: $path";
    du -h --max-depth=1 "$path" | sort -rh
}

general_dirsize ()
{ 
    du -sh "${1:-.}"/* 2> /dev/null | sort -rh
}

general_dlogin ()
{ 
    cls 2> /dev/null || clear;
    general_listar_contenedores;
    echo -e "${Yellow}";
    read -p "Ingrese el nombre o ID del contenedor: " CONTAINER;
    echo -e "${Color_Off}";
    if [ -z "$CONTAINER" ]; then
        echo -e "${Red}Error: No se ingresó un nombre o ID de contenedor.${Color_Off}";
        return 1;
    fi;
    general_entrar_contenedor "$CONTAINER";
    RET=$?;
    if [ $RET -eq 0 ]; then
        echo -e "${Green}Sesión del contenedor finalizada correctamente.${Color_Off}";
    else
        echo -e "${Red}Hubo un problema al intentar acceder al contenedor.${Color_Off}";
    fi
}

general_droot ()
{ 
    general_listar_contenedores;
    echo -e "${Yellow}";
    read -p "Ingrese el nombre o ID del contenedor: " CONTAINER;
    echo -e "${Color_Off}";
    docker exec -it --user root "$CONTAINER" bash
}

general_entrar_contenedor ()
{ 
    local CONTAINER=$1;
    echo -e "${Green}Entrando al contenedor '${Yellow}$CONTAINER${Green}'...${Color_Off}";
    echo -e "${Gray}docker exec -it "$CONTAINER" bash ${Color_Off}";
    if docker exec -it "$CONTAINER" bash 2> /dev/null; then
        return 0;
    else
        echo -e "${Yellow}bash no está disponible en el contenedor, intentando con sh...${Color_Off}";
        docker exec -it "$CONTAINER" /bin/sh;
        return $?;
    fi
}

general_find_files_by_size ()
{ 
    local directory=${1:-.};
    local size=${2:-1M};
    if [ ! -d "$directory" ]; then
        echo "Error: El directorio '$directory' no existe.";
        return 1;
    fi;
    echo "Buscando archivos en '$directory' con un tamaño mayor a $size:";
    echo "------------------------------------------------------------";
    find "$directory" -type f -size +"$size" -exec du -h {} + 2> /dev/null | sort -rh
}

general_find_heaviest_files ()
{ 
    local directory=${1:-.};
    local limit=${2:-10};
    echo "Buscando los $limit archivos más pesados en el directorio: $directory";
    echo "-----------------------------------------------";
    find "$directory" -type f -exec du -h {} + | sort -rh | head -n "$limit"
}

general_generar_ssh ()
{ 
    ssh-keygen -t rsa -b 4096 -C "$1";
    echo "Clave SSH generada para: $1"
}

general_listar_archivos_recientes_modificados ()
{ 
    local path="${1:-.}";
    local count="${2:-10}";
    if [ ! -d "$path" ]; then
        echo "❌ Error: '$path' is not a valid directory.";
        return 1;
    fi;
    echo "📁 Showing the last $count modified files in: $path";
    echo "─────────────────────────────────────────────────────────────";
    find "$path" -type f -printf '%TY-%Tm-%Td %TH:%TM:%TS %p\n' | sort | tail -n "$count"
}

general_listar_contenedores ()
{ 
    echo -e "${Cyan}Contenedores en ejecución:${Color_Off}";
    docker ps --format "table {{.ID}}\t{{.Names}}\t{{.Status}}"
}

general_log ()
{ 
    if [ $# -eq 0 ]; then
        echo -e "--- ${Yellow}Advertencia:${Color_Off} no se proporcionaron rutas.";
        echo -e "Uso: log <archivo|directorio> [más_rutas...]";
        echo -e "Ej.:  log /var/log/mail.log /var/log/lfd.log /var/log";
        return 2;
    fi;
    if ! command -v lnav > /dev/null 2>&1; then
        echo -e "--- ${Red}Error:${Color_Off} 'lnav' no está instalado o no está en el PATH.";
        echo -e "     Instálalo con: ${Green}sudo snap install lnav${Color_Off} (o tu método preferido)";
        return 127;
    fi;
    local found=();
    local missing=0;
    for path in "$@";
    do
        if [ -e "$path" ]; then
            found+=("$path");
        else
            echo -e "--- ${Yellow}Aviso:${Color_Off} la ruta '${path}' no existe (omitida).";
            missing=$((missing+1));
        fi;
    done;
    if [ ${#found[@]} -eq 0 ]; then
        echo -e "--- ${Red}Error:${Color_Off} no hay rutas válidas para abrir.";
        echo -e "Uso: log <archivo|directorio> [más_rutas...]";
        echo -e "Ej.:  log /var/log/mail.log /var/log/lfd.log /var/log";
        return 1;
    fi;
    TZ=America/Lima lnav "${found[@]}"
}


general_mkcd ()
{ 
    mkdir -p "$1" && cd "$1"
}

general_mostrar_uso ()
{ 
    echo "Uso: vi [archivo]"
}

general_p ()
{ 
    if [[ "$1" == "-h" || "$1" == "--help" ]]; then
        echo -e "${BYellow}=== PROMPTS DISPONIBLES ===${Color_Off}";
        echo "";
        echo -e "${BGreen}p1${Color_Off} - ${Cyan}Prompt Completo${Color_Off}";
        echo -e "     Fecha y hora completa + usuario@host + directorio + Git + indicador root";
        echo -e "     ${Gray}Ejemplo: [2025-09-22 15:30:25] cesar@host /d/repos/curso_linux (master) \$${Color_Off}";
        echo "";
        echo -e "${BGreen}p2${Color_Off} - ${Cyan}Hacker Style (Cyberpunk)${Color_Off}";
        echo -e "     Estilo hacker con líneas elegantes y colores cyan/magenta";
        echo -e "     ${Gray}Ejemplo: ╭─ cesar@host─[/path] (branch) [15:30:25]${Color_Off}";
        echo -e "     ${Gray}         ╰─💀 ❯${Color_Off}";
        echo "";
        echo -e "${BGreen}p2_matrix${Color_Off} - ${Cyan}Matrix Green${Color_Off}";
        echo -e "     Estilo Matrix clásico con colores verdes";
        echo -e "     ${Gray}Ejemplo: ╭─ cesar@host─[/path] (branch) [15:30:25]${Color_Off}";
        echo -e "     ${Gray}         ╰─⚡ ❯${Color_Off}";
        echo "";
        echo -e "${BGreen}p2_cyberpunk${Color_Off} - ${Cyan}Cyberpunk${Color_Off}";
        echo -e "     Colores cyan/magenta estilo cyberpunk";
        echo -e "     ${Gray}Ejemplo: ╭─ cesar@host─[/path] (branch) [15:30:25]${Color_Off}";
        echo -e "     ${Gray}         ╰─💀 ❯${Color_Off}";
        echo "";
        echo -e "${BGreen}p2_neon${Color_Off} - ${Cyan}Neon Blue${Color_Off}";
        echo -e "     Azul neón vibrante";
        echo -e "     ${Gray}Ejemplo: ╭─ cesar@host─[/path] (branch) [15:30:25]${Color_Off}";
        echo -e "     ${Gray}         ╰─❯${Color_Off}";
        echo "";
        echo -e "${BGreen}p2_terminal${Color_Off} - ${Cyan}Hacker Terminal${Color_Off}";
        echo -e "     Verde/negro intenso estilo terminal hacker";
        echo -e "     ${Gray}Ejemplo: ╭─ cesar@host─[/path] (branch) [15:30:25]${Color_Off}";
        echo -e "     ${Gray}         ╰─❯${Color_Off}";
        echo "";
        echo -e "${BGreen}p2_fire${Color_Off} - ${Cyan}Fire${Color_Off}";
        echo -e "     Colores rojo/naranja como fuego";
        echo -e "     ${Gray}Ejemplo: ╭─ cesar@host─[/path] (branch) [15:30:25]${Color_Off}";
        echo -e "     ${Gray}         ╰─❯${Color_Off}";
        echo "";
        echo -e "${BGreen}p2_rainbow${Color_Off} - ${Cyan}Rainbow Hacker${Color_Off}";
        echo -e "     Multicolor vibrante";
        echo -e "     ${Gray}Ejemplo: ╭─ cesar@host─[/path] (branch) [15:30:25]${Color_Off}";
        echo -e "     ${Gray}         ╰─❯${Color_Off}";
        echo "";
        echo -e "${BGreen}p2_elite${Color_Off} - ${Cyan}Dark Mode Elite${Color_Off}";
        echo -e "     Gris/blanco elegante";
        echo -e "     ${Gray}Ejemplo: ╭─ cesar@host─[/path] (branch) [15:30:25]${Color_Off}";
        echo -e "     ${Gray}         ╰─❯${Color_Off}";
        echo "";
        echo -e "${BGreen}p2_retro${Color_Off} - ${Cyan}Retro Wave${Color_Off}";
        echo -e "     Magenta/cyan estilo años 80";
        echo -e "     ${Gray}Ejemplo: ╭─ cesar@host─[/path] (branch) [15:30:25]${Color_Off}";
        echo -e "     ${Gray}         ╰─❯${Color_Off}";
        echo "";
        echo -e "${BGreen}p3${Color_Off} - ${Cyan}Pure/Minimal${Color_Off}";
        echo -e "     Directorio actual + rama Git (si existe) + símbolo";
        echo -e "     ${Gray}Ejemplo: curso_linux${BYellow}(master)${Color_Off}${Gray} ❯${Color_Off}";
        echo "";
        echo -e "${BGreen}p4${Color_Off} - ${Cyan}Two-Line${Color_Off}";
        echo -e "     Información completa en dos líneas";
        echo -e "     ${Gray}Ejemplo: cesar@host /d/repos/curso_linux${Color_Off}";
        echo -e "     ${Gray}         ❯${Color_Off}";
        echo "";
        echo -e "${BGreen}p5${Color_Off} - ${Cyan}Ultra Minimal${Color_Off}";
        echo -e "     Solo símbolo en rojo brillante";
        echo -e "     ${Gray}Ejemplo: ${BRed}❯${Color_Off}";
        echo "";
        echo -e "${BYellow}Uso:${Color_Off} Escribe ${Yellow}p1${Color_Off}, ${Yellow}p2${Color_Off}, ${Yellow}p2_matrix${Color_Off}, ${Yellow}p3${Color_Off}, etc. para activar cada prompt";
        echo -e "${BYellow}Ayuda:${Color_Off} ${Yellow}p -h${Color_Off} para mostrar este menú";
        echo "";
        echo -e "${BYellow}=== GESTIÓN DE PROMPT PERSISTENTE ===${Color_Off}";
        echo -e "${BGreen}show_saved_prompt${Color_Off} - ${Cyan}Mostrar el prompt actualmente guardado${Color_Off}";
        echo -e "${BGreen}clear_saved_prompt${Color_Off} - ${Cyan}Eliminar el prompt guardado${Color_Off}";
        echo -e "${BGreen}load_saved_prompt${Color_Off} - ${Cyan}Cargar el prompt guardado manualmente${Color_Off}";
        echo "";
        echo -e "${BCyan}Nota:${Color_Off} Los prompts se guardan automáticamente al activarlos y se cargan al iniciar sesión";
        echo "";
    else
        echo -e "${BRed}Uso:${Color_Off} p -h    ${Gray}(para ver todos los prompts disponibles)${Color_Off}";
        echo -e "${BRed}     ${Color_Off} p1, p2, p2_matrix, p3, p4, p5   ${Gray}(para activar un prompt específico)${Color_Off}";
    fi
}



general_sd ()
{ 
    local dir;
    dir=$(find "${1:-.}" -type d 2> /dev/null | fzf +m) && cd "$dir"
}

general_sd2 ()
{ 
    local pattern="";
    local directory=".";
    local case_sensitive=false;
    local max_depth="";
    function show_help () 
    { 
        echo -e "${BYellow}Uso:${Color_Off} sd2 [opciones] 'patrón_de_directorio'";
        echo "";
        echo -e "${BCyan}Opciones:${Color_Off}";
        echo -e "  ${Green}-d, --dir DIRECTORIO${Color_Off}    Buscar en directorio específico (por defecto: directorio actual)";
        echo -e "  ${Green}-i, --ignore-case${Color_Off}      B煤squeda sin distinguir mayúsculas/minúsculas";
        echo -e "  ${Green}-m, --max-depth NUM${Color_Off}    Profundidad máxima de búsqueda";
        echo -e "  ${Green}-a, --all${Color_Off}              Incluir directorios ocultos (que empiecen con .)";
        echo -e "  ${Green}-h, --help${Color_Off}             Mostrar esta ayuda";
        echo "";
        echo -e "${BCyan}Ejemplos:${Color_Off}";
        echo -e "  ${Yellow}sd2 config${Color_Off}              # Buscar directorios que contengan 'config'";
        echo -e "  ${Yellow}sd2 'src*'${Color_Off}              # Buscar directorios que empiecen con 'src'";
        echo -e "  ${Yellow}sd2 node${Color_Off}                # Buscar directorios que contengan 'node'";
        echo -e "  ${Yellow}sd2 -i 'TEST'${Color_Off}           # Buscar sin importar mayúsculas";
        echo -e "  ${Yellow}sd2 -d /home backup${Color_Off}     # Buscar directorios con 'backup' en /home";
        echo -e "  ${Yellow}sd2 -a '.git'${Color_Off}           # Buscar directorios .git (incluye ocultos)";
        echo -e "  ${Yellow}sd2 -m 2 temp${Color_Off}           # Buscar solo hasta 2 niveles de profundidad";
        return 0
    };
    local include_hidden=false;
    while [[ $# -gt 0 ]]; do
        case $1 in 
            -h | --help)
                show_help;
                return 0
            ;;
            -d | --dir)
                if [[ -n "$2" && ! "$2" =~ ^- ]]; then
                    directory="$2";
                    shift 2;
                else
                    echo -e "${BRed}Error:${Color_Off} --dir requiere un directorio" 1>&2;
                    return 1;
                fi
            ;;
            -i | --ignore-case)
                case_sensitive=true;
                shift
            ;;
            -a | --all)
                include_hidden=true;
                shift
            ;;
            -m | --max-depth)
                if [[ -n "$2" && "$2" =~ ^[0-9]+$ ]]; then
                    max_depth="-maxdepth $2";
                    shift 2;
                else
                    echo -e "${BRed}Error:${Color_Off} --max-depth requiere un n煤mero" 1>&2;
                    return 1;
                fi
            ;;
            -*)
                echo -e "${BRed}Error:${Color_Off} Opción desconocida '$1'" 1>&2;
                echo -e "Usa '${Yellow}sd2 --help${Color_Off}' para ver las opciones disponibles";
                return 1
            ;;
            *)
                if [[ -z "$pattern" ]]; then
                    pattern="$1";
                    shift;
                else
                    echo -e "${BRed}Error:${Color_Off} Solo se permite un patrón de búsqueda" 1>&2;
                    return 1;
                fi
            ;;
        esac;
    done;
    if [[ -z "$pattern" ]]; then
        echo -e "${BRed}Error:${Color_Off} Debes especificar un patrón de búsqueda";
        echo -e "${BYellow}Uso:${Color_Off} sd2 'patrón_de_directorio'";
        echo -e "Usa '${Yellow}sd2 --help${Color_Off}' para más información";
        return 1;
    fi;
    if [[ ! -d "$directory" ]]; then
        echo -e "${BRed}Error:${Color_Off} El directorio '${Yellow}$directory${Color_Off}' no existe" 1>&2;
        return 1;
    fi;
    local find_cmd="find \"$directory\" $max_depth -type d";
    if ! $include_hidden; then
        find_cmd="$find_cmd ! -path '*/.*'";
    fi;
    if $case_sensitive; then
        find_cmd="$find_cmd -iname";
    else
        find_cmd="$find_cmd -name";
    fi;
    if [[ "$pattern" != *"*"* && "$pattern" != *"?"* && "$pattern" != *"["* ]]; then
        pattern="*${pattern}*";
    fi;
    echo -e "${BCyan}[>] Buscando directorios que coincidan con:${Color_Off} ${BYellow}$pattern${Color_Off}";
    echo -e "${BCyan}[DIR] En directorio:${Color_Off} ${BBlue}$(realpath "$directory")${Color_Off}";
    if ! $include_hidden; then
        echo -e "${BCyan}[INFO] Excluyendo directorios ocultos${Color_Off} ${Gray}(usa -a para incluirlos)${Color_Off}";
    fi;
    echo "";
    local results;
    results=$(eval "$find_cmd \"$pattern\" 2>/dev/null | sort");
    if [[ -z "$results" ]]; then
        echo -e "${BRed}[X] No se encontraron directorios que coincidan con el patrón '${BYellow}$pattern${Color_Off}${BRed}'${Color_Off}";
        return 1;
    else
        echo "$results" | while IFS= read -r dir; do
            local dir_name=$(basename "$dir");
            if [[ "$dir_name" =~ ^\. ]]; then
                echo -e "${Gray}[HIDDEN] $dir${Color_Off}";
            else
                if [[ "$dir_name" =~ ^(src|source|lib|library)$ ]]; then
                    echo -e "${BPurple}[SRC] $dir${Color_Off}";
                else
                    if [[ "$dir_name" =~ ^(test|tests|spec|specs)$ ]]; then
                        echo -e "${BYellow}[TEST] $dir${Color_Off}";
                    else
                        if [[ "$dir_name" =~ ^(config|conf|cfg|settings)$ ]]; then
                            echo -e "${BCyan}[CONF] $dir${Color_Off}";
                        else
                            if [[ "$dir_name" =~ ^(doc|docs|documentation)$ ]]; then
                                echo -e "${BWhite}[DOCS] $dir${Color_Off}";
                            else
                                if [[ "$dir_name" =~ ^(bin|binary|exe)$ ]]; then
                                    echo -e "${BGreen}[BIN] $dir${Color_Off}";
                                else
                                    if [[ "$dir_name" =~ ^(backup|bak|old|archive)$ ]]; then
                                        echo -e "${Purple}[BAK] $dir${Color_Off}";
                                    else
                                        if [[ "$dir_name" =~ ^(temp|tmp|cache)$ ]]; then
                                            echo -e "${Yellow}[TEMP] $dir${Color_Off}";
                                        else
                                            if [[ "$dir_name" =~ (node_modules|\.git|\.svn|build|dist|target)$ ]]; then
                                                echo -e "${Red}[SYS] $dir${Color_Off}";
                                            else
                                                echo -e "${BBlue}[DIR] $dir${Color_Off}";
                                            fi;
                                        fi;
                                    fi;
                                fi;
                            fi;
                        fi;
                    fi;
                fi;
            fi;
        done;
        local count=$(echo "$results" | wc -l);
        echo "";
        echo -e "${BGreen}[OK] Encontrados ${BWhite}$count${Color_Off}${BGreen} directorio(s)${Color_Off}";
    fi
}

general_sde ()
{ 
    export FZF_DEFAULT_OPTS="--height 40% --layout=reverse --border";
    bind '"\C-r": " \C-a\C-k\C-r\C-y\ey\C-m"';
    while true; do
        dirs=("..");
        while IFS= read -r -d '' dir; do
            dirs+=("$dir");
        done < <(find . -maxdepth 1 -type d -print0);
        dir=$(printf "%s\n" "${dirs[@]}" | fzf --header "Selecciona un directorio ('..' para retroceder)");
        if [[ -n "$dir" ]]; then
            if [[ "$dir" == ".." ]]; then
                cd ..;
            else
                cd "$dir";
            fi;
            echo -e "${Gray}Estás en: $(pwd)";
        else
            break;
        fi;
    done
}

general_search_text ()
{ 
    grep -rin "$1" . 2> /dev/null
}

general_searchtext ()
{ 
    if [ -z "$1" ]; then
        echo "Uso: searchtext 'texto_a_buscar'";
        return 1;
    fi;
    grep -r "$1" . 2> /dev/null
}

general_sf ()
{ 
    export FZF_DEFAULT_OPTS="--height 100% --layout=reverse --border";
    bind '"\C-r": " \C-a\C-k\C-r\C-y\ey\C-m"';
    if which fzf > /dev/null; then
        if command -v batcat &> /dev/null; then
            find . -type d \( -iname '$RECYCLE.BIN' -o -iname '.git' -o -iname 'node_modules' -o -iname 'dist' \) -prune -o -type f \( -not -iname '*.dll' -a -not -iname '*.exe' \) -print | fzf --preview 'batcat --style=numbers --color=always --line-range :500 {}' | xargs -r nvim;
        else
            find . -type d \( -iname '$RECYCLE.BIN' -o -iname '.git' -o -iname 'node_modules' -o -iname 'dist' \) -prune -o -type f \( -not -iname '*.dll' -a -not -iname '*.exe' \) -print | fzf --preview 'cat {}' | xargs -r nvim;
        fi;
    else
        echo "fzf no está instalado.";
    fi
}

general_sf2 ()
{ 
    local pattern="";
    local directory=".";
    local case_sensitive=false;
    local type_filter="";
    local max_depth="";
    function show_help () 
    { 
        echo -e "${BYellow}Uso:${Color_Off} sf2 [opciones] 'patrón_de_archivo'";
        echo "";
        echo -e "${BCyan}Opciones:${Color_Off}";
        echo -e "  ${Green}-d, --dir DIRECTORIO${Color_Off}    Buscar en directorio específico (por defecto: directorio actual)";
        echo -e "  ${Green}-i, --ignore-case${Color_Off}      B煤squeda sin distinguir mayúsculas/minúsculas";
        echo -e "  ${Green}-f, --files-only${Color_Off}       Buscar solo archivos regulares";
        echo -e "  ${Green}-D, --dirs-only${Color_Off}        Buscar solo directorios";
        echo -e "  ${Green}-m, --max-depth NUM${Color_Off}    Profundidad máxima de búsqueda";
        echo -e "  ${Green}-h, --help${Color_Off}             Mostrar esta ayuda";
        echo "";
        echo -e "${BCyan}Ejemplos:${Color_Off}";
        echo -e "  ${Yellow}sf2 ejemplo.sh${Color_Off}          # Buscar archivo exacto";
        echo -e "  ${Yellow}sf2 'ejemplo*'${Color_Off}          # Buscar con wildcards";
        echo -e "  ${Yellow}sf2 plo${Color_Off}                 # Buscar archivos que contengan 'plo'";
        echo -e "  ${Yellow}sf2 -i '*.PDF'${Color_Off}          # Buscar PDFs sin importar mayúsculas";
        echo -e "  ${Yellow}sf2 -f -d /home script${Color_Off}  # Buscar solo archivos que contengan 'script' en /home";
        echo -e "  ${Yellow}sf2 -D config${Color_Off}           # Buscar solo directorios que contengan 'config'";
        return 0
    };
    while [[ $# -gt 0 ]]; do
        case $1 in 
            -h | --help)
                show_help;
                return 0
            ;;
            -d | --dir)
                if [[ -n "$2" && ! "$2" =~ ^- ]]; then
                    directory="$2";
                    shift 2;
                else
                    echo -e "${BRed}Error:${Color_Off} --dir requiere un directorio" 1>&2;
                    return 1;
                fi
            ;;
            -i | --ignore-case)
                case_sensitive=true;
                shift
            ;;
            -f | --files-only)
                type_filter="-type f";
                shift
            ;;
            -D | --dirs-only)
                type_filter="-type d";
                shift
            ;;
            -m | --max-depth)
                if [[ -n "$2" && "$2" =~ ^[0-9]+$ ]]; then
                    max_depth="-maxdepth $2";
                    shift 2;
                else
                    echo -e "${BRed}Error:${Color_Off} --max-depth requiere un n煤mero" 1>&2;
                    return 1;
                fi
            ;;
            -*)
                echo -e "${BRed}Error:${Color_Off} Opción desconocida '$1'" 1>&2;
                echo -e "Usa '${Yellow}sf2 --help${Color_Off}' para ver las opciones disponibles";
                return 1
            ;;
            *)
                if [[ -z "$pattern" ]]; then
                    pattern="$1";
                    shift;
                else
                    echo -e "${BRed}Error:${Color_Off} Solo se permite un patrón de búsqueda" 1>&2;
                    return 1;
                fi
            ;;
        esac;
    done;
    if [[ -z "$pattern" ]]; then
        echo -e "${BRed}Error:${Color_Off} Debes especificar un patrón de búsqueda";
        echo -e "${BYellow}Uso:${Color_Off} sf2 'patrón_de_archivo'";
        echo -e "Usa '${Yellow}sf2 --help${Color_Off}' para más información";
        return 1;
    fi;
    if [[ ! -d "$directory" ]]; then
        echo -e "${BRed}Error:${Color_Off} El directorio '${Yellow}$directory${Color_Off}' no existe" 1>&2;
        return 1;
    fi;
    local find_cmd="find \"$directory\" $max_depth $type_filter";
    if $case_sensitive; then
        find_cmd="$find_cmd -iname";
    else
        find_cmd="$find_cmd -name";
    fi;
    if [[ "$pattern" != *"*"* && "$pattern" != *"?"* && "$pattern" != *"["* ]]; then
        pattern="*${pattern}*";
    fi;
    echo -e "${BCyan}[>] Buscando archivos que coincidan con:${Color_Off} ${BYellow}$pattern${Color_Off}";
    echo -e "${BCyan}[DIR] En directorio:${Color_Off} ${BBlue}$(realpath "$directory")${Color_Off}";
    echo "";
    local results;
    results=$(eval "$find_cmd \"$pattern\" 2>/dev/null | sort");
    if [[ -z "$results" ]]; then
        echo -e "${BRed}[X] No se encontraron archivos que coincidan con el patrón '${BYellow}$pattern${Color_Off}${BRed}'${Color_Off}";
        return 1;
    else
        echo "$results" | while IFS= read -r file; do
            if [[ -d "$file" ]]; then
                echo -e "${BBlue}[DIR] $file${Color_Off}";
            else
                if [[ -x "$file" ]]; then
                    echo -e "${BGreen}[EXE] $file${Color_Off}";
                else
                    if [[ "$file" == *.sh || "$file" == *.py || "$file" == *.pl || "$file" == *.rb ]]; then
                        echo -e "${BPurple}[SCR] $file${Color_Off}";
                    else
                        if [[ "$file" == *.txt || "$file" == *.md || "$file" == *.doc* ]]; then
                            echo -e "${BCyan}[DOC] $file${Color_Off}";
                        else
                            if [[ "$file" == *.jpg || "$file" == *.png || "$file" == *.gif || "$file" == *.jpeg ]]; then
                                echo -e "${BYellow}[IMG] $file${Color_Off}";
                            else
                                if [[ "$file" == *.zip || "$file" == *.tar || "$file" == *.gz || "$file" == *.rar ]]; then
                                    echo -e "${Purple}[ZIP] $file${Color_Off}";
                                else
                                    echo -e "${Green}[FILE] $file${Color_Off}";
                                fi;
                            fi;
                        fi;
                    fi;
                fi;
            fi;
        done;
        local count=$(echo "$results" | wc -l);
        echo "";
        echo -e "${BGreen}[OK] Encontrados ${BWhite}$count${Color_Off}${BGreen} resultado(s)${Color_Off}";
    fi
}

general_sff ()
{ 
    export FZF_DEFAULT_OPTS="--height 100% --layout=reverse --border";
    bind '"\C-r": " \C-a\C-k\C-r\C-y\ey\C-m"';
    if which fzf > /dev/null; then
        if command -v batcat &> /dev/null; then
            find . -print | fzf --preview 'batcat --style=numbers --color=always --line-range :500 {}' | xargs -r nvim;
        else
            find . -print | fzf --preview 'cat {}' | xargs -r nvim;
        fi;
    else
        echo "fzf no está instalado.";
    fi
}

general_short_pwd ()
{ 
    local pwd_length=${#PWD};
    local max_length=60;
    if [ $pwd_length -gt $max_length ]; then
        local path_parts=(${PWD//\// });
        local num_parts=${#path_parts[@]};
        if [ $num_parts -gt 3 ]; then
            echo "../${path_parts[$((num_parts-3))]}/${path_parts[$((num_parts-2))]}/${path_parts[$((num_parts-1))]}";
        else
            echo "$PWD";
        fi;
    else
        echo "$PWD";
    fi
}

general_show_date ()
{ 
    readable_date=$(LC_TIME=es_ES.UTF-8 date "+%A %d de %B de %Y, %H:%M:%S");
    utc_date=$(date -u "+%Y-%m-%d %H:%M:%S UTC");
    peru_date=$(date -u -d "-5 hours" "+%Y-%m-%d %H:%M:%S UTC-5");
    echo "Fecha actual (formato legible): $readable_date";
    echo "Fecha actual en UTC:            $utc_date";
    echo "Fecha actual en Perú (UTC-5):   $peru_date"
}

general_show_saved_prompt ()
{ 
    if [ -f "$PROMPT_CONFIG_FILE" ]; then
        local saved_prompt=$(cat "$PROMPT_CONFIG_FILE");
        if [ -n "$saved_prompt" ]; then
            echo -e "${BGreen}Prompt guardado: ${Yellow}$saved_prompt${Color_Off}";
        else
            echo -e "${BRed}No hay prompt guardado${Color_Off}";
        fi;
    else
        echo -e "${BRed}No hay prompt guardado${Color_Off}";
    fi
}

general_simple_server ()
{ 
    local port=${1:-8000};
    echo "Servidor disponible en http://localhost:$port";
    python3 -m http.server "$port"
}

general_st ()
{ 
    local pattern="";
    local directory=".";
    local case_sensitive=false;
    local file_filter="";
    local exclude_pattern="";
    local max_depth="";
    local show_line_numbers=true;
    local context_lines="";
    local word_boundary=false;
    local use_ripgrep=false;
    local force_grep=false;
    if command -v rg > /dev/null 2>&1; then
        use_ripgrep=true;
    fi;
    function show_help () 
    { 
        local tool_name;
        if $use_ripgrep; then
            tool_name="${BGreen}ripgrep (rg)${Color_Off}";
        else
            tool_name="${Yellow}grep${Color_Off}";
        fi;
        echo -e "${BYellow}Uso:${Color_Off} st [opciones] 'texto_a_buscar'";
        echo -e "${Gray}Usando: $tool_name${Color_Off}";
        echo "";
        echo -e "${BCyan}Opciones:${Color_Off}";
        echo -e "  ${Green}-d, --dir DIRECTORIO${Color_Off}    Buscar en directorio específico (por defecto: directorio actual)";
        echo -e "  ${Green}-i, --ignore-case${Color_Off}      B煤squeda sin distinguir mayúsculas/minúsculas";
        echo -e "  ${Green}-f, --files PATRÓN${Color_Off}     Buscar solo en archivos que coincidan con patrón (ej: '*.txt')";
        echo -e "  ${Green}-e, --exclude PATRÓN${Color_Off}   Excluir archivos que coincidan con patrón";
        echo -e "  ${Green}-m, --max-depth NUM${Color_Off}    Profundidad máxima de búsqueda";
        echo -e "  ${Green}-n, --no-line-numbers${Color_Off}  No mostrar números de línea";
        echo -e "  ${Green}-C, --context NUM${Color_Off}      Mostrar NUM líneas de contexto antes y despu茅s";
        echo -e "  ${Green}-w, --word${Color_Off}             Buscar palabras completas solamente";
        echo -e "  ${BYellow}-g, --force-grep${Color_Off}       ${BRed}Forzar el uso de grep${Color_Off} (incluso si ripgrep está disponible)";
        echo -e "  ${Green}-h, --help${Color_Off}             Mostrar esta ayuda";
        echo "";
        echo -e "${BCyan}Ejemplos:${Color_Off}";
        echo -e "  ${Yellow}st 'function'${Color_Off}              # Buscar texto en todos los archivos";
        echo -e "  ${Yellow}st -i 'error'${Color_Off}              # B煤squeda insensitive a mayúsculas";
        echo -e "  ${Yellow}st -f '*.js' 'console'${Color_Off}     # Buscar solo en archivos .js";
        echo -e "  ${Yellow}st -C 3 'TODO'${Color_Off}             # Mostrar 3 líneas de contexto";
        echo -e "  ${Yellow}st -w 'test'${Color_Off}               # Buscar palabra completa 'test'";
        echo -e "  ${Yellow}st -d /home 'config'${Color_Off}       # Buscar en directorio específico";
        echo -e "  ${Yellow}st -e '*.log' 'error'${Color_Off}      # Excluir archivos .log";
        echo "";
        echo -e "${BYellow}Forzar herramienta espec铆fica:${Color_Off}";
        echo -e "  ${BYellow}st -g 'function'${Color_Off}           # ${BRed}Forzar uso de grep${Color_Off} (comparar con ripgrep)";
        return 0
    };
    while [[ $# -gt 0 ]]; do
        case $1 in 
            -h | --help)
                show_help;
                return 0
            ;;
            -d | --dir)
                if [[ -n "$2" && ! "$2" =~ ^- ]]; then
                    directory="$2";
                    shift 2;
                else
                    echo -e "${BRed}Error:${Color_Off} --dir requiere un directorio" 1>&2;
                    return 1;
                fi
            ;;
            -i | --ignore-case)
                case_sensitive=true;
                shift
            ;;
            -f | --files)
                if [[ -n "$2" && ! "$2" =~ ^- ]]; then
                    file_filter="$2";
                    shift 2;
                else
                    echo -e "${BRed}Error:${Color_Off} --files requiere un patrón" 1>&2;
                    return 1;
                fi
            ;;
            -e | --exclude)
                if [[ -n "$2" && ! "$2" =~ ^- ]]; then
                    exclude_pattern="$2";
                    shift 2;
                else
                    echo -e "${BRed}Error:${Color_Off} --exclude requiere un patrón" 1>&2;
                    return 1;
                fi
            ;;
            -m | --max-depth)
                if [[ -n "$2" && "$2" =~ ^[0-9]+$ ]]; then
                    max_depth="$2";
                    shift 2;
                else
                    echo -e "${BRed}Error:${Color_Off} --max-depth requiere un n煤mero" 1>&2;
                    return 1;
                fi
            ;;
            -n | --no-line-numbers)
                show_line_numbers=false;
                shift
            ;;
            -C | --context)
                if [[ -n "$2" && "$2" =~ ^[0-9]+$ ]]; then
                    context_lines="$2";
                    shift 2;
                else
                    echo -e "${BRed}Error:${Color_Off} --context requiere un n煤mero" 1>&2;
                    return 1;
                fi
            ;;
            -w | --word)
                word_boundary=true;
                shift
            ;;
            -g | --force-grep)
                force_grep=true;
                use_ripgrep=false;
                shift
            ;;
            -*)
                echo -e "${BRed}Error:${Color_Off} Opción desconocida '$1'" 1>&2;
                echo -e "Usa '${Yellow}st --help${Color_Off}' para ver las opciones disponibles";
                return 1
            ;;
            *)
                if [[ -z "$pattern" ]]; then
                    pattern="$1";
                    shift;
                else
                    echo -e "${BRed}Error:${Color_Off} Solo se permite un patrón de búsqueda" 1>&2;
                    return 1;
                fi
            ;;
        esac;
    done;
    if [[ -z "$pattern" ]]; then
        echo -e "${BRed}Error:${Color_Off} Debes especificar un texto a buscar";
        echo -e "${BYellow}Uso:${Color_Off} st 'texto_a_buscar'";
        echo -e "Usa '${Yellow}st --help${Color_Off}' para más información";
        return 1;
    fi;
    if [[ ! -d "$directory" ]]; then
        echo -e "${BRed}Error:${Color_Off} El directorio '${Yellow}$directory${Color_Off}' no existe" 1>&2;
        return 1;
    fi;
    local tool_info;
    if $use_ripgrep; then
        tool_info="${BGreen}ripgrep${Color_Off}";
    else
        tool_info="${Yellow}grep${Color_Off}";
    fi;
    echo -e "${BCyan}[>] Buscando texto:${Color_Off} ${BYellow}'$pattern'${Color_Off} ${Gray}(usando $tool_info)${Color_Off}";
    echo -e "${BCyan}[DIR] En directorio:${Color_Off} ${BBlue}$(realpath "$directory")${Color_Off}";
    if [[ -n "$file_filter" ]]; then
        echo -e "${BCyan}[FILTER] Filtro de archivos:${Color_Off} ${Yellow}$file_filter${Color_Off}";
    fi;
    if [[ -n "$exclude_pattern" ]]; then
        echo -e "${BCyan}[EXCLUDE] Excluir:${Color_Off} ${Yellow}$exclude_pattern${Color_Off}";
    fi;
    echo "";
    if $use_ripgrep; then
        local rg_opts="--color=always --heading --with-filename";
        if $case_sensitive; then
            rg_opts="$rg_opts -i";
        fi;
        if $show_line_numbers; then
            rg_opts="$rg_opts -n";
        else
            rg_opts="$rg_opts -N";
        fi;
        if [[ -n "$context_lines" ]]; then
            rg_opts="$rg_opts -C $context_lines";
        fi;
        if $word_boundary; then
            rg_opts="$rg_opts -w";
        fi;
        if [[ -n "$max_depth" ]]; then
            rg_opts="$rg_opts --max-depth $max_depth";
        fi;
        if [[ -n "$file_filter" ]]; then
            rg_opts="$rg_opts -g '$file_filter'";
        fi;
        if [[ -n "$exclude_pattern" ]]; then
            rg_opts="$rg_opts -g '!$exclude_pattern'";
        fi;
        local results;
        results=$(eval "rg $rg_opts '$pattern' '$directory'" 2> /dev/null);
        if [[ -z "$results" ]]; then
            echo -e "${BRed}[X] No se encontraron coincidencias para '${BYellow}$pattern${Color_Off}${BRed}'${Color_Off}";
            return 1;
        else
            echo "$results";
            echo "";
            local match_count;
            local file_count;
            local stats_opts="--count-matches";
            if $case_sensitive; then
                stats_opts="$stats_opts -i";
            fi;
            if $word_boundary; then
                stats_opts="$stats_opts -w";
            fi;
            if [[ -n "$max_depth" ]]; then
                stats_opts="$stats_opts --max-depth $max_depth";
            fi;
            if [[ -n "$file_filter" ]]; then
                stats_opts="$stats_opts -g '$file_filter'";
            fi;
            if [[ -n "$exclude_pattern" ]]; then
                stats_opts="$stats_opts -g '!$exclude_pattern'";
            fi;
            local stats_result;
            stats_result=$(eval "rg $stats_opts '$pattern' '$directory'" 2> /dev/null);
            if [[ -n "$stats_result" ]]; then
                file_count=$(echo "$stats_result" | wc -l);
                match_count=$(echo "$stats_result" | awk -F: '{sum += $2} END {print sum}' 2> /dev/null || echo "0");
                echo -e "${BGreen}[OK] Encontradas ${BWhite}$match_count${Color_Off}${BGreen} coincidencias en ${BWhite}$file_count${Color_Off}${BGreen} archivos${Color_Off}";
            else
                echo -e "${BGreen}[OK] B煤squeda completada con ripgrep${Color_Off}";
            fi;
        fi;
    else
        local grep_opts="-r --color=always";
        if $case_sensitive; then
            grep_opts="$grep_opts -i";
        fi;
        if $show_line_numbers; then
            grep_opts="$grep_opts -n";
        fi;
        if [[ -n "$context_lines" ]]; then
            grep_opts="$grep_opts -C $context_lines";
        fi;
        if $word_boundary; then
            grep_opts="$grep_opts -w";
        fi;
        local find_cmd="find \"$directory\"";
        if [[ -n "$max_depth" ]]; then
            find_cmd="$find_cmd -maxdepth $max_depth";
        fi;
        find_cmd="$find_cmd -type f";
        find_cmd="$find_cmd ! -path '*/.git/*' ! -path '*/node_modules/*' ! -path '*/.svn/*'";
        if [[ -n "$file_filter" ]]; then
            find_cmd="$find_cmd -name '$file_filter'";
        fi;
        if [[ -n "$exclude_pattern" ]]; then
            find_cmd="$find_cmd ! -name '$exclude_pattern'";
        fi;
        local results="";
        local file_count=0;
        local match_count=0;
        while IFS= read -r -d '' file; do
            ((file_count++));
            local grep_result;
            grep_result=$(eval "grep $grep_opts '$pattern' \"$file\"" 2> /dev/null);
            if [[ -n "$grep_result" ]]; then
                local file_matches=$(echo "$grep_result" | wc -l);
                ((match_count += file_matches));
                echo -e "${BPurple}[FILE] $file${Color_Off} ${Gray}($file_matches coincidencias)${Color_Off}";
                echo "$grep_result" | while IFS= read -r line; do
                    echo -e "  $line";
                done;
                echo "";
            fi;
        done < <(eval "$find_cmd -print0" 2> /dev/null);
        if [[ $match_count -eq 0 ]]; then
            echo -e "${BRed}[X] No se encontraron coincidencias para '${BYellow}$pattern${Color_Off}${BRed}' en $file_count archivos${Color_Off}";
            return 1;
        else
            echo -e "${BGreen}[OK] Encontradas ${BWhite}$match_count${Color_Off}${BGreen} coincidencias en ${BWhite}$file_count${Color_Off}${BGreen} archivos revisados${Color_Off}";
        fi;
    fi
}

general_start_cyber_panel ()
{ 
    systemctl enable lscpd && systemctl start lscpd && systemctl status lscpd
}

general_stop_cyber_panel ()
{ 
    systemctl stop lscpd && systemctl disable lscpd && systemctl status lscpd
}

#echo "se cargo func_genrales.sh"