#######################################
# @description reemplaza el contenido de un fichero
# @author Cesar Auris
# @param str param_path_file
# @param str param_text_search
# @param str param_text_replace
# @return  ok
# @example:
#       param_path_file="O:/test/level1/test.txt"
#       param_text_search="perfect"
#       param_text_replace="kamu"
#       SALIDA=$(fn_replace_string_file)
# @since   2023-08-08
#######################################
fn_replace_string_file() {

  # 1. :::::::::::: valida parameters
  if [ ! -n "$param_path_file" ]; then
    echo "You supplied the first parameter! [set param_path_file]";exit
  fi
  if [ ! -n "$param_text_search" ]; then
    echo "You supplied the second parameter! [set param_text_search]";exit
  fi
  if [ ! -n "$param_text_replace" ]; then
    echo "You supplied the third parameter! [set param_text_replace]";exit
  fi
  # 2. :::::::::::: valida if exist file path
   if [ ! -f $param_path_file ]; then
     echo "No existe el fichero en: ${param_path_file}"
     exit
   fi

  # 3. :::::::::::: codigo
  FILE_PATH=`dirname $param_path_file`
  FILE_NAME=`basename $param_path_file`




  # FILE_PATH= ubicacion de donde buscara el archivo
  # -maxdepth 1  = para wu  solo lo busque  en un solo  nivel
  find "${FILE_PATH}" -maxdepth 1 -name "${FILE_NAME}"   -exec sed -i "s/${param_text_search}/${param_text_replace}/g" {} \;
  output_return="ok"
  echo $output_return # uso SALIDA=$(fn_replace_string_file)

}

function path_file_weight_humanDU() {
    local file=$1
    local weight=$(du -h "$file" | cut -f1)
    echo $weight
}

#######################################
# @description con esta funcion obtenemos el peso humano de bytes
# @author Cesar Auris
# @param $1
# @return String
# @example :
#       peso=$(convert_bytes_to_human "2016727040")
# @since   2024-13-21
#######################################
function convert_bytes_to_human() {
    bytes=$1

    # Determinar la unidad de medida
    if [ $bytes -lt 1024 ]; then
        weight_bytes="${bytes} B"
    elif [ $bytes -lt 1048576 ]; then
        weight_bytes=$(echo "${bytes}" | awk '{ printf "%.2f", $1 / 1024 }')
        weight_bytes="${weight_bytes} KB"
    elif [ $bytes -lt 1073741824 ]; then
        weight_bytes=$(echo "${bytes}" | awk '{ printf "%.2f", $1 / (1024 * 1024) }')
        weight_bytes="${weight_bytes} MB"
    elif [ $bytes -lt 1099511627776 ]; then
        weight_bytes=$(echo "${bytes}" | awk '{ printf "%.2f", $1 / (1024 * 1024 * 1024) }')
        weight_bytes="${weight_bytes} GB"
    else
        weight_bytes=$(echo "${bytes}" | awk '{ printf "%.2f", $1 / (1024 * 1024 * 1024 * 1024) }')
        weight_bytes="${weight_bytes} TB"
    fi
    # Imprimir el resultado
    echo "$weight_bytes"
}

#######################################
# @description funcion que obtene el peso exacto del fichero pasandole el path
# @author Cesar Auris
# @param String
# @return string
# @example:
#     res=$(path_file_weight_human2 "/c/Users/cesar/Downloads/flatsome.zip")
# @since   2024-16-21
#######################################
function path_file_weight_human() {
    local file=$1
    unidades=$(stat -c %s "${file}")
    local res=$(convert_bytes_to_human $unidades)
    echo "${res}"
}

#######################################
# @description devuelve el peso de un path de directorio
# @author Cesar Auris
# @param str
# @return str
# @example: path_dir="D:/repos/curso_ojs"
#           PESO_DIR=$(fn_get_dir_weight "${path_dir}")
# @since   2023-19-28
#######################################
function fn_get_dir_weight() {
  #----paranmetros
  PATH_DIR=$1

  # ------------------------------------------
  # ----1 . obtenemos el peso y lo ponemos en un fichero temporal
  # ------------------------------------------

  #du -a  "D:/repos/curso_ojs" | sort -n -r | head -n 7 | awk '{printf $2 " - " ; system("  numfmt --to=iec-i --suffix=B --format=\"%.2f\"  $((" $1 " * 1000)) " ) }' > $scriptPathFileTemp
  #du -a  "${PATH_DIR}" | sort -n -r | head -n 7 | awk '{printf $2 " - " ; system("  numfmt --to=iec-i --suffix=B --format=\"%.2f\"  $((" $1 " * 1000)) " ) }' > "${LOG_TEMP}"

  # grep -v './.git/*'  => omite el directorio git
  local tamano=$(du -a  "${PATH_DIR}" | grep -v './.git/*'  | sort -n -r | head -n 7 | awk '{printf $2 " - " ; system("  numfmt --to=iec-i --suffix=B --format=\"%.2f\"  $((" $1 " * 1000)) " ) }' | head -n 1 | awk '{print $NF}')

  # du -a  "D:/repos/curso_ojs" | sort -n -r | head -n 7 | awk '{printf $2 " - " ; system("  numfmt --to=iec-i --suffix=B --format=\"%.2f\"  $((" $1 " * 1000)) " ) }' | head -n 1

  echo -n $tamano
}

#######################################
# @description pasarle el path del fichero
# @author Cesar Auris
# @param String
# @return string
# @example:
#     res=$(delete_file "/c/Users/cesar/Downloads/flatsome.zip")
# @since   2024-16-21
#######################################
function delete_file() {
    local file=$1
    if [ ! -f "$file" ]; then
        echo "[ERROR] El archivo: ${file} No existe."
        return 1
    fi

    rm "${file}"
}
#res=$(delete_file "/c/Users/cesar/Downloads/flatsome3.zip")
#echo  "Fichero eliminado:${res}"