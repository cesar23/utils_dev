# Colores Regulares
Color_Off='\033[0m'       # Reset de color.
NC='\033[0m'
Black='\033[0;30m'        # Negro.
Red='\033[0;31m'          # Rojo.
Green='\033[0;32m'        # Verde.
Yellow='\033[0;33m'       # Amarillo.
Blue='\033[0;34m'         # Azul.
Purple='\033[0;35m'       # Púrpura.
Cyan='\033[0;36m'         # Cian.
White='\033[0;37m'        # Blanco.
Gray='\033[0;90m'         # Gris.

# Colores en Negrita
BBlack='\033[1;30m'       # Negro (negrita).
BRed='\033[1;31m'         # Rojo (negrita).
BGreen='\033[1;32m'       # Verde (negrita).
BYellow='\033[1;33m'      # Amarillo (negrita).
BBlue='\033[1;34m'        # Azul (negrita).
BPurple='\033[1;35m'      # Púrpura (negrita).
BCyan='\033[1;36m'        # Cian (negrita).
BWhite='\033[1;37m'       # Blanco (negrita).
BGray='\033[1;90m'        # Gris (negrita).

#######################################
# @description reemplaza el contenido de un fichero
# @author Cesar Auris
# @param str param_path_file
# @param str param_text_search
# @param str param_text_replace
# @return  ok
# @example:
#       param_path_file="O:/test/level1/test.txt"
#       param_text_search="perfect"
#       param_text_replace="kamu"
#       SALIDA=$(fn_replace_string_file)
# @since   2023-08-08
#######################################
fn_replace_string_file() {

  # 1. :::::::::::: valida parameters
  if [ ! -n "$param_path_file" ]; then
    echo "You supplied the first parameter! [set param_path_file]";exit
  fi
  if [ ! -n "$param_text_search" ]; then
    echo "You supplied the second parameter! [set param_text_search]";exit
  fi
  if [ ! -n "$param_text_replace" ]; then
    echo "You supplied the third parameter! [set param_text_replace]";exit
  fi
  # 2. :::::::::::: valida if exist file path
   if [ ! -f $param_path_file ]; then
     echo "No existe el fichero en: ${param_path_file}"
     exit
   fi

  # 3. :::::::::::: codigo
  FILE_PATH=`dirname $param_path_file`
  FILE_NAME=`basename $param_path_file`




  # FILE_PATH= ubicacion de donde buscara el archivo
  # -maxdepth 1  = para wu  solo lo busque  en un solo  nivel
  find "${FILE_PATH}" -maxdepth 1 -name "${FILE_NAME}"   -exec sed -i "s/${param_text_search}/${param_text_replace}/g" {} \;
  output_return="ok"
  echo $output_return # uso SALIDA=$(fn_replace_string_file)

}

function path_file_weight_humanDU() {
    local file=$1
    local weight=$(du -h "$file" | cut -f1)
    echo $weight
}

#######################################
# @description con esta funcion obtenemos el peso humano de bytes
# @author Cesar Auris
# @param $1
# @return String
# @example :
#       peso=$(convert_bytes_to_human "2016727040")
# @since   2024-13-21
#######################################
function convert_bytes_to_human() {
    bytes=$1

    # Determinar la unidad de medida
    if [ $bytes -lt 1024 ]; then
        weight_bytes="${bytes} B"
    elif [ $bytes -lt 1048576 ]; then
        weight_bytes=$(echo "${bytes}" | awk '{ printf "%.2f", $1 / 1024 }')
        weight_bytes="${weight_bytes} KB"
    elif [ $bytes -lt 1073741824 ]; then
        weight_bytes=$(echo "${bytes}" | awk '{ printf "%.2f", $1 / (1024 * 1024) }')
        weight_bytes="${weight_bytes} MB"
    elif [ $bytes -lt 1099511627776 ]; then
        weight_bytes=$(echo "${bytes}" | awk '{ printf "%.2f", $1 / (1024 * 1024 * 1024) }')
        weight_bytes="${weight_bytes} GB"
    else
        weight_bytes=$(echo "${bytes}" | awk '{ printf "%.2f", $1 / (1024 * 1024 * 1024 * 1024) }')
        weight_bytes="${weight_bytes} TB"
    fi
    # Imprimir el resultado
    echo "$weight_bytes"
}

#######################################
# @description funcion que obtene el peso exacto del fichero pasandole el path
# @author Cesar Auris
# @param String
# @return string
# @example:
#     res=$(path_file_weight_human2 "/c/Users/cesar/Downloads/flatsome.zip")
# @since   2024-16-21
#######################################
function path_file_weight_human() {
    local file=$1
    unidades=$(stat -c %s "${file}")
    local res=$(convert_bytes_to_human $unidades)
    echo "${res}"
}

#######################################
# @description devuelve el peso de un path de directorio
# @author Cesar Auris
# @param str
# @return str
# @example: path_dir="D:/repos/curso_ojs"
#           PESO_DIR=$(fn_get_dir_weight "${path_dir}")
# @since   2023-19-28
#######################################
function fn_get_dir_weight() {
  #----paranmetros
  PATH_DIR=$1

  # ------------------------------------------
  # ----1 . obtenemos el peso y lo ponemos en un fichero temporal
  # ------------------------------------------

  #du -a  "D:/repos/curso_ojs" | sort -n -r | head -n 7 | awk '{printf $2 " - " ; system("  numfmt --to=iec-i --suffix=B --format=\"%.2f\"  $((" $1 " * 1000)) " ) }' > $scriptPathFileTemp
  #du -a  "${PATH_DIR}" | sort -n -r | head -n 7 | awk '{printf $2 " - " ; system("  numfmt --to=iec-i --suffix=B --format=\"%.2f\"  $((" $1 " * 1000)) " ) }' > "${LOG_TEMP}"

  # grep -v './.git/*'  => omite el directorio git
  local tamano=$(du -a  "${PATH_DIR}" | grep -v './.git/*'  | sort -n -r | head -n 7 | awk '{printf $2 " - " ; system("  numfmt --to=iec-i --suffix=B --format=\"%.2f\"  $((" $1 " * 1000)) " ) }' | head -n 1 | awk '{print $NF}')

  # du -a  "D:/repos/curso_ojs" | sort -n -r | head -n 7 | awk '{printf $2 " - " ; system("  numfmt --to=iec-i --suffix=B --format=\"%.2f\"  $((" $1 " * 1000)) " ) }' | head -n 1

  echo -n $tamano
}

#######################################
# @description pasarle el path del fichero
# @author Cesar Auris
# @param String
# @return string
# @example:
#     res=$(delete_file "/c/Users/cesar/Downloads/flatsome.zip")
# @since   2024-16-21
#######################################
function delete_file() {
    local file=$1
    if [ ! -f "$file" ]; then
        echo "[ERROR] El archivo: ${file} No existe."
        return 1
    fi

    rm "${file}"
}
#res=$(delete_file "/c/Users/cesar/Downloads/flatsome3.zip")
#echo  "Fichero eliminado:${res}"


#######################################
# @description normaliza finales de línea (quita CRLF, asegura salto
#              de línea final) en todos los archivos de texto/código
#              de una carpeta, recursivamente. Excluye node_modules,
#              vendor, target, .venv, y demás carpetas de dependencias.
# @author Cesar Auris
# @param str param_target_path (opcional)
#        - Si se pasa: se usa esa ruta directo, SIN preguntar nada
#          (útil para llamarla desde otro script sin interacción).
#        - Si NO se pasa: pregunta por consola con un único input:
#            Enter en blanco -> usa el directorio actual (.)
#            Cualquier texto -> se usa como ruta
# @return  ok  (o mensaje de error si la ruta no existe)
# @example:
#       fn_normalize_files                          # pregunta, Enter = actual
#       fn_normalize_files "/home/cesar/proyecto"    # directo, sin preguntar
#       SALIDA=$(fn_normalize_files "/ruta")
# @since   2026-09-18
#######################################
fn_normalize_files() {
    local param_target_path="${1:-}"

    # ── Si NO vino ruta por parámetro, se pregunta UNA sola vez ────
    # Enter en blanco = directorio actual. Cualquier otro texto = esa ruta.
    if [ -z "$param_target_path" ]; then
        read -r -p "$(echo -e "${BGreen}Ruta a normalizar ${Gray}[Enter = directorio actual]${NC}: ")" param_target_path
        param_target_path="${param_target_path:-.}"
        echo
    fi

    if [ ! -d "$param_target_path" ]; then
        echo -e "${BRed}❌ Error: la ruta '${param_target_path}' no existe o no es una carpeta.${NC}" >&2
        return 1
    fi

    # Extensiones de archivo consideradas "texto". Agrega aquí
    # cualquier otra que uses.
    local file_extensions=(
        # Infra / config / docs
        "*.yml" "*.yaml" "*.sh" "*.cfg" "*.ini" "*.md" "*.j2" "*.txt"
        "*.json" "*.toml" "*.env" "*.conf" "*.properties"

        # Python
        "*.py" "*.pyi"

        # Java / Kotlin
        "*.java" "*.kt" "*.kts" "*.gradle"

        # TypeScript / JavaScript
        "*.ts" "*.tsx" "*.js" "*.jsx" "*.vue" "*.mjs" "*.cjs"

        # Web
        "*.html" "*.css" "*.scss" "*.sass"

        # C / C++ / C#
        "*.c" "*.h" "*.cpp" "*.hpp" "*.cs"

        # Otros lenguajes comunes
        "*.go" "*.rs" "*.rb" "*.sql" "*.lua" "*.pl" "*.r" "*.swift" "*.dart" "*.scala"

        # PHP / Laravel
        "*.php" "*.blade.php" "*.phtml"
    )

    # Nombres de archivo SIN extensión (find los busca por -name exacto)
    local exact_names=("Dockerfile" "Makefile" "Jenkinsfile" ".gitignore" ".env")

    # Carpetas a EXCLUIR siempre
    local exclude_paths=(
        -path "*/.git/*"
        -o -path "*/.ansible/*"
        -o -name "ansible.log"

        # JavaScript / TypeScript / Node
        -o -path "*/node_modules/*"
        -o -path "*/.next/*"
        -o -path "*/.nuxt/*"
        -o -path "*/dist/*"
        -o -path "*/build/*"

        # PHP / Laravel (Composer)
        -o -path "*/vendor/*"
        -o -path "*/storage/framework/*"
        -o -path "*/bootstrap/cache/*"

        # Java / Kotlin (Maven, Gradle)
        -o -path "*/target/*"
        -o -path "*/.gradle/*"
        -o -path "*/.m2/*"

        # Python
        -o -path "*/__pycache__/*"
        -o -path "*/.venv/*"
        -o -path "*/venv/*"
        -o -path "*/.mypy_cache/*"
        -o -path "*/*.egg-info/*"

        # C# / .NET
        -o -path "*/bin/*"
        -o -path "*/obj/*"

        # Editores / IDEs
        -o -path "*/.idea/*"
        -o -path "*/.vscode/*"
    )

    echo -e "${BBlue}🔍 Buscando archivos de texto en:${NC} $(cd "$param_target_path" && pwd)"
    echo

    # Construir la condición "-name *.yml -o -name *.sh -o ..." dinámicamente
    local name_expr=()
    for ext in "${file_extensions[@]}"; do
        name_expr+=(-o -name "$ext")
    done
    for name in "${exact_names[@]}"; do
        name_expr+=(-o -name "$name")
    done
    # Quitar el primer "-o" sobrante
    name_expr=("${name_expr[@]:1}")

    local file_count=0

    while IFS= read -r -d '' file; do
        sed -i 's/\r$//' "$file"          # 1. Quitar retornos de carro
        sed -i -e '$a\' "$file"           # 2. Asegurar salto de línea final

        file_count=$((file_count + 1))
        echo -e "  ${Green}✅${NC} $file"
    done < <(find "$param_target_path" \( "${exclude_paths[@]}" \) -prune -o -type f \( "${name_expr[@]}" \) -print0)

    echo
    echo -e "${BCyan}════════════════════════════════════════${NC}"
    echo -e "  ${BGreen}Procesados:${NC} $file_count archivos"
    echo -e "  ${BGreen}Ruta:${NC}       $(cd "$param_target_path" && pwd)"
    echo -e "${BCyan}════════════════════════════════════════${NC}"

    output_return="ok"
    echo $output_return
}
#res=$(fn_normalize_files "/home/cesar/mi-proyecto")
#echo "Resultado: ${res}"