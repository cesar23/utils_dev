import sys
import os
import io
import html
import urllib.parse
import socket
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

# --------------------------------------------------------------
# Servidor Local en Python
# --------------------------------------------------------------
# Este script implementa un servidor HTTP básico para listar
# directorios y acceder a ellos mediante un navegador web.
# --------------------------------------------------------------

# Configuración por defecto
HOST_NAME = "0.0.0.0"  # Escuchar en todas las interfaces (localhost y red local)
DEFAULT_PORT = 8080
DEFAULT_DIRECTORY = "./"

# --------------------------------------------------------------
# Validar argumentos de entrada (puerto y directorio)
# --------------------------------------------------------------

try:
    # Verifica si se proporcionó un puerto como argumento
    PORT = int(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_PORT
except ValueError:
    print(f"ERROR: El puerto proporcionado no es válido. Usando el puerto predeterminado: {DEFAULT_PORT}")
    PORT = DEFAULT_PORT

# Verifica si se proporcionó un directorio válido como argumento
DIRECTORY_PATH = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_DIRECTORY
if not os.path.isdir(DIRECTORY_PATH):
    print(f"ERROR: El directorio proporcionado no es válido. Usando el directorio predeterminado: {DEFAULT_DIRECTORY}")
    DIRECTORY_PATH = DEFAULT_DIRECTORY


# --------------------------------------------------------------
# Clase personalizada del servidor
# --------------------------------------------------------------
class PythonServer(SimpleHTTPRequestHandler):
    """
    Clase que extiende SimpleHTTPRequestHandler para personalizar
    la funcionalidad del servidor y agregar características
    como la generación de listados de directorios.
    """

    def __init__(self, *args, **kwargs):
        # Inicializa la clase con el directorio especificado
        super().__init__(*args, directory=DIRECTORY_PATH, **kwargs)

    def list_directory(self, path):
        """
        Genera un listado HTML del contenido de un directorio.

        Args:
            path (str): Ruta del directorio a listar.

        Returns:
            io.BytesIO: Archivo en memoria con el contenido HTML.
        """
        try:
            # Obtener la lista de archivos en el directorio
            file_list = os.listdir(path)
            current_path = os.path.abspath(path)
        except OSError:
            # Manejar errores de permisos
            self.send_error(HTTPStatus.NOT_FOUND, "No permission to list directory")
            return None

        # Ordenar los archivos alfabéticamente (case insensitive)
        file_list.sort(key=lambda a: a.lower())
        enc = sys.getfilesystemencoding()
        display_path = html.escape(urllib.parse.unquote(self.path), quote=False)

        # Crear la respuesta HTML
        response = [
            "<html>",
            "<head>",
            f"<title>Listado de {display_path}</title>",
            '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/milligram/1.4.1/milligram.min.css">',
            "</head>",
            "<body>",
            f"<h2>Directorio: {html.escape(current_path)}</h2>",
            "<ul>",
        ]

        for name in file_list:
            fullname = os.path.join(path, name)
            displayname = name + "/" if os.path.isdir(fullname) else name
            href = urllib.parse.quote(name)
            response.append(f'<li><a href="{href}">{html.escape(displayname)}</a></li>')

        response.extend(["</ul>", "</body>", "</html>"])
        encoded = "\n".join(response).encode(enc, "surrogateescape")

        # Configurar la respuesta HTTP
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-type", f"text/html; charset={enc}")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        return io.BytesIO(encoded)


# --------------------------------------------------------------
# Función para obtener la IP local
# --------------------------------------------------------------
def get_local_ip():
    """
    Obtiene la dirección IP local de la máquina.

    Returns:
        str: Dirección IP local o mensaje de error.
    """
    try:
        # Crear un socket para conectarse a un host externo
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))  # Conectar a un servidor externo (Google DNS)
            ip_local = s.getsockname()[0]  # Obtener la IP local asociada
        return ip_local
    except Exception as e:
        return f"Error al obtener la IP local: {e}"


# --------------------------------------------------------------
# Iniciar el servidor
# --------------------------------------------------------------
def start_server():
    """
    Inicia el servidor HTTP en el puerto y directorio especificados.
    """
    try:
        # Crear el servidor con soporte para múltiples hilos
        with ThreadingHTTPServer((HOST_NAME, PORT), PythonServer) as server:
            local_ip = get_local_ip()  # Obtener la IP local
            print(f"Servidor iniciado en:")
            print(f"  - Localhost: http://localhost:{PORT}")
            print(f"  - IP local: http://{local_ip}:{PORT}")
            print(f"Directorio raíz: {os.path.abspath(DIRECTORY_PATH)}")
            server.serve_forever()  # Ejecutar el servidor
    except KeyboardInterrupt:
        print("\nServidor detenido.")
    except Exception as e:
        print(f"ERROR: {str(e)}")


# --------------------------------------------------------------
# Punto de entrada del script
# --------------------------------------------------------------
if __name__ == "__main__":
    start_server()


# -------------------------------------------------------------
# MANUAL DE USO
# -------------------------------------------------------------
# python server.py 9090
# python server.py 8080 /home/usuario/mis_archivos
