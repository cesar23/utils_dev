# libs_shell/config_menu.sh

# ==========================================================================
# Helpers de interfaz (tema One Dark) — los usan menu_system() y TODOS los
# submenús, así que si algún día quieres cambiar el look, solo se edita
# aquí una vez y se aplica en todos lados por igual.
# ==========================================================================

# Ancho real de la terminal (con fallback si tput no está disponible).
_ui_width() {
    local w
    w=$(tput cols 2>/dev/null)
    [ -z "$w" ] && w="$COLUMNS"
    [ -z "$w" ] && w=60
    echo "$w"
}

# Barra de título a todo el ancho, estilo "status bar" de editor.
# Uso: _ui_bar "CESAR SHELL" "control panel"
_ui_bar() {
    local title="$1"
    local subtitle="$2"
    local w
    w=$(_ui_width)
    local pad
    pad=$(printf '%*s' "$w" '')
    echo -e "${On_IBlack}${pad}${Color_Off}"
    if [ -n "$subtitle" ]; then
        local rest=$((w - ${#title} - ${#subtitle} - 8))
        [ "$rest" -lt 0 ] && rest=0
        echo -e "${On_IBlack}${BIWhite}   ${title}${Color_Off}${On_IBlack}${IBlack}  ·  ${subtitle}$(printf '%*s' "$rest" '')${Color_Off}"
    else
        local rest=$((w - ${#title} - 3))
        [ "$rest" -lt 0 ] && rest=0
        echo -e "${On_IBlack}${BIWhite}   ${title}$(printf '%*s' "$rest" '')${Color_Off}"
    fi
    echo -e "${On_IBlack}${pad}${Color_Off}"
}

# Línea divisoria fina a todo el ancho.
_ui_hr() {
    local w
    w=$(_ui_width)
    printf "${IBlack}"
    printf '─%.0s' $(seq 1 "$w")
    printf "${Color_Off}\n"
}

# ==========================================================================

menu_system()
{
    clear;
    _ui_bar "CESAR SHELL" "control panel";
    echo -e "";
    echo -e "  ${IBlack}BASHRC${Color_Off}    ${IGreen}${VERSION_BASHRC}${Color_Off}";
    echo -e "  ${IBlack}PLATFORM${Color_Off}  ${IGreen}${VERSION_PLATFORM}${Color_Off}";
    echo -e "  ${IBlack}UTC${Color_Off}       ${ICyan}${DATE_HOUR}${Color_Off}";
    echo -e "  ${IBlack}UTC-5 PE${Color_Off}  ${ICyan}${DATE_HOUR_PE}${Color_Off}";
    echo -e "";
    _ui_hr;
    echo -e "";
    echo -e "  ${IYellow}01${Color_Off}  ${IBlue}Opciones Generales${Color_Off}";
    echo -e "  ${IYellow}02${Color_Off}  ${IBlue}Comandos Ficheros${Color_Off}";
    echo -e "  ${IYellow}03${Color_Off}  ${IBlue}Navegación${Color_Off}";
    echo -e "  ${IYellow}04${Color_Off}  ${IBlue}Docker${Color_Off}";
    echo -e "  ${IYellow}05${Color_Off}  ${IBlue}Docker Comandos${Color_Off}";
    echo -e "  ${IYellow}06${Color_Off}  ${IBlue}CyberPanel${Color_Off}";
    echo -e "  ${IYellow}07${Color_Off}  ${IBlue}FZF${Color_Off}";
    echo -e "  ${IYellow}08${Color_Off}  ${IBlue}Script Python${Color_Off}";
    echo -e "  ${IYellow}09${Color_Off}  ${IBlue}Ficheros de configuración${Color_Off}";
    echo -e "  ${IYellow}10${Color_Off}  ${IBlue}Prompts${Color_Off}";
    echo -e "  ${IYellow}11${Color_Off}  ${IBlue}servers SSH ~/.ssh/config${Color_Off}";
    echo -e "  ${IRed}x${Color_Off}   ${IRed}Salir${Color_Off}";
    echo -e "";
    _ui_hr;
    # NOTA: se muestran con cero a la izquierda (01, 02...) solo para que
    # la lista se vea prolija y alineada; para elegir escribes el número
    # normal, SIN el cero (1, 2, 3... 11), porque así están definidos los
    # patrones de abajo en el "case". Escribir "01" no coincidiría con nada.
    echo -en "${On_IGreen}${BIBlack} ❯ ${Color_Off} ${IWhite}";
    read -p "" opt;
    echo -en "${Color_Off}";
    case $opt in
        1)
            submenu_generales
        ;;
        2)
            # la función está en este mismo archivo (submenu_files),
            # que a su vez lista comandos de: conf_funciones_files.sh
            submenu_files
        ;;
        3)
            # la función está en este mismo archivo (menu_search),
            # que carga: func_navegacion.sh
            menu_search
        ;;
        4)
            submenu_docker
        ;;
        5)
            submenu_docker_comandos
        ;;
        6)
            submenu_cyberpanel
        ;;
        7)
            submenu_fzf
        ;;
        8)
            submenu_python_utils
        ;;
        9)
            submenu_ficheros_configuracion
        ;;
        10)
            p -h
        ;;
        11)
            main_config_ssh
        ;;
        x | X)
            return
        ;;
        "")
            return
        ;;
        *)
            echo -e "${IRed}[!] Opción inválida${Color_Off}";
            menu
        ;;
    esac
}


submenu_generales ()
{
    cls;
    _ui_bar "Opciones Generales";
    echo -e "";
    echo -e "${IBlue}   - cf : ${ICyan}Crear un fichero de manera manual${Color_Off}";
    echo -e "${IBlue}   - sf2 : ${ICyan} realiza busquedas de archivos (sf2 -h  para ayuda y ejemplos)${Color_Off}";
    echo -e "${IBlue}   - sd2 : ${ICyan} realiza busquedas de directorios (sd2 -h  para ayuda y ejemplos)${Color_Off}";
    echo -e "${IBlue}   - st : ${ICyan} realiza busqueda de texto en directorio actual (st -h  para ayuda y ejemplos)${Color_Off}";
    echo -e "${IBlue}   - listar_archivos_recientes_modificados : ${ICyan} ficheros recientes y modificados  Ejemplo: listar_archivos_recientes_modificados '/var/www/html' 15${Color_Off}";
    echo -e "${IBlue}   - generar_ssh : ${ICyan}Generar claves SSH. Ejemplo: generar_ssh usuario@dominio.com${Color_Off}";
    echo -e "${IBlue}   - comparar : ${ICyan}Comparar dos archivos. Ejemplo: comparar archivo1.txt archivo2.txt${Color_Off}";
    echo -e "${IBlue}   - search_text : ${ICyan}Buscar texto en múltiples archivos del directorio actual. Ejemplo: search_text 'texto_a_buscar'${Color_Off}";
    echo -e "${IBlue}   - directory_space : ${ICyan}Ver peso de sus directorios pasar el path opcional . Ejemplo: directory_space '/var/www'${Color_Off}";
    echo -e "${IBlue}   - find_files_by_size : ${ICyan}Archivos por tamaño. Ejemplo: find_files_by_size . 5M${Color_Off}";
    echo -e "${IBlue}   - find_heaviest_files : ${ICyan}Listar los archivos más pesados en un directorio. Ejemplo: find_heaviest_files /ruta/al/directorio 10${Color_Off}";
    echo -e "${IBlue}   - simple_server : ${ICyan}Iniciar un servidor HTTP simple en el puerto especificado (por defecto 8000). Ejemplo: simple_server 8080${Color_Off}";
    echo -e "";
    _ui_hr;
    echo -e "${IPurple}Utilidades Red:${Color_Off}";
    echo -e "${IBlue}   - Obtener Ip Publica : ${ICyan}curl checkip.amazonaws.com${Color_Off}";
    echo -e "${IPurple}Alias básicos disponibles:${Color_Off}";
    echo -e "${IBlue}   - ll : ${ICyan}Lista archivos con tamaños legibles (ls -lh).${Color_Off}";
    echo -e "${IBlue}   - la : ${ICyan}Lista todos los archivos, incluidos ocultos (ls -lha).${Color_Off}";
    echo -e "${IBlue}   - rm : ${ICyan}Borrar archivos con confirmación.${Color_Off}";
    echo -e "${IBlue}   - cp : ${ICyan}Copiar archivos con confirmación.${Color_Off}";
    echo -e "${IBlue}   - mm : ${ICyan}Efecto Hacker${Color_Off}";
    echo -e "${IBlue}   - mv : ${ICyan}Mover archivos con confirmación.${Color_Off}";
    echo -e "${IBlue}   - cls : ${ICyan}Limpiar la pantalla.${Color_Off}";
    echo -e "${IPurple}Alias avanzados disponibles:${Color_Off}";
    echo -e "${IBlue}   - search : ${ICyan}Buscar archivos por nombre. Ejemplo: search '*.log'${Color_Off}";
    echo -e "${IBlue}   - bigfiles : ${ICyan}Mostrar los 10 archivos más grandes en el directorio actual.${Color_Off}";
    echo -e "${IBlue}   - newestfile : ${ICyan}Mostrar el archivo más reciente del directorio actual.${Color_Off}";
    echo -e "${IPurple}Configuraciones adicionales:${Color_Off}";
    echo -e "${IBlue}   - ulimit -n 4096 : ${ICyan}Incrementa el límite de archivos abiertos.${Color_Off}";
    echo -e "${IBlue}   - history : ${ICyan}Historial extendido con fecha y hora.${Color_Off}";
    echo -e "${IBlue}   - PATH : ${ICyan}Incluye scripts personalizados en /opt/mis-scripts.${Color_Off}";
    echo -e "";
}


submenu_files ()
{
    cls;
    _ui_bar "Comandos Ficheros";
    echo -e "";
    echo -e "${IBlue}  - fn_normalize_files : ${ICyan}Quita saltos de línea y agrega una línea al final del fichero${Color_Off}";
    echo -e "${IBlue}  - fn_replace_string_file : ${ICyan} reemplaza el contenido de un fichero${Color_Off}";
    echo -e "";
}


menu_search(){
  source "${CURRENT_DIR}/${CURRENT_TERMINAL}/func_navegacion.sh"
  navegacion_menu_search
}

submenu_cyberpanel ()
{
    # ubicados en func_generales.sh
    cls;
    _ui_bar "CyberPanel";
    echo -e "";
    echo -e "${IBlue}   - stop_cyber_panel : ${ICyan}Detener CyberPanel.${Color_Off}";
    echo -e "${IBlue}   - start_cyber_panel : ${ICyan}Iniciar CyberPanel.${Color_Off}";
    echo -e "";
}

submenu_docker ()
{
    # ubicados en func_generales.sh
    cls;
    _ui_bar "Docker";
    echo -e "";
    echo -e "${IBlue}   - d : ${ICyan}docker${Color_Off}";
    echo -e "${IBlue}   - dps : ${ICyan}docker ps${Color_Off}";
    echo -e "${IBlue}   - di : ${ICyan}docker images${Color_Off}";
    echo -e "${IBlue}   - drm : ${ICyan}docker rm -f${Color_Off}";
    echo -e "${IBlue}   - drmi : ${ICyan}docker rmi${Color_Off}";
    echo -e "${IBlue}   - dlog : ${ICyan}docker logs -f${Color_Off}";
    echo -e "";
    echo -e "${IBlue}   - dc : ${ICyan}docker-compose ${Color_Off}";
    echo -e "${IBlue}   - dcu : ${ICyan}docker-compose up -d ${Color_Off}";
    echo -e "${IBlue}   - dcd : ${ICyan}docker-compose down ${Color_Off}";
    echo -e "${IBlue}   - dcb : ${ICyan}docker-compose build ${Color_Off}";
    echo -e "${IBlue}   - dcr : ${ICyan}docker-compose restart ${Color_Off}";
    echo -e "";
    echo -e "${IBlue}   - dinspect : ${ICyan}Inspecionar contenedor - Uso: dinspect <nombre_contenedor> ${Color_Off}";
    echo -e "${IBlue}   - dlogin : ${ICyan}Listar e Ingresar a contenedor - Uso: dit ${Color_Off}";
    echo -e "${IBlue}   - droot : ${ICyan}Listar e Ingresar a contenedor MODO : ROOT- Uso: dit ${Color_Off}";
    echo -e "${IBlue}   - dcrestart : ${ICyan}docker-compose down && docker-compose up -d ${Color_Off}";
    echo -e "";
}

submenu_docker_comandos ()
{
    cls;
    curl -sSL https://raw.githubusercontent.com/cesar23/utils_dev/master/binarios/linux/util/docker_info.sh | bash
}

submenu_ficheros_configuracion ()
{
    cls;
    _ui_bar "Ficheros de configuración";
    echo -e "";
    echo -e "${Code_background} ~/.bashrc ${Color_Off}${ICyan} → Configuración del shell interactivo (para Bash).${Color_Off}";
    echo -e "${Code_background} /etc/network/interfaces ${ICyan} → Configuración de la red (Debian/Ubuntu).${Color_Off}";
    echo -e "${Code_background} /etc/sysconfig/network-scripts/ifcfg-eth0 ${ICyan} → Configuración de la red (RHEL/CentOS)..${Color_Off}";
    echo -e "${Code_background} /etc/resolv.conf ${ICyan} → Configuración de servidores DNS..${Color_Off}";
    echo -e "${Code_background} /etc/hosts.allow y /etc/hosts.deny ${ICyan} → Control de acceso a servicios..${Color_Off}";
    echo -e "${Code_background} /etc/nsswitch.conf ${ICyan} → Orden de búsqueda de nombres de host..${Color_Off}";
    echo -e "${Code_background} /etc/hostname ${ICyan} → Nombre del host del sistema..${Color_Off}";
    echo -e "${Code_background} /etc/iptables/rules.v4 y /etc/iptables/rules.v6 ${ICyan} → Configuración de reglas de firewall (si usa iptables)..${Color_Off}";
    echo -e "";
}

submenu_fzf ()
{
    # ubicados en func_generales.sh
    cls;
    _ui_bar "FZF";
    echo -e "";
    echo -e "${IBlue}   - sd : ${ICyan}Buscar y cambiar de directorio.${Color_Off}";
    echo -e "${IBlue}   - sde : ${ICyan}Navegación estilo explorador de Windows.${Color_Off}";
    echo -e "${IBlue}   - sf : ${ICyan}Buscar archivos excluyendo carpetas y tipos de archivos.${Color_Off}";
    echo -e "${IBlue}   - sff : ${ICyan}Buscar archivos sin exclusiones.${Color_Off}";
    echo -e "";
}


submenu_python_utils ()
{
    cls;
    _ui_bar "Script Python";
    echo -e "";
    echo -e "${IBlue} - run_server_py : ${ICyan}Crea un servidor de explorador de ficheros.${Color_Off}";
    echo -e "${IYellow}   Ejemplos de uso:${Color_Off}";
    echo -e "${IPurple}      run_server_py  :${ICyan}directorio actual.${Color_Off}";
    echo -e "${IPurple}      run_server_py 9090 : ${ICyan}directorio actual y con puerto 9090.${Color_Off}";
    echo -e "${IPurple}      run_server_py 9090 /d/repos : ${ICyan}puerto y directorio pasado por parametro.${Color_Off}";
    echo -e "${IBlue} - optimize_img_dir : ${IYellow}(solo Linux)${Color_Off} ${ICyan}Comprime Recursivamente imagenes tipo (jpg,png) en el directorio actual o pasandole un path ejemplo: optimize_img_dir '/mnt/e/imgs'  ${Color_Off}";
    echo -e "";
}


main_config_ssh(){
  source "${CURRENT_DIR}/${CURRENT_TERMINAL}/func_server_ssh.sh"
  ssh_func_main_config_ssh
}


sysinfo ()
{
    echo "=== INFORMACIÓN DEL SISTEMA ===";
    echo "Hostname: $(hostname)";
    echo "Usuario: $USER";
    echo "Sistema: $(lsb_release -d 2> /dev/null | cut -f2 || uname -s)";
    echo "Uptime: $(uptime -p 2> /dev/null || uptime)";
    echo "Memoria: $(free -h | grep '^Mem:' | awk '{print $3"/"$2}')";
    echo "Disco: $(df -h / | tail -1 | awk '{print $3"/"$2" ("$5")"}')";
    echo "IP: $(hostname -I | awk '{print $1}' 2> /dev/null || echo 'N/A')"
}