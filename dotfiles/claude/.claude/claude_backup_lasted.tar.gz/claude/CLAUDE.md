# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Repository Overview

This is a Claude Code configuration directory containing specialized agents, custom commands, and development tools. The repository serves as a personal assistant framework for software development tasks in Spanish.

## Architecture

### Core Components

- **`/agents/`** - Specialized AI agents for different development tasks
  - `core/` - General purpose agents (general-purpose, code-reviewer, debugger, refactor-expert, test-writer, architecture-advisor, performance-optimizer, database-expert)
  - `development/` - Domain-specific development agents (frontend-expert, backend-expert, doc-writer, mobile-expert, api-expert)
  - `devops/` - Infrastructure and system administration agents (linux-shell-expert, devops-expert)
  - `security/` - Security-focused agents (security-expert)
  - `specialized/` - Specialized domain agents (data-analyst, game-dev-expert, blockchain-expert)

- **`/commands/`** - Custom slash commands for common development tasks
  - `review.md` - Code review command
  - `fix.md` - Error fixing command
  - `explain.md` - Code explanation command
  - `debug.md` - Debug assistance command
  - `optimize.md` - Performance optimization command
  - `test.md` - Automated test generation command
  - `deploy.md` - Deployment assistance command
  - `refactor.md` - Code refactoring command
  - `migrate.md` - Migration assistance command
  - `benchmark.md` - Performance benchmarking command
  - `scaffold.md` - Project scaffolding command

- **`/ide/`** - IDE-specific configurations and extensions
- **`/plugins/`** - Plugin configurations and custom tools
- **`/projects/`** - Project-specific configurations
- **`/todos/`** - Task management and tracking

### Agent System

Each agent follows a consistent markdown format with:
- **Front matter**: name, description, tools, personality, model
- **Specialization section**: Defines expertise areas
- **Methodology**: Step-by-step approach to tasks
- **Tools and examples**: Practical usage patterns
- **Integration guidelines**: When to use each agent

### Command System

Custom commands are defined in markdown with:
- **Front matter**: description, argument hints, model specification
- **Process description**: Step-by-step workflow
- **Usage examples**: Practical implementation patterns

## Development Workflow

### Agent Selection
- Use `general-purpose` for basic development tasks and code exploration
- Use `code-reviewer` for thorough code quality analysis
- Use `performance-optimizer` for bottleneck identification and optimization
- Use `database-expert` for database design, queries, and optimization
- Use specialized agents (frontend-expert, backend-expert, mobile-expert, api-expert) for domain-specific tasks
- Use `devops-expert` for CI/CD, containerization, and infrastructure
- Use `security-expert` for security audits and vulnerability assessment
- Use `data-analyst` for data analysis, ML basics, and visualizations
- Use `game-dev-expert` for game development and engine programming
- Use `blockchain-expert` for Web3, smart contracts, and DeFi development

### Configuration Management
- All settings stored in `settings.json`
- Agent configurations in individual markdown files
- Commands defined with argument hints and process descriptions
- Language preference: Spanish for user-facing content

### Common Tasks

No specific build, test, or development commands are defined as this is a configuration repository rather than a traditional codebase.

## Key Features

### Multi-Language Agent Support
The agent system supports development in multiple programming languages and frameworks:
- **Web Development**: JavaScript/TypeScript (React, Vue, Angular, Node.js), HTML/CSS
- **Backend Development**: Python (Django, Flask, FastAPI), Node.js (Express, NestJS), Go, Java, C#
- **Mobile Development**: React Native, Flutter, Swift (iOS), Kotlin/Java (Android)
- **Database Systems**: PostgreSQL, MySQL, MongoDB, Redis, SQL optimization
- **DevOps & Infrastructure**: Docker, Kubernetes, CI/CD, AWS/Azure/GCP, Terraform
- **Specialized Domains**: Data analysis (Python/R), Game development (Unity/Unreal), Blockchain (Solidity)
- **Security**: Vulnerability assessment, secure coding practices, penetration testing concepts

### Specialized Workflows
- **Code Review**: Systematic analysis including security, performance, and maintainability
- **Debug Assistance**: Structured problem-solving approach
- **Performance Optimization**: Bottleneck identification and optimization strategies
- **Architecture Consulting**: High-level design decisions and patterns
- **Documentation**: Technical writing and explanation generation
- **Testing**: Automated test generation for unit, integration, and E2E testing
- **Deployment**: CI/CD setup, containerization, and production deployment
- **Refactoring**: Code improvement while maintaining functionality
- **Migration**: Technology and data migration assistance
- **Scaffolding**: Project structure generation with best practices

### Quality Standards
- Emphasis on clean, readable code
- Security-first approach
- Performance optimization awareness
- Comprehensive testing and validation
- Consistent code style and conventions