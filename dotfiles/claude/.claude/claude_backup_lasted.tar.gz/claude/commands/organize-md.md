---
description: Organiza un archivo Markdown añadiendo índice navegable y botones de regreso
argument-hint: [archivo-markdown]
model: claude-sonnet-4-20250514
---

# 📋 Organizador de Markdown

Voy a organizar y añadir navegación a: $ARGUMENTS

## 🎯 Mi proceso de organización:

### 1. **📖 Análisis del Documento**
- Leer el archivo Markdown completo
- Identificar todos los títulos y subtítulos (H1, H2, H3, etc.)
- Detectar la estructura jerárquica existente
- Preservar todo el contenido original
- Mapear la organización actual

### 2. **📑 Generación del Índice**
- Crear índice automático basado en títulos
- Generar enlaces navegables a cada sección
- Mantener jerarquía visual (H1 > H2 > H3)
- Incluir emojis existentes en los enlaces
- Organizar por niveles de importancia

### 3. **🔗 Añadir Navegación**
- Insertar botones "🔝 Volver al índice" después de cada sección
- Crear enlaces internos funcionales
- Mantener formato y estilo original
- Preservar código, tablas, listas y bloques

### 4. **✨ Mejoras de Estructura**
- Añadir separadores visuales entre secciones
- Mejorar espaciado y legibilidad
- Mantener orden lógico del contenido
- Conservar todos los bloques de código intactos

## 🛠️ Transformaciones que realizo:

### **A) Creación de Índice**
```markdown
# Indice

## 🔍 [Sección Principal](#🔍-sección-principal)
- [Subsección 1](#subsección-1)
- [Subsección 2](#subsección-2)

## 🚀 [Otra Sección](#🚀-otra-sección)
- [Parte A](#parte-a)
- [Parte B](#parte-b)

---
```

### **B) Añadir Botones de Regreso**
```markdown
## 🔍 Sección Principal

Contenido original se mantiene intacto...

```python
# Todo el código se preserva exactamente
def mi_funcion():
    return "sin cambios"
```

Más contenido original...

[🔝 Volver al índice](#Indice)

---
```

### **C) Enlaces Automáticos**
- **H1 (Títulos principales):** `# Mi Título` → `[Mi Título](#mi-título)`
- **H2 (Secciones):** `## Mi Sección` → `[Mi Sección](#mi-sección)`
- **H3 (Subsecciones):** `### Mi Subsección` → `[Mi Subsección](#mi-subsección)`
- **Con emojis:** `## 🔧 Tools` → `[🔧 Tools](#🔧-tools)`

## 📊 Características del índice generado:

### **Estructura Jerárquica**
```markdown
## 📑 ÍNDICE

### 🔵 [NIVEL 1 - Secciones Principales](#nivel-1)
- [📘 Subsección importante](#📘-subsección-importante)
- [📗 Otra subsección](#📗-otra-subsección)
  - [Nivel 3 detallado](#nivel-3-detallado)
  - [Más detalles](#más-detalles)

### 🟢 [NIVEL 2 - Documentación](#nivel-2)
- [Guías](#guías)
- [Ejemplos](#ejemplos)
- [Referencia](#referencia)
```

### **Preservación Total**
- ✅ **Código:** Todos los bloques de código intactos
- ✅ **Tablas:** Formato y contenido preservado
- ✅ **Listas:** Numeradas y con viñetas mantenidas
- ✅ **Enlaces:** Enlaces externos conservados
- ✅ **Imágenes:** Referencias y alt text preservados
- ✅ **Formato:** Negrita, cursiva, código inline
- ✅ **Bloques especiales:** Quotes, alerts, etc.

## 🎨 Personalización automática:

### **Detección de Tipos de Documento**
- **README:** Estructura para proyectos
- **Documentación:** Organización técnica
- **Guías:** Flujo paso a paso
- **APIs:** Endpoints y referencias
- **Tutoriales:** Progresión educativa

### **Estilos de Índice**
```markdown
# Para READMEs
## 📑 Tabla de Contenidos
- [🚀 Inicio Rápido](#🚀-inicio-rápido)
- [📦 Instalación](#📦-instalación)
- [🔧 Configuración](#🔧-configuración)

# Para Documentación Técnica
## 📖 Índice de Documentación
### 📋 [Fundamentos](#📋-fundamentos)
### ⚙️ [Configuración Avanzada](#⚙️-configuración-avanzada)
### 🔍 [Troubleshooting](#🔍-troubleshooting)

# Para APIs
## 🔗 Referencia de API
- [🔐 Autenticación](#🔐-autenticación)
- [📡 Endpoints](#📡-endpoints)
- [📊 Respuestas](#📊-respuestas)
```

## 📋 Casos de uso típicos:

### **1. README de proyecto**
- Añadir navegación a documentación existente
- Mantener todos los badges y enlaces
- Preservar ejemplos de código
- Organizar instalación, uso, contribución

### **2. Documentación técnica**
- Crear índice de múltiples secciones
- Navegación entre conceptos
- Preservar diagramas y ejemplos
- Mantener referencias cruzadas

### **3. Guías y tutoriales**
- Índice de pasos o capítulos
- Navegación secuencial
- Preservar ejercicios y código
- Mantener flujo didáctico

### **4. Notas y apuntes**
- Organizar contenido existente
- Añadir navegación rápida
- Preservar formato personal
- Mantener enlaces y referencias

## ⚡ Ejemplos de transformación:

### **Antes (archivo desorganizado):**
```markdown
# Mi Proyecto

Descripción del proyecto...

## Instalación

Pasos de instalación...

## Uso

Ejemplos de uso...

## API Reference

Documentación de API...
```

### **Después (con navegación):**
```markdown
# Mi Proyecto

## 📑 ÍNDICE
- [🚀 Descripción](#🚀-descripción)
- [📦 Instalación](#📦-instalación)
- [💻 Uso](#💻-uso)
- [🔗 API Reference](#🔗-api-reference)

---

## 🚀 Descripción

Descripción del proyecto...

[🔝 Volver al índice](#📑-índice)

---

## 📦 Instalación

Pasos de instalación...

[🔝 Volver al índice](#📑-índice)

---
```

## 🎯 Configuraciones especiales:

### **Manejo de Código**
- Preservar sintaxis highlighting: ```python, ```javascript
- Mantener indentación exacta
- Conservar comentarios inline
- Preservar bloques de configuración

### **Tablas y Listas**
- Mantener alineación de columnas
- Preservar formato de markdown tables
- Conservar listas anidadas
- Mantener checkboxes [ ] [x]

### **Enlaces y Multimedia**
- Conservar enlaces externos intactos
- Preservar imágenes y alt text
- Mantener referencias y footnotes
- Conservar embeds y iframes

## ✅ Resultado esperado:
- Archivo Markdown completamente navegable
- Índice funcional al inicio del documento
- Botones de regreso en cada sección
- Todo el contenido original preservado
- Navegación fluida entre secciones
- Estructura profesional y organizada
- Enlaces internos funcionando perfectamente
- Formato mejorado sin pérdida de información

## 💡 Ventajas:
- **Navegación instantánea:** Acceso rápido a cualquier sección
- **Profesional:** Documentos con aspecto pulido
- **Conserva trabajo:** Cero pérdida de contenido existente
- **Reutilizable:** Funciona con cualquier Markdown
- **Responsive:** Navegación funciona en GitHub, editores, web

¡Transforma cualquier Markdown en documentación navegable! 📋✨