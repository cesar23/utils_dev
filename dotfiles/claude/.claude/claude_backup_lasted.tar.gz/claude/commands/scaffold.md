---
description: Genera estructura base de proyectos y componentes
argument-hint: [tipo de proyecto o framework]
model: claude-sonnet-4-20250514
---

# 🏗️ Project Scaffolder

Voy a generar la estructura para: $ARGUMENTS

## 🎯 Tipos de scaffold que genero:

### 🌐 **Frontend Projects**
- React + TypeScript + Vite
- Vue 3 + Composition API
- Angular + TypeScript
- Svelte/SvelteKit
- Next.js full-stack

### ⚙️ **Backend APIs**
- Node.js + Express + TypeScript
- Python + FastAPI/Django
- Go + Gin/Echo
- Rust + Actix/Warp
- Java + Spring Boot

### 📱 **Mobile Apps**
- React Native + TypeScript
- Flutter + Dart
- Expo managed workflow
- Ionic + Angular/React

### 🗄️ **Full-Stack**
- MEAN/MERN stack
- LAMP/LEMP stack
- JAMstack + Serverless
- Microservices architecture

## 🏗️ Mi proceso de scaffolding:

### 1. **📋 Análisis de Requisitos**
- Identificar tipo de proyecto
- Tecnologías requeridas
- Patrones de arquitectura
- Configuraciones necesarias

### 2. **🎨 Generación de Estructura**
- Directorios organizados
- Archivos de configuración
- Dependencies setup
- Build/dev scripts

### 3. **⚙️ Configuración Base**
- Linting y formatting
- Testing framework
- CI/CD básico
- Environment setup

### 4. **📚 Documentación**
- README detallado
- Setup instructions
- Development guidelines
- Architecture notes

## 📁 Estructuras típicas:

### React + TypeScript
```
my-react-app/
├── public/
├── src/
│   ├── components/
│   ├── hooks/
│   ├── services/
│   ├── types/
│   ├── utils/
│   └── App.tsx
├── tests/
├── .env.example
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

### Node.js API
```
my-api/
├── src/
│   ├── controllers/
│   ├── middleware/
│   ├── models/
│   ├── routes/
│   ├── services/
│   ├── types/
│   └── app.ts
├── tests/
├── .env.example
├── package.json
├── tsconfig.json
├── Dockerfile
└── docker-compose.yml
```

### Flutter App
```
my_flutter_app/
├── lib/
│   ├── models/
│   ├── screens/
│   ├── services/
│   ├── utils/
│   ├── widgets/
│   └── main.dart
├── test/
├── assets/
├── pubspec.yaml
└── README.md
```

## 🛠️ Configuraciones incluidas:

### Package.json Scripts
```json
{
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "test": "jest",
    "test:watch": "jest --watch",
    "lint": "eslint src --ext .ts,.tsx",
    "lint:fix": "eslint src --ext .ts,.tsx --fix",
    "type-check": "tsc --noEmit"
  }
}
```

### ESLint + Prettier
```json
{
  "extends": [
    "@typescript-eslint/recommended",
    "prettier"
  ],
  "rules": {
    "no-console": "warn",
    "@typescript-eslint/no-unused-vars": "error"
  }
}
```

### Docker Setup
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

## 🎯 Features incluidas:

### ✅ **Development Tools**
- Hot reload setup
- Debugging configuration
- Environment variables
- Path aliases

### ✅ **Code Quality**
- ESLint configuration
- Prettier formatting
- Husky git hooks
- Pre-commit checks

### ✅ **Testing Setup**
- Jest configuration
- Testing utilities
- Coverage reports
- E2E testing setup

### ✅ **Build Optimization**
- Production builds
- Asset optimization
- Bundle analysis
- Performance budgets

### ✅ **Documentation**
- README template
- API documentation
- Component stories
- Development guides

## 🚀 Resultado esperado:
- Proyecto completo listo para desarrollo
- Todas las herramientas configuradas
- Best practices implementadas
- Documentación completa
- Scripts de development/build funcionales