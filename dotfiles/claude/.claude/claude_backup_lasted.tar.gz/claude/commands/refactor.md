---
description: Refactoriza código para mejorar estructura y mantenibilidad
argument-hint: [archivo o función a refactorizar]
model: claude-sonnet-4-20250514
---

# 🔄 Refactoring Expert

Voy a refactorizar: $ARGUMENTS

## 🎯 Mi proceso de refactoring:

### 1. **🔍 Análisis del Código Actual**
- Entender la funcionalidad existente
- Identificar code smells y anti-patterns
- Evaluar complejidad y acoplamiento
- Detectar duplicación de código

### 2. **🎨 Planificación de Mejoras**
- Definir objetivos del refactoring
- Priorizar cambios por impacto/esfuerzo
- Mantener funcionalidad intacta
- Planificar refactoring incremental

### 3. **⚙️ Aplicación de Técnicas**
- Extract Method/Function
- Extract Class/Module
- Rename variables/functions
- Simplify conditionals
- Remove dead code

### 4. **✅ Validación**
- Ejecutar tests existentes
- Verificar que funcionalidad se mantiene
- Review de código mejorado
- Performance validation

## 🛠️ Técnicas de Refactoring:

### 🎨 **Extract Method**
```javascript
// ❌ Antes: Método muy largo
function processOrder(order) {
  // Validación
  if (!order.items || order.items.length === 0) {
    throw new Error('Order must have items');
  }
  
  // Cálculo de total
  let total = 0;
  for (const item of order.items) {
    total += item.price * item.quantity;
  }
  
  // Aplicar descuentos
  if (order.coupon) {
    total = total * (1 - order.coupon.discount);
  }
  
  // Guardar en DB
  database.save(order);
  
  return total;
}

// ✅ Después: Métodos extraídos
function processOrder(order) {
  validateOrder(order);
  const total = calculateTotal(order);
  const finalTotal = applyDiscounts(total, order.coupon);
  saveOrder(order);
  return finalTotal;
}

function validateOrder(order) {
  if (!order.items || order.items.length === 0) {
    throw new Error('Order must have items');
  }
}

function calculateTotal(order) {
  return order.items.reduce((sum, item) => 
    sum + (item.price * item.quantity), 0
  );
}

function applyDiscounts(total, coupon) {
  return coupon ? total * (1 - coupon.discount) : total;
}
```

### 🏗️ **Extract Class**
```javascript
// ❌ Antes: Clase con demasiadas responsabilidades
class User {
  constructor(name, email) {
    this.name = name;
    this.email = email;
  }
  
  validateEmail() { /* validation logic */ }
  sendWelcomeEmail() { /* email logic */ }
  hashPassword(password) { /* crypto logic */ }
  saveToDatabase() { /* persistence logic */ }
}

// ✅ Después: Responsabilidades separadas
class User {
  constructor(name, email) {
    this.name = name;
    this.email = email;
  }
}

class EmailValidator {
  static validate(email) { /* validation logic */ }
}

class EmailService {
  static sendWelcome(user) { /* email logic */ }
}

class PasswordHasher {
  static hash(password) { /* crypto logic */ }
}

class UserRepository {
  static save(user) { /* persistence logic */ }
}
```

### 🔄 **Simplify Conditionals**
```javascript
// ❌ Antes: Condicionales complejos
function getDiscount(user) {
  if (user.isPremium) {
    if (user.yearsActive > 5) {
      if (user.totalPurchases > 10000) {
        return 0.2;
      } else {
        return 0.15;
      }
    } else {
      return 0.1;
    }
  } else {
    if (user.yearsActive > 2) {
      return 0.05;
    } else {
      return 0;
    }
  }
}

// ✅ Después: Early returns y guard clauses
function getDiscount(user) {
  if (!user.isPremium) {
    return user.yearsActive > 2 ? 0.05 : 0;
  }
  
  if (user.yearsActive <= 5) {
    return 0.1;
  }
  
  return user.totalPurchases > 10000 ? 0.2 : 0.15;
}
```

## 📋 Code Smells que detecto:

### 🐛 **Long Method**
- Métodos con más de 20 líneas
- Solución: Extract Method

### 📜 **Large Class**
- Clases con demasiadas responsabilidades
- Solución: Extract Class, Single Responsibility

### 🔁 **Duplicate Code**
- Código repetido en múltiples lugares
- Solución: Extract Method/Function

### 🧩 **Long Parameter List**
- Métodos con muchos parámetros
- Solución: Parameter Object, Builder Pattern

### 🌍 **Global Data**
- Variables globales accedidas por muchos módulos
- Solución: Dependency Injection, Encapsulation

### 🔢 **Magic Numbers**
- Números hard-coded sin explicación
- Solución: Named Constants

## 📊 Patrones de Mejora:

### 🎨 **Strategy Pattern**
```javascript
// Reemplazar switch/if complejos
class PaymentProcessor {
  constructor(strategy) {
    this.strategy = strategy;
  }
  
  process(amount) {
    return this.strategy.process(amount);
  }
}

class CreditCardStrategy {
  process(amount) { /* credit card logic */ }
}

class PayPalStrategy {
  process(amount) { /* paypal logic */ }
}
```

### 🏗️ **Builder Pattern**
```javascript
// Simplificar construcción de objetos complejos
class QueryBuilder {
  constructor() {
    this.query = {};
  }
  
  select(fields) {
    this.query.select = fields;
    return this;
  }
  
  where(condition) {
    this.query.where = condition;
    return this;
  }
  
  build() {
    return this.query;
  }
}

// Uso
const query = new QueryBuilder()
  .select(['name', 'email'])
  .where('active = true')
  .build();
```

## 📝 Mejores Prácticas:

### 🎯 **Single Responsibility Principle**
- Cada clase/función una sola responsabilidad
- Fácil de testear y mantener

### 🔓 **Open/Closed Principle**
- Abierto para extensión, cerrado para modificación
- Uso de interfaces y abstracciones

### 🚀 **DRY (Don't Repeat Yourself)**
- Eliminar duplicación de código
- Extraer funcionalidad común

### 💬 **Meaningful Names**
- Nombres descriptivos y claros
- Evitar abreviaciones confusas

### 🧪 **Small Functions**
- Funciones pequeñas y enfocadas
- Una sola cosa, bien hecha

## 🎯 Resultado esperado:
- Código más legible y mantenible
- Menor complejidad ciclomática
- Mejor separación de responsabilidades
- Fácil testing y debugging
- Documentación de cambios realizados
- Tests pasando después del refactoring