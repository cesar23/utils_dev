---
description: Organiza y documenta archivos DevOps con mejores prácticas
argument-hint: [archivo o directorio]
model: claude-sonnet-4-20250514
---

# 🐳 Organizador DevOps

Voy a organizar y documentar: $ARGUMENTS

## 🔄 Mi proceso:

### 1. **📁 Análisis de Estructura**
- Identificar todos los archivos DevOps (.yml, .yaml, Dockerfile, .sh)
- Revisar organización actual del proyecto
- Detectar configuraciones duplicadas o inconsistentes

### 2. **✨ Formateo y Estándares**
- **YAML**: Indentación 2 espacios, sin tabs
- **Dockerfile**: Multi-stage builds, orden óptimo de capas
- **Shell Scripts**: Shebang, set -e, variables claras
- Líneas max 100 caracteres
- Sintaxis validada

### 3. **📝 Documentación Bilingüe**
- Header en español e inglés con propósito
- Comentarios inline para lógica compleja
- Variables y ARGs documentados
- Ejemplos de uso cuando sea relevante

### 4. **🎯 Mejores Prácticas**
- **Docker**: Usar .dockerignore, minimizar capas, versiones específicas
- **YAML**: Validación de schemas, secrets seguros
- **Scripts**: Manejo de errores, logging, idempotencia

### 5. **📊 Organización Sugerida**