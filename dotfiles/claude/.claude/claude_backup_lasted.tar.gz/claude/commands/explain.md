---
description: Explica código línea por línea para principiantes
argument-hint: [nombre-del-archivo]
---

# 📚 Explicador de Código

Voy a explicar paso a paso el código en: $ARGUMENTS

## Mi explicación incluirá:

### 🎯 **Propósito General**
- ¿Qué hace este código en términos simples?
- ¿Para qué se usa?

### 🔧 **Análisis Línea por Línea**
- Explicación de cada parte importante
- Qué hace cada función o método
- Por qué se escribió así

### 📥 **Entradas y Salidas**
- ¿Qué información necesita el código?
- ¿Qué produce como resultado?

### 🌊 **Flujo de Ejecución**
- En qué orden se ejecuta el código
- Qué decisiones toma el programa

### 🛠️ **Herramientas y Librerías**
- Qué librerías o dependencias usa
- Para qué sirve cada una

### 💡 **Conceptos Clave**
- Explicación de términos técnicos
- Patrones de programación utilizados

### ⚠️ **Casos Especiales**
- Manejo de errores
- Situaciones especiales que considera el código
