---
description: Revisa código buscando errores y mejoras
argument-hint: [nombre-del-archivo]
model: claude-sonnet-4-20250514
---

# 🔍 Revisión de Código

Analiza el archivo: $ARGUMENTS

## ¿Qué voy a revisar?
1. **Errores potenciales**: Bugs que podrían causar problemas
2. **Mejores prácticas**: Si sigues las reglas de programación
3. **Optimizaciones**: Maneras de hacer el código más rápido
4. **Legibilidad**: Si otros programadores pueden entender tu código
5. **Seguridad**: Si hay vulnerabilidades
6. **Rendimiento**: Si el código es eficiente

## Formato del reporte:
- ✅ **Lo que está bien**
- ⚠️ **Lo que se puede mejorar**
- 🚨 **Errores que deben corregirse**
- 💡 **Sugerencias de mejora**
