---
description: Asistente para encontrar y solucionar problemas
argument-hint: [descripción del problema o error]
---

# 🐛 Asistente de Debug

Voy a ayudarte a debuggear: $ARGUMENTS

## 🔍 Mi proceso de debug:

### 1. **📋 Entender el Problema**
- ¿Qué debería hacer el código?
- ¿Qué está haciendo realmente?
- ¿Cuándo ocurre el error?

### 2. **📊 Recopilar Información**
- Revisar mensajes de error
- Analizar logs del sistema
- Examinar el código relacionado

### 3. **🕵️ Investigar Causas Posibles**
- Errores de lógica
- Problemas de configuración
- Dependencias faltantes
- Conflictos de versiones

### 4. **🧪 Probar Hipótesis**
- Crear casos de prueba
- Aislar el problema
- Verificar cada posibilidad

### 5. **🔧 Proponer Soluciones**
- Explicar la causa raíz
- Ofrecer múltiples opciones de fix
- Priorizar por simplicidad y efectividad

### 6. **✅ Verificar la Solución**
- Confirmar que el fix funciona
- Probar casos edge (límite)
- Asegurar que no rompió nada más
