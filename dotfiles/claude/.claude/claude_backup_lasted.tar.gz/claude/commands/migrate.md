---
description: Asistente para migración de código, datos y tecnologías
argument-hint: [tipo de migración o tecnología origen/destino]
model: claude-sonnet-4-20250514
---

# 🔄 Asistente de Migración

Voy a ayudarte con la migración: $ARGUMENTS

## 🎯 Tipos de migración que manejo:

### 📊 **Migración de Bases de Datos**
- Schema migrations (versioning)
- Data migrations (transformación)
- Entre diferentes DBMS
- Optimización de estructura

### 🛠️ **Migración de Tecnologías**
- Framework migrations (React → Vue, etc.)
- Language migrations (JavaScript → TypeScript)
- Cloud migrations (AWS → Azure)
- Architecture migrations (monolith → microservices)

### 📁 **Migración de Datos**
- Import/export entre sistemas
- Limpieza y transformación
- Validación de integridad
- Backup y rollback strategies

## 🔄 Mi proceso de migración:

### 1. **📋 Análisis y Planning**
- Evaluar sistema actual
- Definir objetivos y scope
- Identificar riesgos y dependencias
- Crear timeline realista

### 2. **🧪 Preparación y Testing**
- Setup de ambiente de prueba
- Scripts de migración
- Data validation tools
- Rollback procedures

### 3. **⚡ Ejecución**
- Backup completo
- Migración incremental
- Monitoring en tiempo real
- Validation checks

### 4. **✅ Validación Post-migración**
- Data integrity checks
- Performance validation
- User acceptance testing
- Documentation update

## 📊 Herramientas y Scripts:

### SQL Migrations
```sql
-- Migration script example
BEGIN TRANSACTION;

-- Add new column
ALTER TABLE users ADD COLUMN phone VARCHAR(20);

-- Migrate existing data
UPDATE users SET phone = '000-000-0000' WHERE phone IS NULL;

-- Add constraints
ALTER TABLE users ALTER COLUMN phone SET NOT NULL;

COMMIT;
```

### Code Migration
```javascript
// Automated transformation script
const transformer = {
  'var ': 'const ',
  'function ': 'const functionName = ',
  '== ': '=== ',
  '!= ': '!== '
};

function migrateCode(code) {
  let result = code;
  for (const [old, newVal] of Object.entries(transformer)) {
    result = result.replace(new RegExp(old, 'g'), newVal);
  }
  return result;
}
```

## 🎯 Resultado esperado:
- Migración exitosa sin pérdida de datos
- Sistema funcionando correctamente
- Documentación completa del proceso
- Plan de rollback probado
- Performance equivalente o mejorada