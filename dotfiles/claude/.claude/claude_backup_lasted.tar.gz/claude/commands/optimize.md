---
description: Optimiza el rendimiento del código identificando bottlenecks
argument-hint: [archivo o directorio]
model: claude-sonnet-4-20250514
---

# ⚡ Optimizador de Performance

Voy a analizar y optimizar: $ARGUMENTS

## 🔍 Mi proceso de optimización:

### 1. **📊 Análisis Inicial**
- Medir performance baseline actual
- Identificar hot paths y bottlenecks
- Analizar uso de memoria y CPU
- Revisar complejidad algorítmica

### 2. **🎯 Identificación de Problemas**
- Queries lentas en base de datos
- Algoritmos ineficientes (O(n²), O(n³))
- Memory leaks y uso excesivo de memoria
- Renderizado innecesario en frontend
- Llamadas de red redundantes

### 3. **⚡ Estrategias de Optimización**
- **Algoritmos**: Mejorar complejidad temporal
- **Caching**: Implementar estrategias de cache
- **Lazy Loading**: Cargar contenido bajo demanda
- **Code Splitting**: Dividir bundles grandes
- **Database**: Optimizar queries e índices

### 4. **🧪 Implementación y Testing**
- Aplicar optimizaciones incrementales
- Medir mejoras con profiling tools
- A/B testing de cambios críticos
- Verificar que no se rompa funcionalidad

### 5. **📈 Validación de Resultados**
- Comparar métricas antes/después
- Documentar mejoras obtenidas
- Configurar monitoring continuo
- Sugerir optimizaciones futuras

## 🛠️ Herramientas que utilizo:

### Frontend
- Chrome DevTools Performance
- Lighthouse auditing
- Bundle analyzer
- React Profiler / Vue DevTools

### Backend
- APM tools (New Relic, DataDog)
- Database query analyzers
- Memory profilers
- Load testing tools

### Móvil
- Xcode Instruments (iOS)
- Android Studio Profiler
- Flutter DevTools

## 📋 Tipos de optimización que manejo:

✅ **Performance de algoritmos**
✅ **Optimización de bases de datos**
✅ **Mejoras de rendering frontend**
✅ **Reducción de bundle size**
✅ **Optimización de imágenes y assets**
✅ **Mejoras de tiempo de carga**
✅ **Optimización de memoria**
✅ **Caching strategies**

## 🎯 Resultado esperado:
- Código más rápido y eficiente
- Menor uso de recursos
- Mejor experiencia de usuario
- Métricas de performance mejoradas
- Documentación de optimizaciones realizadas