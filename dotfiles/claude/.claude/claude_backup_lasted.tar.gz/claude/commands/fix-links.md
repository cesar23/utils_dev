---
description: Corrige automáticamente enlaces de Markdown que incluyen iconos/emojis
argument-hint: [archivo markdown]
model: claude-sonnet-4-20250514
---

# 🔗 Corrector de Enlaces con Iconos

Voy a corregir los enlaces de Markdown en: $ARGUMENTS

## 🎯 Mi proceso de corrección:

### 1. **🔍 Análisis del Documento**
- Detectar títulos con emojis/iconos
- Identificar enlaces rotos o incorrectos
- Mapear la estructura de navegación
- Verificar índices y referencias cruzadas

### 2. **🛠️ Corrección Automática**
- **Enlaces del índice**: Incluir emojis en los links
- **Botones de regreso**: Corregir referencias al índice principal
- **Enlaces internos**: Sincronizar con títulos reales
- **Subsecciones**: Mantener coherencia visual

### 3. **📋 Patrones que corrijo:**

#### Problema común:
```markdown
## 📑 ÍNDICE
### 🤖 [AGENTES](#-agentes)  ❌ Sin emoji
- [📦 Core Agents](#-core-agents)  ❌ Sin emoji
[🔝 Volver al índice](#-índice)  ❌ Sin emoji del título
```

#### Corrección automática:
```markdown
## Indice
### 🤖 [AGENTES](#🤖-agentes)  ✅ Con emoji
- [📦 Core Agents](#📦-core-agents)  ✅ Con emoji
[🔝 Volver al índice](#Indice)  ✅ Con emoji del título
```

### 4. **🔧 Tipos de corrección:**

#### **A) Enlaces principales**
- Detectar títulos: `## 🎯 TÍTULO`
- Corregir enlace: `#🎯-título` (incluye emoji)

#### **B) Enlaces de subsección**
- Detectar subtítulos: `### 📦 SUBTÍTULO`
- Corregir enlace: `#📦-subtítulo` (incluye emoji)

#### **C) Botones de regreso**
- Encontrar índice principal: `## 📑 ÍNDICE`
- Corregir todos los: `[🔝 Volver al índice](#📑-índice)`

#### **D) Enlaces internos**
- Sincronizar texto del enlace con título real
- Mantener coherencia de iconos
- Verificar mayúsculas/minúsculas

### 5. **✅ Validación Final**
- Verificar que todos los enlaces funcionen
- Confirmar navegación bidireccional
- Mantener estructura visual consistente
- Probar navegación completa

## 🛠️ Reglas de conversión automática:

### Emojis comunes en enlaces:
- `📑` → Índices principales
- `🤖` → Agentes/Bots
- `🔧` → Comandos/Herramientas
- `📦` → Core/Principal
- `🌐` → Development/Desarrollo
- `⚙️` → DevOps/Operaciones
- `🔒` → Security/Seguridad
- `🎯` → Specialized/Especializado
- `🚀` → Guías rápidas
- `🔄` → Workflows/Procesos
- `✅` → Best practices/Mejores prácticas

### Patrones de enlace:
```markdown
Título: ## 🎯 MI SECCIÓN
Enlace correcto: [🎯 MI SECCIÓN](#🎯-mi-sección)

Título: ### 📦 SUBSECCIÓN
Enlace correcto: [📦 SUBSECCIÓN](#📦-subsección)
```

## 📊 Casos típicos que resuelvo:

### ❌ **Problemas frecuentes:**
1. Enlaces sin emojis: `#-agentes` → `#🤖-agentes`
2. Botones rotos: `#-índice` → `#📑-índice`
3. Inconsistencia: Título con emoji, enlace sin emoji
4. Case sensitivity: `#TÍTULO` vs `#título`
5. Caracteres especiales en emojis complejos

### ✅ **Soluciones automáticas:**
1. Detectar todos los títulos con emojis
2. Generar enlaces correctos automáticamente
3. Reemplazar enlaces incorrectos en todo el documento
4. Mantener formato y estructura originales
5. Verificar funcionalidad de navegación

## 🎯 Resultado esperado:
- Enlaces de Markdown completamente funcionales
- Navegación fluida con iconos correctos
- Coherencia visual en todo el documento
- Botones de regreso funcionando
- Estructura de índice navegable
- Documentación profesional y pulida

## 💡 Casos de uso:
- Documentación técnica con iconos
- Guías de configuración con navegación
- READMEs complejos con índices
- Manuales con múltiples secciones
- Cualquier Markdown con emojis en títulos

¡No más enlaces rotos con iconos! 🔗✨