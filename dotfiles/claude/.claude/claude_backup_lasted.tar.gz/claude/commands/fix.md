---
description: Encuentra y corrige errores en el código
argument-hint: [archivo o descripción del error]
---

# 🔧 Corrector de Errores

Voy a analizar y corregir: $ARGUMENTS

## Mi proceso de corrección:
1. **📖 Leer y entender** el código o error
2. **🔍 Identificar la causa** del problema
3. **💡 Proponer una solución** explicada paso a paso
4. **✏️ Implementar la corrección** en el código
5. **✅ Verificar** que el fix funciona
6. **📚 Explicar** por qué ocurrió el error
7. **🛡️ Sugerir** cómo prevenir errores similares

## Tipos de errores que puedo corregir:
- Errores de sintaxis (código mal escrito)
- Errores lógicos (el código no hace lo que debería)
- Problemas de rendimiento (código lento)
- Vulnerabilidades de seguridad
- Problemas de compatibilidad
