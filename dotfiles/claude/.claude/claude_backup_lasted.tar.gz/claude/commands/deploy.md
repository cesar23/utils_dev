---
description: Asistente para deployment y puesta en producción
argument-hint: [entorno o plataforma]
model: claude-sonnet-4-20250514
---

# 🚀 Asistente de Deployment

Voy a ayudarte con el deployment a: $ARGUMENTS

## 📋 Mi proceso de deployment:

### 1. **🔍 Análisis Pre-deployment**
- Verificar que tests pasen
- Revisar cambios desde último deploy
- Validar configuración de entorno
- Backup de datos críticos

### 2. **⚙️ Preparación**
- Build optimizado para producción
- Minificación y compresión de assets
- Variables de entorno configuradas
- Secrets y certificados actualizados

### 3. **🚀 Estrategia de Deploy**
- **Blue-Green**: Zero downtime
- **Rolling**: Deploy gradual
- **Canary**: Deploy a subset de usuarios
- **Feature flags**: Control de features

### 4. **✅ Validación Post-deploy**
- Health checks automáticos
- Smoke tests en producción
- Monitoreo de métricas
- Rollback plan preparado

## 🌐 Plataformas que manejo:

### ☁️ **Cloud Providers**
- **AWS**: EC2, ECS, Lambda, S3
- **Azure**: App Service, Functions, Blob
- **GCP**: App Engine, Cloud Run, GCS
- **DigitalOcean**: Droplets, App Platform

### 📦 **Container Platforms**
- **Docker**: Containerización
- **Kubernetes**: Orquestación
- **Docker Swarm**: Cluster management
- **Nomad**: Workload orchestration

### 🔄 **CI/CD Platforms**
- **GitHub Actions**: Workflows automatizados
- **GitLab CI**: Pipeline integrado
- **Jenkins**: Build automation
- **Azure DevOps**: Pipeline completo

### 🌍 **Static Hosting**
- **Vercel**: Frontend frameworks
- **Netlify**: JAMstack sites
- **GitHub Pages**: Static sites
- **Cloudflare Pages**: Edge deployment

## 🛠️ Configuraciones típicas:

### Docker Deployment
```yaml
version: '3.8'
services:
  app:
    image: myapp:latest
    ports:
      - "80:3000"
    environment:
      - NODE_ENV=production
    restart: unless-stopped
```

### Kubernetes Deployment
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: myapp
spec:
  replicas: 3
  selector:
    matchLabels:
      app: myapp
  template:
    spec:
      containers:
      - name: myapp
        image: myapp:latest
        ports:
        - containerPort: 3000
```

### GitHub Actions
```yaml
name: Deploy
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to production
        run: ./deploy.sh
```

## 📊 Monitoreo y Health Checks:

### Health Endpoints
```javascript
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});
```

### Rollback Strategy
```bash
#!/bin/bash
# Rollback script
echo "Rolling back to previous version..."
docker tag myapp:current myapp:rollback
docker tag myapp:previous myapp:current
docker-compose up -d
echo "Rollback completed"
```

## 🎯 Checklist de Deployment:

✅ **Pre-deployment**
- [ ] Tests passing
- [ ] Code reviewed
- [ ] Environment variables set
- [ ] Database migrations ready
- [ ] Backup completed

✅ **During deployment**
- [ ] Zero downtime strategy
- [ ] Health checks active
- [ ] Monitoring enabled
- [ ] Rollback plan ready

✅ **Post-deployment**
- [ ] Smoke tests passed
- [ ] Performance metrics normal
- [ ] Error rates acceptable
- [ ] User experience validated

## 🚨 Troubleshooting común:

- **503 Service Unavailable**: Check load balancer
- **502 Bad Gateway**: Verify upstream servers
- **High memory usage**: Check for memory leaks
- **Slow response times**: Investigate database queries
- **Failed health checks**: Review application logs

## 🎯 Resultado esperado:
- Deployment exitoso sin downtime
- Aplicación funcionando correctamente
- Monitoreo y alertas configurados
- Plan de rollback documentado
- Performance baseline establecido