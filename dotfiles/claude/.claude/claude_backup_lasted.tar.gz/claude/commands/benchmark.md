---
description: Ejecuta benchmarks y análisis de performance comparativo
argument-hint: [código o sistema a benchmarkar]
model: claude-sonnet-4-20250514
---

# 📊 Benchmark Analyzer

Voy a ejecutar benchmarks para: $ARGUMENTS

## ⚡ Mi proceso de benchmarking:

### 1. **🎯 Definición de Métricas**
- Tiempo de ejecución
- Uso de memoria
- CPU utilization
- Throughput/Latency
- Escalabilidad

### 2. **🧪 Setup de Pruebas**
- Ambiente controlado
- Datos de prueba representativos
- Múltiples iteraciones
- Warm-up periods

### 3. **📈 Ejecución y Medición**
- Benchmarks automatizados
- Profiling detallado
- Comparación A/B
- Statistical analysis

### 4. **📊 Análisis de Resultados**
- Identificar bottlenecks
- Comparar implementaciones
- Recomendaciones de optimización
- Visualización de datos

## 🛠️ Herramientas de Benchmark:

### JavaScript/Node.js
```javascript
const Benchmark = require('benchmark');

const suite = new Benchmark.Suite;

suite
  .add('RegExp#test', function() {
    /o/.test('Hello World!');
  })
  .add('String#indexOf', function() {
    'Hello World!'.indexOf('o') > -1;
  })
  .on('cycle', function(event) {
    console.log(String(event.target));
  })
  .on('complete', function() {
    console.log('Fastest is ' + this.filter('fastest').map('name'));
  })
  .run({ 'async': true });
```

### Python
```python
import timeit
import memory_profiler

def benchmark_function():
    # Code to benchmark
    return sum(range(1000))

# Time benchmark
time_result = timeit.timeit(benchmark_function, number=10000)

# Memory benchmark
@memory_profiler.profile
def memory_test():
    return benchmark_function()
```

### Database Queries
```sql
-- PostgreSQL query performance
EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)
SELECT * FROM users
WHERE created_at > '2023-01-01'
ORDER BY created_at DESC
LIMIT 100;
```

## 📈 Tipos de benchmark:

### ⚡ **Performance Benchmarks**
- Execution time comparison
- Memory usage analysis
- CPU utilization
- I/O performance

### 🌐 **Load Testing**
- Concurrent users simulation
- Request/response times
- Error rates under load
- Scalability limits

### 📊 **Algorithm Comparison**
- Big O analysis
- Real-world performance
- Memory complexity
- Edge case handling

## 🎯 Resultado esperado:
- Métricas detalladas de performance
- Comparación entre implementaciones
- Identificación de bottlenecks
- Recomendaciones de optimización
- Reportes visuales con gráficos