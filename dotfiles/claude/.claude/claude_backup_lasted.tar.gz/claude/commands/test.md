---
description: Genera tests unitarios, de integración y E2E automáticamente
argument-hint: [archivo o función a testear]
model: claude-sonnet-4-20250514
---

# 🧪 Generador de Tests

Voy a crear tests completos para: $ARGUMENTS

## 🎯 Mi proceso de testing:

### 1. **📋 Análisis del Código**
- Entender la funcionalidad a testear
- Identificar casos de uso principales
- Detectar edge cases y errores posibles
- Analizar dependencias y mocks necesarios

### 2. **🏗️ Estructura de Tests**
- Tests unitarios para funciones puras
- Tests de integración para módulos
- Tests E2E para flujos completos
- Tests de performance cuando aplique

### 3. **📝 Casos de Prueba**
- **Happy path**: Funcionamiento normal
- **Edge cases**: Valores límite y extremos
- **Error handling**: Manejo de errores
- **Boundary testing**: Validaciones de entrada
- **State testing**: Cambios de estado

### 4. **🔧 Setup y Configuración**
- Configurar framework de testing
- Setup de mocks y fixtures
- Configurar base de datos de prueba
- Environment de testing aislado

### 5. **✅ Validación y Coverage**
- Verificar cobertura de código (>80%)
- Tests de regresión
- Performance benchmarks
- Documentar casos de prueba

## 🛠️ Frameworks que manejo:

### JavaScript/TypeScript
- **Jest** + Testing Library
- **Vitest** para proyectos Vite
- **Cypress** para E2E
- **Playwright** para testing cross-browser

### Python
- **pytest** + fixtures
- **unittest** estándar
- **Selenium** para E2E web
- **pytest-django** para Django

### Mobile
- **Detox** para React Native
- **Flutter Driver** para Flutter
- **XCTest** para iOS nativo
- **Espresso** para Android

### Backend
- **Supertest** para APIs Node.js
- **Postman/Newman** para API testing
- **Artillery** para load testing

## 📋 Tipos de tests que genero:

### ✅ **Unit Tests**
```javascript
describe('calculateTotal', () => {
  it('should calculate total with tax', () => {
    expect(calculateTotal(100, 0.1)).toBe(110);
  });

  it('should handle zero amount', () => {
    expect(calculateTotal(0, 0.1)).toBe(0);
  });

  it('should throw error for negative values', () => {
    expect(() => calculateTotal(-10, 0.1)).toThrow();
  });
});
```

### ✅ **Integration Tests**
```javascript
describe('User API', () => {
  beforeEach(async () => {
    await setupTestDB();
  });

  it('should create user successfully', async () => {
    const response = await request(app)
      .post('/api/users')
      .send({ name: 'John', email: 'john@test.com' });

    expect(response.status).toBe(201);
    expect(response.body.name).toBe('John');
  });
});
```

### ✅ **E2E Tests**
```javascript
describe('Login Flow', () => {
  it('should login successfully', () => {
    cy.visit('/login');
    cy.get('[data-testid=email]').type('user@test.com');
    cy.get('[data-testid=password]').type('password');
    cy.get('[data-testid=submit]').click();
    cy.url().should('include', '/dashboard');
  });
});
```

### ✅ **Component Tests**
```javascript
describe('Button Component', () => {
  it('should render with correct text', () => {
    render(<Button>Click me</Button>);
    expect(screen.getByText('Click me')).toBeInTheDocument();
  });

  it('should handle click events', () => {
    const handleClick = jest.fn();
    render(<Button onClick={handleClick}>Click</Button>);
    fireEvent.click(screen.getByText('Click'));
    expect(handleClick).toHaveBeenCalled();
  });
});
```

## 🎯 Best Practices que sigo:

1. **Arrange-Act-Assert**: Estructura clara de tests
2. **One assertion per test**: Tests específicos y enfocados
3. **Descriptive names**: Nombres que explican qué se testea
4. **Independent tests**: Sin dependencias entre tests
5. **Fast execution**: Tests rápidos para feedback inmediato
6. **Deterministic**: Resultados consistentes siempre

## 📊 Métricas de calidad:

- **Coverage > 80%**: Cobertura de código adecuada
- **Mutation testing**: Calidad de los tests
- **Test execution time**: Performance de la suite
- **Flaky tests**: Identificar tests inestables

## 🚀 Resultado esperado:
- Suite completa de tests automatizados
- Cobertura de código documentada
- Tests de regresión para bugs conocidos
- Setup de CI/CD con testing automatizado
- Documentación de casos de prueba