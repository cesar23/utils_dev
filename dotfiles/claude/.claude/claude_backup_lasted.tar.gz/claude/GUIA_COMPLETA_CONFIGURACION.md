# 📋 Guía Completa de Configuración Claude Code

Esta es tu configuración completa de Claude Code con todos los agentes y comandos disponibles, organizados por categorías para fácil referencia.

---

## 📑 ÍNDICE

### 🤖 [AGENTES DISPONIBLES](#🤖-agentes-disponibles)
- [📦 CORE AGENTS (Agentes Principales)](#📦-core-agents-agentes-principales)
- [🌐 DEVELOPMENT AGENTS (Agentes de Desarrollo)](#🌐-development-agents-agentes-de-desarrollo)
- [⚙️ DEVOPS AGENTS (Agentes DevOps)](#⚙️-devops-agents-agentes-devops)
- [🔒 SECURITY AGENTS (Agentes de Seguridad)](#🔒-security-agents-agentes-de-seguridad)
- [🎯 SPECIALIZED AGENTS (Agentes Especializados)](#🎯-specialized-agents-agentes-especializados)

### 🔧 [COMANDOS DISPONIBLES](#🔧-comandos-disponibles)
- [Comandos de Análisis](#comandos-de-análisis)
- [Comandos de Optimización](#comandos-de-optimización)
- [Comandos de Generación](#comandos-de-generación)
- [Comandos de Markdown](#comandos-de-markdown)

### 🎯 [GUÍAS DE USO](#🎯-guías-de-uso)
- [🚀 Guía de Uso Rápido](#🚀-guía-de-uso-rápido)
- [🔄 Workflows Recomendados](#🔄-workflows-recomendados)
- [✅ Mejores Prácticas](#✅-mejores-prácticas)

---

## 🤖 AGENTES DISPONIBLES

### 📦 CORE AGENTS (Agentes Principales)

#### `general-purpose` - DevBot
**Uso:** Tareas generales de desarrollo y exploración de código
**Especialidades:**
- Desarrollo general multi-lenguaje
- Exploración de código desconocido
- Automatización y scripts
- Implementaciones directas

**Cuándo usar:** Cuando no necesitas especialización profunda, tareas de desarrollo básico a intermedio.

[🔝 Volver al índice](#📑-índice)

---

#### `code-reviewer` - ReviewBot
**Uso:** Revisión exhaustiva de código y calidad
**Especialidades:**
- Análisis de calidad de código
- Seguridad y vulnerabilidades
- Performance y optimización
- Arquitectura y patrones

**Cuándo usar:** Para revisiones de código, auditorías de calidad, antes de merge/deploy.

[🔝 Volver al índice](#📑-índice)

---

#### `debugger` - DebugBot
**Uso:** Resolución de problemas y debugging
**Especialidades:**
- Análisis de errores y bugs
- Troubleshooting sistemático
- Root cause analysis
- Soluciones paso a paso

**Cuándo usar:** Cuando tienes errores, bugs, o comportamientos inesperados.

[🔝 Volver al índice](#📑-índice)

---

#### `refactor-expert` - RefactorBot
**Uso:** Mejora de estructura y mantenibilidad del código
**Especialidades:**
- Code smells y anti-patterns
- Extract methods/classes
- Simplificación de código
- Aplicación de patrones de diseño

**Cuándo usar:** Para limpiar código legacy, mejorar estructura, reducir complejidad.

[🔝 Volver al índice](#📑-índice)

---

#### `test-writer` - TestBot
**Uso:** Generación y estrategias de testing
**Especialidades:**
- Tests unitarios, integración, E2E
- TDD y coverage
- Mocking y fixtures
- Testing automatizado

**Cuándo usar:** Para crear tests, mejorar cobertura, implementar TDD.

[🔝 Volver al índice](#📑-índice)

---

#### `architecture-advisor` - ArchBot
**Uso:** Consultoría de arquitectura y decisiones técnicas
**Especialidades:**
- Patrones de diseño
- Arquitectura de software
- Escalabilidad y performance
- Decisiones técnicas estratégicas

**Cuándo usar:** Para decisiones de arquitectura, design patterns, escalabilidad.

[🔝 Volver al índice](#📑-índice)

---

#### `performance-optimizer` - SpeedBot
**Uso:** Optimización de rendimiento y análisis de bottlenecks
**Especialidades:**
- Profiling y benchmarking
- Optimización de algoritmos
- Memory management
- Database performance

**Cuándo usar:** Para problemas de performance, optimización de código lento, análisis de memoria.

[🔝 Volver al índice](#📑-índice)

---

#### `database-expert` - DataBot
**Uso:** Diseño, optimización y administración de bases de datos
**Especialidades:**
- SQL/NoSQL design
- Query optimization
- Indexing strategies
- Migrations y backup

**Cuándo usar:** Para diseño de schemas, optimización de queries, problemas de BD.

[🔝 Volver al índice](#📑-índice)

---

### 🌐 DEVELOPMENT AGENTS (Agentes de Desarrollo)

#### `frontend-expert` - FrontBot
**Uso:** Desarrollo frontend moderno
**Especialidades:**
- React, Vue, Angular
- UI/UX implementation
- Performance frontend
- Modern CSS y frameworks

**Cuándo usar:** Para desarrollo de interfaces, componentes, optimización frontend.

[🔝 Volver al índice](#📑-índice)

---

#### `backend-expert` - BackBot
**Uso:** Desarrollo backend y APIs
**Especialidades:**
- REST/GraphQL APIs
- Microservices
- Database integration
- Authentication/Authorization

**Cuándo usar:** Para desarrollo de APIs, servicios backend, integración de sistemas.

[🔝 Volver al índice](#📑-índice)

---

#### `doc-writer` - DocBot
**Uso:** Documentación técnica especializada
**Especialidades:**
- Technical writing
- API documentation
- User guides
- Code documentation

**Cuándo usar:** Para crear documentación técnica, READMEs, guías de usuario.

[🔝 Volver al índice](#📑-índice)

---

#### `mobile-expert` - MobileBot
**Uso:** Desarrollo de aplicaciones móviles
**Especialidades:**
- React Native, Flutter
- iOS/Android nativo
- Performance móvil
- Publishing en stores

**Cuándo usar:** Para desarrollo de apps móviles, optimización mobile, deploy en stores.

[🔝 Volver al índice](#📑-índice)

---

#### `api-expert` - APIBot
**Uso:** Diseño y desarrollo de APIs
**Especialidades:**
- REST, GraphQL, gRPC
- API documentation
- Performance y caching
- Security best practices

**Cuándo usar:** Para diseño de APIs, documentación OpenAPI, optimización de endpoints.

[🔝 Volver al índice](#📑-índice)

---

### ⚙️ DEVOPS AGENTS (Agentes DevOps)

#### `linux-shell-expert` - ShellBot
**Uso:** Administración Linux y shell scripting
**Especialidades:**
- Bash scripting avanzado
- System administration
- Automation scripts
- Linux troubleshooting

**Cuándo usar:** Para scripts de automatización, administración de servidores, comandos Linux.

[🔝 Volver al índice](#📑-índice)

---

#### `devops-expert` - OpsBot
**Uso:** CI/CD, containerización e infraestructura
**Especialidades:**
- Docker/Kubernetes
- CI/CD pipelines
- Infrastructure as Code
- Cloud platforms

**Cuándo usar:** Para setup de CI/CD, containerización, deployment, infraestructura.

[🔝 Volver al índice](#📑-índice)

---

### 🔒 SECURITY AGENTS (Agentes de Seguridad)

#### `security-expert` - SecBot
**Uso:** Seguridad y análisis de vulnerabilidades
**Especialidades:**
- Vulnerability assessment
- Secure coding practices
- Penetration testing
- Security audits

**Cuándo usar:** Para auditorías de seguridad, análisis de vulnerabilidades, secure coding.

[🔝 Volver al índice](#📑-índice)

---

### 🎯 SPECIALIZED AGENTS (Agentes Especializados)

#### `data-analyst` - DataBot
**Uso:** Análisis de datos y ML básico
**Especialidades:**
- Data analysis y EDA
- Visualizaciones
- Machine Learning básico
- Statistical analysis

**Cuándo usar:** Para análisis de datos, visualizaciones, modelos ML básicos, insights.

[🔝 Volver al índice](#📑-índice)

---

#### `game-dev-expert` - GameBot
**Uso:** Desarrollo de videojuegos
**Especialidades:**
- Unity, Unreal Engine
- Game mechanics
- Performance gaming
- 2D/3D development

**Cuándo usar:** Para desarrollo de juegos, game mechanics, optimización de juegos.

[🔝 Volver al índice](#📑-índice)

---

#### `blockchain-expert` - Web3Bot
**Uso:** Desarrollo blockchain y Web3
**Especialidades:**
- Smart contracts (Solidity)
- DeFi development
- NFT platforms
- Web3 integration

**Cuándo usar:** Para desarrollo Web3, smart contracts, dApps, proyectos DeFi.

[🔝 Volver al índice](#📑-índice)

---

## 🔧 COMANDOS DISPONIBLES

### Comandos de Análisis

#### `/review [archivo]`
**Función:** Revisa código buscando errores y mejoras
**Analiza:**
- Errores potenciales y bugs
- Mejores prácticas
- Optimizaciones posibles
- Legibilidad y mantenibilidad
- Seguridad básica

**Ejemplo:** `/review src/components/UserForm.tsx`

[🔝 Volver al índice](#📑-índice)

---

#### `/debug [descripción del problema]`
**Función:** Asistente para encontrar y solucionar problemas
**Proceso:**
1. Entender el problema
2. Recopilar información
3. Investigar causas posibles
4. Probar hipótesis
5. Proponer soluciones

**Ejemplo:** `/debug "La app se cuelga al hacer login"`

[🔝 Volver al índice](#📑-índice)

---

#### `/explain [archivo]`
**Función:** Explica código línea por línea para principiantes
**Incluye:**
- Propósito general del código
- Análisis línea por línea
- Entradas y salidas
- Flujo de ejecución
- Herramientas y librerías usadas

**Ejemplo:** `/explain src/utils/dateHelpers.js`

[🔝 Volver al índice](#📑-índice)

---

#### `/benchmark [código o sistema]`
**Función:** Ejecuta benchmarks y análisis de performance
**Mide:**
- Tiempo de ejecución
- Uso de memoria
- CPU utilization
- Throughput/Latency
- Comparación A/B

**Ejemplo:** `/benchmark "algoritmo de ordenamiento"`

[🔝 Volver al índice](#📑-índice)

---

### Comandos de Optimización

#### `/optimize [archivo o directorio]`
**Función:** Optimiza el rendimiento del código
**Analiza:**
- Performance baseline actual
- Hot paths y bottlenecks
- Uso de memoria y CPU
- Complejidad algorítmica
- Oportunidades de optimización

**Ejemplo:** `/optimize src/services/dataProcessor.js`

[🔝 Volver al índice](#📑-índice)

---

#### `/refactor [archivo o función]`
**Función:** Refactoriza código para mejorar estructura
**Técnicas:**
- Extract Method/Class
- Simplify conditionals
- Remove code smells
- Apply design patterns
- Improve readability

**Ejemplo:** `/refactor src/legacy/userManager.js`

[🔝 Volver al índice](#📑-índice)

---

#### `/fix [archivo o descripción del error]`
**Función:** Encuentra y corrige errores en el código
**Proceso:**
1. Leer y entender el código/error
2. Identificar la causa del problema
3. Proponer solución explicada
4. Implementar la corrección
5. Verificar que funciona

**Ejemplo:** `/fix "Error: Cannot read property 'name' of undefined"`

[🔝 Volver al índice](#📑-índice)

---

#### `/fix-links [archivo markdown]`
**Función:** Corrige automáticamente enlaces de Markdown con iconos/emojis
**Resuelve:**
- Enlaces sin emojis en títulos con iconos
- Botones de regreso rotos al índice
- Inconsistencias en navegación
- Problemas con caracteres especiales en emojis
- Sincronización entre títulos y enlaces

**Ejemplo:** `/fix-links GUIA_COMPLETA_CONFIGURACION.md`

[🔝 Volver al índice](#📑-índice)

---

### Comandos de Generación

#### `/test [archivo o función]`
**Función:** Genera tests unitarios, integración y E2E
**Genera:**
- Tests unitarios (Jest, Vitest)
- Tests de integración
- Tests E2E (Cypress, Playwright)
- Mocks y fixtures necesarios
- Configuración de testing

**Ejemplo:** `/test src/components/PaymentForm.tsx`

[🔝 Volver al índice](#📑-índice)

---

#### `/scaffold [tipo de proyecto]`
**Función:** Genera estructura base de proyectos
**Soporta:**
- Frontend projects (React, Vue, Angular)
- Backend APIs (Node.js, Python, Go)
- Mobile apps (React Native, Flutter)
- Full-stack applications
- Configuración completa

**Ejemplo:** `/scaffold "React + TypeScript + Vite"`

[🔝 Volver al índice](#📑-índice)

---

#### `/organize-md [archivo-markdown]`
**Función:** Organiza cualquier archivo Markdown añadiendo índice navegable
**Características:**
- Genera índice automático basado en títulos
- Añade botones de regreso a cada sección
- Preserva TODO el contenido original (código, tablas, listas)
- Crea navegación interna funcional
- Mantiene formato y estructura existente
- Detecta emojis en títulos para enlaces correctos

**Ejemplo:** `/organize-md README.md` o `/organize-md mi-documentacion.md`

[🔝 Volver al índice](#📑-índice)

---

#### `/deploy [entorno o plataforma]`
**Función:** Asistente para deployment y puesta en producción
**Incluye:**
- Análisis pre-deployment
- Preparación de build
- Estrategias de deploy
- Validación post-deploy
- Configuración para diferentes plataformas

**Ejemplo:** `/deploy vercel` o `/deploy aws`

[🔝 Volver al índice](#📑-índice)

---

#### `/migrate [tipo de migración]`
**Función:** Asistencia para migración de código/datos/tecnologías
**Tipos:**
- Database migrations
- Framework migrations
- Language migrations
- Data migrations
- Cloud migrations

**Ejemplo:** `/migrate "React Class Components a Hooks"`

[🔝 Volver al índice](#📑-índice)

---

### Comandos de Markdown

#### `/fix-links [archivo markdown]`
**Función:** Corrige automáticamente enlaces de Markdown con iconos/emojis
**Resuelve:**
- Enlaces sin emojis en títulos con iconos
- Botones de regreso rotos al índice
- Inconsistencias en navegación
- Problemas con caracteres especiales en emojis
- Sincronización entre títulos y enlaces

**Ejemplo:** `/fix-links GUIA_COMPLETA_CONFIGURACION.md`

[🔝 Volver al índice](#📑-índice)

---

#### `/organize-md [archivo-markdown]`
**Función:** Organiza cualquier archivo Markdown añadiendo índice navegable
**Características:**
- Genera índice automático basado en títulos
- Añade botones de regreso a cada sección
- Preserva TODO el contenido original (código, tablas, listas)
- Crea navegación interna funcional
- Mantiene formato y estructura existente
- Detecta emojis en títulos para enlaces correctos

**Ejemplo:** `/organize-md README.md` o `/organize-md mi-documentacion.md`

[🔝 Volver al índice](#📑-índice)

---

## 🎯 GUÍAS DE USO

### 🚀 Guía de Uso Rápido

#### Para Desarrollo Frontend
1. **Exploración inicial:** `general-purpose`
2. **Componentes específicos:** `frontend-expert`
3. **Optimización:** `performance-optimizer`
4. **Testing:** `/test` + `test-writer`
5. **Deploy:** `/deploy`

#### Para Desarrollo Backend
1. **APIs:** `api-expert` o `backend-expert`
2. **Base de datos:** `database-expert`
3. **Optimización:** `performance-optimizer`
4. **Seguridad:** `security-expert`
5. **Deploy:** `devops-expert` + `/deploy`

#### Para Proyectos Móviles
1. **Setup inicial:** `/scaffold` + `mobile-expert`
2. **Performance:** `performance-optimizer`
3. **Testing:** `/test`
4. **Deploy stores:** `mobile-expert`

#### Para Análisis de Datos
1. **Exploración:** `data-analyst`
2. **Visualización:** `data-analyst`
3. **ML básico:** `data-analyst`
4. **Optimización:** `performance-optimizer`

#### Para Juegos
1. **Game mechanics:** `game-dev-expert`
2. **Performance:** `performance-optimizer`
3. **Testing:** `/test`

#### Para Web3/Blockchain
1. **Smart contracts:** `blockchain-expert`
2. **Security audit:** `security-expert`
3. **Testing:** `/test`
4. **Deploy:** `blockchain-expert`

#### Para Documentación Markdown
1. **Organizar documento:** `/organize-md`
2. **Corregir enlaces:** `/fix-links`
3. **Documentar proyecto:** `doc-writer`
4. **Review de docs:** `code-reviewer`

[🔝 Volver al índice](#📑-índice)

---

### 🔄 Workflows Recomendados

#### Desarrollo de Nueva Feature
1. `/scaffold` (si es nuevo proyecto)
2. Agente especializado (frontend-expert, backend-expert, etc.)
3. `/test` para generar tests
4. `code-reviewer` para review
5. `/deploy` para poner en producción

#### Debug de Problema
1. `/debug` para análisis inicial
2. `debugger` para investigación profunda
3. `/fix` para implementar solución
4. `/test` para evitar regresión

#### Optimización de Performance
1. `/benchmark` para métricas baseline
2. `performance-optimizer` para análisis
3. `/optimize` para implementar mejoras
4. `/benchmark` para validar mejoras

#### Refactoring de Código Legacy
1. `code-reviewer` para análisis inicial
2. `/refactor` para mejoras estructurales
3. `/test` para mantener funcionalidad
4. `performance-optimizer` si es necesario

#### Organización de Documentación Markdown
1. `/organize-md` para añadir índice y navegación
2. `/fix-links` para corregir enlaces con emojis
3. `doc-writer` para mejorar contenido si es necesario
4. `code-reviewer` para validar calidad de documentación

[🔝 Volver al índice](#📑-índice)

---

### ✅ Mejores Prácticas

#### Combinación de Agentes
- **Combina agentes:** Usa `code-reviewer` después de cualquier desarrollo significativo
- **Testing primero:** Usa `/test` frecuentemente para mantener buena cobertura
- **Optimiza al final:** Usa `performance-optimizer` cuando el código funcione
- **Documenta:** Usa `doc-writer` para documentación técnica
- **Organiza Markdown:** Usa `/organize-md` + `/fix-links` para documentación navegable

#### Flujo de Trabajo Eficiente
- **Planifica:** Usa `architecture-advisor` para decisiones importantes
- **Desarrolla:** Usa agentes especializados según el dominio
- **Valida:** Usa `code-reviewer` y `/test` regularmente
- **Optimiza:** Usa `performance-optimizer` para mejoras
- **Despliega:** Usa `devops-expert` y `/deploy` para producción

#### Especialización por Dominio
- **Frontend:** `frontend-expert` → `performance-optimizer` → `test-writer`
- **Backend:** `backend-expert` → `database-expert` → `security-expert`
- **Mobile:** `mobile-expert` → `performance-optimizer` → testing
- **Data:** `data-analyst` → visualización → insights
- **Gaming:** `game-dev-expert` → `performance-optimizer` → testing
- **Web3:** `blockchain-expert` → `security-expert` → testing
- **Documentación:** `doc-writer` → `/organize-md` → `/fix-links`

[🔝 Volver al índice](#📑-índice)

---

## 📊 RESUMEN RÁPIDO

### 🤖 **19 Agentes Especializados**
- **8 Core:** general-purpose, code-reviewer, debugger, refactor-expert, test-writer, architecture-advisor, performance-optimizer, database-expert
- **5 Development:** frontend-expert, backend-expert, doc-writer, mobile-expert, api-expert
- **2 DevOps:** linux-shell-expert, devops-expert
- **1 Security:** security-expert
- **3 Specialized:** data-analyst, game-dev-expert, blockchain-expert

### 🔧 **13 Comandos Útiles**
- **Análisis:** `/review`, `/debug`, `/explain`, `/benchmark`
- **Optimización:** `/optimize`, `/refactor`, `/fix`
- **Generación:** `/test`, `/scaffold`, `/deploy`, `/migrate`
- **Markdown:** `/fix-links`, `/organize-md`

¡Esta es tu configuración completa! Usa este documento como referencia rápida para saber qué agente o comando usar en cada situación. 🚀

[🔝 Volver al índice](#📑-índice)